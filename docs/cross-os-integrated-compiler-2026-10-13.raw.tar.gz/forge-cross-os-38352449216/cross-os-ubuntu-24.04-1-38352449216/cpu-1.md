# Native cross-OS CPU comparison

Platform: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39` / `x86_64`. Measured 60 balanced triples per workload, seed 20261014.

| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0069 [0.9951, 1.0258] | 1.6855 [1.6636, 1.7037] | supported for this case |
| primes | 1.1955 [1.1830, 1.2069] | 1.4069 [1.3918, 1.4241] | supported for this case |
| scan | 2.1163 [2.0973, 2.1615] | 2.3824 [2.3541, 2.4198] | supported for this case |
| builder | 1.6620 [1.6271, 1.6895] | 1.4427 [1.4221, 1.4868] | supported for this case |
| immutable | 1.1076 [1.0871, 1.1273] | 22.1383 [21.7101, 22.3306] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
