# Native cross-OS CPU comparison

Platform: `macOS-15.7.9-arm64-arm-64bit` / `arm64`. Measured 60 balanced triples per workload, seed 20261014.
**Generated-C experiment `range-kernels`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.8665 [1.8254, 1.9307] | 1.6199 [1.5760, 1.6772] | supported for this case |
| primes | 0.9864 [0.9806, 0.9945] | 0.9366 [0.9279, 0.9463] | below target |
| scan | 0.9988 [0.9896, 1.0089] | 1.0013 [0.9837, 1.0168] | below target |
| builder | 2.0863 [2.0293, 2.1753] | 1.2535 [1.1915, 1.3064] | supported for this case |
| immutable | 1.0155 [0.9907, 1.0298] | 17.9486 [16.9930, 18.8428] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
