# Native cross-OS CPU comparison

Platform: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39` / `x86_64`. Measured 60 balanced triples per workload, seed 20261014.
**Generated-C experiment `range-kernels`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 0.9992 [0.9952, 1.0057] | 1.6265 [1.6191, 1.6300] | supported for this case |
| primes | 1.0404 [1.0333, 1.0450] | 1.2615 [1.2536, 1.2669] | supported for this case |
| scan | 1.0035 [1.0006, 1.0080] | 0.8136 [0.8088, 0.8163] | below target |
| builder | 1.2948 [1.2931, 1.2984] | 1.2241 [1.2207, 1.2268] | supported for this case |
| immutable | 1.0002 [0.9927, 1.0058] | 18.8401 [18.7375, 18.9570] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
