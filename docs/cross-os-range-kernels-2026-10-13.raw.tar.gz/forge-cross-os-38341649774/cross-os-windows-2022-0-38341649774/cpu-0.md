# Native cross-OS CPU comparison

Platform: `Windows-2022Server-10.0.20348-SP0` / `AMD64`. Measured 60 balanced triples per workload, seed 20261013.
**Generated-C experiment `range-kernels`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0003 [0.9996, 1.0007] | 1.6736 [1.6726, 1.6744] | supported for this case |
| primes | 1.0592 [1.0581, 1.0617] | 1.1778 [1.1746, 1.1807] | supported for this case |
| scan | 0.9707 [0.9690, 0.9725] | 0.6456 [0.6396, 0.6525] | below target |
| builder | 1.2744 [1.2712, 1.2788] | 0.9546 [0.9513, 0.9564] | below target |
| immutable | 0.9968 [0.9929, 1.0018] | 68.6906 [68.2821, 69.0115] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-0.json](cpu-0.json).
