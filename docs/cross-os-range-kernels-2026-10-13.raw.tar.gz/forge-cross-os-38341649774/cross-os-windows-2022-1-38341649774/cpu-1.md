# Native cross-OS CPU comparison

Platform: `Windows-2022Server-10.0.20348-SP0` / `AMD64`. Measured 60 balanced triples per workload, seed 20261014.
**Generated-C experiment `range-kernels`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0003 [0.9998, 1.0007] | 1.8575 [1.8561, 1.8582] | supported for this case |
| primes | 1.0372 [1.0359, 1.0393] | 1.2175 [1.2155, 1.2196] | supported for this case |
| scan | 0.9374 [0.9365, 0.9390] | 0.4994 [0.4990, 0.4996] | below target |
| builder | 1.2808 [1.2796, 1.2821] | 0.9469 [0.9462, 0.9482] | below target |
| immutable | 0.9867 [0.9850, 0.9878] | 49.4404 [49.1941, 49.6308] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
