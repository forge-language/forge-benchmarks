# Native cross-OS CPU comparison

Platform: `Windows-2022Server-10.0.20348-SP0` / `AMD64`. Measured 60 balanced triples per workload, seed 2026101401.

| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 0.9998 [0.9992, 1.0002] | 1.8555 [1.8545, 1.8577] | supported for this case |
| primes | 1.1798 [1.1746, 1.1819] | 1.3835 [1.3806, 1.3861] | supported for this case |
| scan | 4.4147 [4.4116, 4.4193] | 2.3562 [2.3526, 2.3598] | supported for this case |
| builder | 2.0946 [2.0906, 2.0988] | 1.5512 [1.5497, 1.5534] | supported for this case |
| immutable | 1.5624 [1.5592, 1.5666] | 77.5570 [77.0937, 77.8725] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-0.json](cpu-0.json).
