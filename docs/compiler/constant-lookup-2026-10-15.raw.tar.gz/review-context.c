#include "semantic.h"
#include "mod_registry.h"
#include "function_index.h"
#include "local_index.h"

/* Unknown is deliberately distinct from every language type: imported binary
 * APIs do not expose a typed Forge AST. Never guess signatures from names. */
#define UNKNOWN ((ForgeTypeKind)-1)
#define FUNCTION_REFERENCE ((ForgeTypeKind)-2)
typedef struct { ForgeStr name; ForgeType type; bool initialized, owned; } Local;
_Static_assert(offsetof(Local, name) == 0, "local index requires a leading name");
typedef struct {
    Program *program;
    ForgeStr module;
    ProcessDecl *process;
    Local *locals;
    size_t count, capacity;
    ForgeLocalIndex local_index;
    ForgeType result;
    unsigned loops, depth;
    bool coroutine;
    ForgeFunctionIndex functions, library_functions;
    ForgeFunctionIndex *module_functions;
} Check;

static void error_at(SourceSpan span, ForgeStr name, const char *reason) {
    size_t reason_len = strlen(reason);
    if (reason_len > SIZE_MAX - 64 || name.len > SIZE_MAX - reason_len - 64)
        forge_die("semantic diagnostic too large");
    size_t cap = name.len + reason_len + 32;
    char *message = malloc(cap), *legacy = malloc(cap + 32);
    if (!message || !legacy) forge_die("out of memory");
    snprintf(message,cap,"%s '%.*s'",reason,(int)name.len,name.data);
    snprintf(legacy,cap+32,"forge: semantic: %s",message);
    forge_source_diagnostic(span,"semantic",message,legacy);
    free(message); free(legacy); exit(1);
}
#define error(name, reason) error_at(location, name, reason)
static ForgeType unknown(void) { ForgeType t = { .kind = UNKNOWN }; return t; }
static bool numeric(ForgeType t) {
    return t.kind == UNKNOWN || t.kind == TY_INT || t.kind == TY_FLOAT || t.kind == TY_BOOL;
}
static bool compatible(ForgeType to, ForgeType from) {
    if (to.kind == FUNCTION_REFERENCE || from.kind == FUNCTION_REFERENCE) return false;
    if (to.kind == UNKNOWN || from.kind == UNKNOWN) return true;
    if (to.kind == TY_FLOAT && numeric(from)) return true;
    if ((to.kind == TY_INT || to.kind == TY_BOOL) &&
        (from.kind == TY_INT || from.kind == TY_BOOL)) return true;
    return to.kind == from.kind &&
        (to.kind != TY_STRUCT || forge_str_eq(to.struct_name, from.struct_name));
}
static void require(ForgeType to, ForgeType from, ForgeStr name, SourceSpan location) {
    if (!compatible(to, from)) error(name, "type mismatch for");
}
static Local *local(Check *c, ForgeStr name) {
    /* Borrow only until the next declare(): expression checking never declares
     * bindings. The index itself never retains this reallocatable pointer. */
    size_t i = forge_local_find(&c->local_index, c->locals, c->count, sizeof(*c->locals), name);
    return i == SIZE_MAX ? NULL : &c->locals[i];
}
static void declare(Check *c, ForgeStr name, ForgeType t, bool initialized) {
    c->locals = forge_array_reserve(c->locals, c->count, &c->capacity, sizeof(*c->locals), 16);
    c->locals[c->count++] = (Local){name, t, initialized, false};
    forge_local_push(&c->local_index, name);
}
static FnDecl *resolve(Check *c, ForgeStr module, ForgeStr name) {
    Program *p = c->program;
    if (module.len) {
        for (size_t i = 0; i < p->module_count; ++i)
            if (forge_str_eq(p->modules[i].name, module))
                return forge_function_index_get(&c->module_functions[i], name);
        if (p->library.present && forge_str_eq(p->library.name, module))
            return forge_function_index_get(&c->library_functions, name);
        return NULL;
    }
    FnDecl *fn = forge_function_index_get(&c->functions, name);
    if (!fn && p->library.present)
        fn = forge_function_index_get(&c->library_functions, name);
    return fn;
}
static ForgeType expression(Check *, Expr *);
/* Callback ABIs currently use int/ptr handles. Keep their compatibility scoped
 * to argument positions; a function reference is never a scalar value. A source
 * wrapper is eligible only when its parameter is forwarded directly to an
 * opaque extern/binary slot. This is not a substitute for function types. */
static ForgeType expression(Check *c, Expr *e) {
    SourceSpan location = e ? (e->focus.file ? e->focus : e->span) : (SourceSpan){0};
    if (!e) return forge_type_void();
    if (++c->depth > 2000) forge_die("semantic expression nesting limit exceeded");
    ForgeType t = unknown();
    switch (e->kind) {
    case EXPR_INT: t = forge_type_int(); break;
    case EXPR_FLOAT: t = forge_type_float(); break;
    case EXPR_BOOL: t = forge_type_bool(); break;
    case EXPR_STRING: t = forge_type_string(); break;
    case EXPR_IDENT: {
        Local *l = local(c, e->as.ident);
        if (l) {
            if (!l->initialized) error(e->as.ident, l->owned ? "use of moved owned value" : "uninitialized value");
            t = l->type; break;
        }
        for (size_t i = 0; i < c->program->const_count; ++i)
            if (forge_str_eq(c->program->consts[i].name, e->as.ident)) {
                t = expression(c, c->program->consts[i].value); goto done;
            }
        /* Function identifiers are accepted as callback references. */
        if (resolve(c, c->module, e->as.ident) || resolve(c, forge_str(""), e->as.ident)) { t.kind=FUNCTION_REFERENCE; break; }
        error(e->as.ident, "unknown value"); break;
    }
void forge_check_program(Program *p) {
    Check c = {.program = p};
    c.functions = forge_function_index_build(p->functions, p->fn_count);
    if (p->library.present)
        c.library_functions = forge_function_index_build(p->library.functions, p->library.fn_count);
    if (p->module_count)
        c.module_functions = forge_calloc_array(p->module_count, sizeof(*c.module_functions));
    /* Keep one owner per module, in original order. A matching empty module
     * must still block later modules and a same-named library in resolve(). */
    for (size_t i = 0; i < p->module_count; i++)
        c.module_functions[i] = forge_function_index_build(p->modules[i].functions, p->modules[i].fn_count);
    for (size_t i = 0; i < p->const_count; ++i) expression(&c, p->consts[i].value);
    functions(&c, p->functions, p->fn_count);
    if (p->library.present) functions(&c, p->library.functions, p->library.fn_count);
    for (size_t i = 0; i < p->module_count; ++i) {
        c.module = p->modules[i].name;
        functions(&c, p->modules[i].functions, p->modules[i].fn_count);
    }
    c.module = forge_str("");
    for (size_t i = 0; i < p->native_count; ++i)
        body(&c, NULL, &p->natives[i].body, forge_type_int());
    for (size_t i = 0; i < p->process_count; ++i) {
        c.process = &p->processes[i];
        body(&c, NULL, &c.process->body, forge_type_void());
        if (c.process->has_receive) body(&c, &c.process->receive_param, c.process->on_receive, forge_type_void());
        c.coroutine = true;
        for (size_t j = 0; j < c.process->coro_count; ++j)
            body(&c, c.process->coros[j].params, &c.process->coros[j].body, unknown());
        c.coroutine = false;
    }
    free(c.locals);
    forge_local_free(&c.local_index);
    forge_function_index_free(&c.functions);
    forge_function_index_free(&c.library_functions);
    for (size_t i = 0; i < p->module_count; i++)
        forge_function_index_free(&c.module_functions[i]);
    free(c.module_functions);
}

typedef struct ConstDecl {
    ForgeStr name;
    Expr *value;
} ConstDecl;

struct Param {
    SourceSpan span;
    ForgeStr name;
    ForgeType type;
    Param *next;
};

typedef