# Retained compiler experiment

This baseline is the previous function/local-index working tree, not clean HEAD.
The archive contains the before-change compiler/CMake snapshot, final source,
23-row paired measurements, generated inputs/outputs, exact commands, both
compiler binaries, a common Release SDK and the incremental patch. The final
public tests are retained in full; their pre-change bodies are outside the
incremental patch replay. The patch reconstructs its five affected files exactly.

On the recorded Linux x86_64 host, from this extracted directory:

```
python3 source/tests/const_lookup_bench.py --baseline "$PWD/forge-baseline" --candidate "$PWD/forge-candidate" --root "$PWD/sdk" --output "$PWD/new-measurement" --cpu 2 --pairs 24
python3 differential.py
```

The original differential.py records the session's absolute SDK path; change
that one sdk assignment to the extracted sdk directory to run elsewhere. Both
compiler variants must use the same SDK and source paths. Timing uses CLI wall
clock, one excluded warmup pair, alternating AB/BA order, no concurrent builds,
and byte equality checks for every successful C/JS output pair. CPU 2 describes
the measured host; choose a supported CPU consistently on a different machine.

reconstruction.json records standalone builds of both complete compiler source
snapshots in the same source/link order and with the same Release flags as CMake,
using the retained common runtime archive. They reconstruct both measured ELF
binaries byte for byte on this host. The exact CMake commands are also retained.

The instrumented baseline profile was built separately:

```
cc -std=c11 -O3 -g -pg -DNDEBUG -I compiler -I build/include compiler/*.c build/lib/libforge_runtime.a -pthread -lm -o forge-profile
GMON_OUT_PREFIX=/absolute/gmon taskset -c 2 /absolute/forge-profile /absolute/last-16384.fg --check --forge-root /absolute/build
# Pass the actual generated gmon.PID file to gprof.
```

The measured Release compilers do not use -pg. Full CTest, rebuilt self-host
fixed-point output and sanitizer logs belong to the actual local dependency
checkout. The SDK's local stdlib HTTP fix is based on its pinned revision, and
is unchanged between compilers; see environment.json. No source revision is
published or dependency pin updated by this archive. Sources and static archives
retain their component license notices under sdk/runtime and sdk/stdlib.
