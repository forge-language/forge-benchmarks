"use strict";
const __forge=(()=>{
const wrap=v=>BigInt.asIntN(64,v),numeric=v=>typeof v==='boolean'?BigInt(v):v;
const arithmetic=(a,b,op)=>{a=numeric(a);b=numeric(b);if(typeof a==='bigint'&&typeof b==='bigint'){if((op==='div'||op==='mod')&&(b===0n||(a===-9223372036854775808n&&b===-1n)))throw new RangeError('Forge integer division');return wrap(op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b);}a=Number(a);b=Number(b);return op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b;};
const bytes=s=>new TextEncoder().encode(s),decode=b=>new TextDecoder('utf-8',{fatal:true}).decode(b);
const eq=(a,b)=>{a=numeric(a);b=numeric(b);return typeof a==='number'&&typeof b==='bigint'||typeof a==='bigint'&&typeof b==='number'?Number(a)===Number(b):a===b;},index=(s,n)=>{if(typeof s!=='string')return s[Number(n)];const b=bytes(s),j=Number(n);return j<0||j>=b.length?-1n:BigInt(b[j]);},i=v=>BigInt(v);
const cbytes=s=>{s=s==null?'':s;const end=s.indexOf(String.fromCharCode(0));return bytes(end<0?s:s.slice(0,end));};
const handles=new Map();let next=1n;const store=v=>{const h=next++;handles.set(h,v);return h;};
const view=h=>handles.get(h),builder=h=>{const b=handles.get(h);return b&&b.kind==='builder'?b:null;};
const reserve=(b,n)=>{if(n<=b.data.length)return;let cap=Math.max(64,b.data.length);while(cap<n)cap*=2;const d=new Uint8Array(cap);d.set(b.data.subarray(0,b.len));b.data=d;};
const range=(v,a,n)=>{if(!v||v.kind!=='view'||a<0n||n<0n)return null;const size=BigInt(v.data.length),from=a<size?a:size,left=size-from;return [Number(from),Number(n<left?n:left)];};
const appendBytes=(h,d)=>{const b=builder(h);if(!b)return 0n;reserve(b,b.len+d.length);b.data.set(d,b.len);b.len+=d.length;return h;};
return {add:(a,b)=>typeof a==='string'&&typeof b==='string'?a+b:arithmetic(a,b,'add'),sub:(a,b)=>arithmetic(a,b,'sub'),mul:(a,b)=>arithmetic(a,b,'mul'),div:(a,b)=>arithmetic(a,b,'div'),mod:(a,b)=>arithmetic(a,b,'mod'),eq,ne:(a,b)=>!eq(a,b),lt:(a,b)=>a<b,le:(a,b)=>a<=b,gt:(a,b)=>a>b,ge:(a,b)=>a>=b,index,println:(...v)=>console.log(v.map(x=>typeof x==='boolean'?(x?'1':'0'):String(x)).join('')),
fr_str_len:s=>i(bytes(s).length),fr_str_concat:(a,b)=>a+b,fr_str_eq:(a,b)=>i(a===b),fr_str_sub:(s,a,n)=>{if(a<0n||n<0n)return null;return decode(bytes(s).slice(Number(a),Number(a+n)));},fr_str_contains:(s,x)=>i(s.includes(x)),fr_str_trim:s=>s.trim(),fr_str_char_at:index,fr_str_append:(s,c)=>{if(c<0n||c>127n)throw new RangeError('JavaScript strings require valid UTF-8');return s+String.fromCharCode(Number(c));},fr_str_append_str:(s,t)=>s+t,fr_str_from_int:String,fr_str_arena_reset:()=>{handles.clear();return 0n;},
fr_str_view:s=>store({kind:'view',data:cbytes(s)}),fr_str_view_len:h=>{const v=view(h);return i(v&&v.kind==='view'?v.data.length:0);},
fr_str_view_at:(h,n)=>{const v=view(h);return !v||v.kind!=='view'||n<0n||n>=BigInt(v.data.length)?-1n:BigInt(v.data[Number(n)]);},
fr_str_view_sub:(h,a,n)=>{const v=view(h),r=range(v,a,n);return r?decode(v.data.subarray(r[0],r[0]+r[1])):null;},
fr_str_view_matches:(h,a,s)=>{const v=view(h);if(!v||v.kind!=='view'||s==null||a<0n||a>BigInt(v.data.length))return 0n;const d=cbytes(s),from=Number(a);if(d.length>v.data.length-from)return 0n;for(let j=0;j<d.length;j++)if(v.data[from+j]!==d[j])return 0n;return 1n;},
fr_str_view_append_byte:(h,c)=>{const v=view(h);if(!v||v.kind!=='view')return 0n;return store({kind:'view',data:cbytes(decode(v.data)+String.fromCharCode(Number(c)))});},
fr_str_builder:()=>store({kind:'builder',data:new Uint8Array(0),len:0}),fr_str_builder_with_capacity:n=>{if(n<0n||n>BigInt(Number.MAX_SAFE_INTEGER))return 0n;try{return store({kind:'builder',data:new Uint8Array(Number(n)),len:0});}catch{return 0n;}},fr_str_builder_append:(h,s)=>appendBytes(h,cbytes(s)),
fr_str_builder_append_view:(h,vh,a,n)=>{const v=view(vh),r=range(v,a,n);return r?appendBytes(h,v.data.subarray(r[0],r[0]+r[1])):0n;},
fr_str_builder_char:(h,c)=>{const b=builder(h);if(!b||c<=0n||c>255n)return 0n;reserve(b,b.len+1);b.data[b.len++]=Number(c);return h;},
fr_str_builder_finish:h=>{const b=builder(h);return b?decode(b.data.subarray(0,b.len)):null;},fr_str_builder_finish_take:h=>{const b=builder(h);if(!b)return null;const s=decode(b.data.subarray(0,b.len));b.data=new Uint8Array(0);b.len=0;return s;},
fr_abs_i:x=>x<0n?-x:x,fr_abs_f:Math.abs,fr_min_i:(a,b)=>a<b?a:b,fr_max_i:(a,b)=>a>b?a:b,fr_clamp_i:(x,a,b)=>x<a?a:x>b?b:x,fr_pow_i:(a,b)=>{if(b<0n)return 0n;let r=1n;while(b>0n){if(b&1n)r=wrap(r*a);a=wrap(a*a);b>>=1n;}return r;},fr_time_now_ms:()=>i(Date.now()),
fr_json_get_string:(s,k)=>{const v=JSON.parse(s)[k];return typeof v==='string'?v:'';},fr_json_get_int:(s,k)=>{const v=JSON.parse(s)[k];if(!Number.isSafeInteger(v))throw new RangeError('Use the lossless browser JSON module');return i(v);},fr_json_stringify_str:(k,v)=>JSON.stringify({[k]:v}),fr_json_stringify_int:(k,v)=>'{'+JSON.stringify(k)+':'+String(v)+'}'};})();
const fr_K_027=(27n);
const fr_K_034=(34n);
const fr_K_014=(14n);
const fr_K_028=(28n);
const fr_K_013=(13n);
const fr_K_010=(10n);
const fr_K_053=(53n);
const fr_K_000=(0n);
const fr_K_033=(33n);
const fr_K_017=(17n);
const fr_K_046=(46n);
const fr_K_006=(6n);
const fr_K_008=(8n);
const fr_K_029=(29n);
const fr_K_024=(24n);
const fr_K_045=(45n);
const fr_K_022=(22n);
const fr_K_038=(38n);
const fr_K_057=(57n);
const fr_K_012=(12n);
const fr_K_048=(48n);
const fr_K_039=(39n);
const fr_K_054=(54n);
const fr_K_064=(64n);
const fr_K_002=(2n);
const fr_K_043=(43n);
const fr_K_035=(35n);
const fr_K_044=(44n);
const fr_K_059=(59n);
const fr_K_031=(31n);
const fr_K_026=(26n);
const fr_K_021=(21n);
const fr_K_058=(58n);
const fr_K_015=(15n);
const fr_K_003=(3n);
const fr_K_030=(30n);
const fr_K_041=(41n);
const fr_K_050=(50n);
const fr_K_025=(25n);
const fr_K_052=(52n);
const fr_K_016=(16n);
const fr_K_055=(55n);
const fr_K_049=(49n);
const fr_K_037=(37n);
const fr_K_042=(42n);
const fr_K_018=(18n);
const fr_K_040=(40n);
const fr_K_009=(9n);
const fr_K_061=(61n);
const fr_K_007=(7n);
const fr_K_020=(20n);
const fr_K_023=(23n);
const fr_K_019=(19n);
const fr_K_056=(56n);
const fr_K_032=(32n);
const fr_K_062=(62n);
const fr_K_063=(63n);
const fr_K_001=(1n);
const fr_K_051=(51n);
const fr_K_047=(47n);
const fr_K_005=(5n);
const fr_K_060=(60n);
const fr_K_036=(36n);
const fr_K_011=(11n);
const fr_K_004=(4n);
function fr_f_0() {
  return fr_K_046;
}

function fr_f_1() {
  return fr_K_019;
}

function fr_f_2() {
  return fr_K_048;
}

function fr_f_3() {
  return fr_K_053;
}

function fr_f_4() {
  return fr_K_002;
}

function fr_f_5() {
  return fr_K_050;
}

function fr_f_6() {
  return fr_K_041;
}

function fr_f_7() {
  return fr_K_015;
}

function fr_f_8() {
  return fr_K_006;
}

function fr_f_9() {
  return fr_K_004;
}

function fr_f_10() {
  return fr_K_008;
}

function fr_f_11() {
  return fr_K_051;
}

function fr_f_12() {
  return fr_K_007;
}

function fr_f_13() {
  return fr_K_032;
}

function fr_f_14() {
  return fr_K_027;
}

function fr_f_15() {
  return fr_K_013;
}

function fr_f_16() {
  return fr_K_048;
}

function fr_f_17() {
  return fr_K_007;
}

function fr_f_18() {
  return fr_K_025;
}

function fr_f_19() {
  return fr_K_015;
}

function __forge_main() {
  {
    let fr_K_046="local";
    __forge.println(fr_K_046);
  }
  __forge.println(fr_K_046);
  {
    let fr_K_019="local";
    __forge.println(fr_K_019);
  }
  __forge.println(fr_K_019);
  {
    let fr_K_048="local";
    __forge.println(fr_K_048);
  }
  __forge.println(fr_K_048);
  return (0n);
}
__forge_main();
