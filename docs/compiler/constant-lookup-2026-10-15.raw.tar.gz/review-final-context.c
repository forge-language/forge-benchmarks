#include "semantic.h"
#include "mod_registry.h"
#include "function_index.h"
#include "const_index.h"
#include "local_index.h"

/* Unknown is deliberately distinct from every language type: imported binary
 * APIs do not expose a typed Forge AST. Never guess signatures from names. */
#define UNKNOWN ((ForgeTypeKind)-1)
#define FUNCTION_REFERENCE ((ForgeTypeKind)-2)
typedef struct { ForgeStr name; ForgeType type; bool initialized, owned; } Local;
_Static_assert(offsetof(Local, name) == 0, "local index requires a leading name");
typedef struct {
    Program *program;
    ForgeStr module;
    ProcessDecl *process;
    Local *locals;
    size_t count, capacity;
    ForgeLocalIndex local_index;
    ForgeType result;
    unsigned loops, depth;
    bool coroutine;
    ForgeConstIndex constants;
    ForgeFunctionIndex functions, library_functions;
    ForgeFunctionIndex *module_functions;
} Check;

static ForgeType expression(Check *c, Expr *e) {
    SourceSpan location = e ? (e->focus.file ? e->focus : e->span) : (SourceSpan){0};
    if (!e) return forge_type_void();
    if (++c->depth > 2000) forge_die("semantic expression nesting limit exceeded");
    ForgeType t = unknown();
    switch (e->kind) {
    case EXPR_INT: t = forge_type_int(); break;
    case EXPR_FLOAT: t = forge_type_float(); break;
    case EXPR_BOOL: t = forge_type_bool(); break;
    case EXPR_STRING: t = forge_type_string(); break;
    case EXPR_IDENT: {
        Local *l = local(c, e->as.ident);
        if (l) {
            if (!l->initialized) error(e->as.ident, l->owned ? "use of moved owned value" : "uninitialized value");
            t = l->type; break;
        }
        ConstDecl *constant = forge_const_index_get(&c->constants, e->as.ident);
        if (constant) {
            /* Recheck in this caller's context: constant initializers may refer
             * to names shadowed by live locals. Do not memoize their types. */
            t = expression(c, constant->value); goto done;
        }
        /* Function identifiers are accepted as callback references. */
        if (resolve(c, c->module, e->as.ident) || resolve(c, forge_str(""), e->as.ident)) { t.kind=FUNCTION_REFERENCE; break; }
        error(e->as.ident, "unknown value"); break;
    }
void forge_check_program(Program *p) {
    Check c = {.program = p};
    c.constants = forge_const_index_build(p->consts, p->const_count);
    c.functions = forge_function_index_build(p->functions, p->fn_count);
    if (p->library.present)
        c.library_functions = forge_function_index_build(p->library.functions, p->library.fn_count);
    if (p->module_count)
        c.module_functions = forge_calloc_array(p->module_count, sizeof(*c.module_functions));
    /* Keep one owner per module, in original order. A matching empty module
     * must still block later modules and a same-named library in resolve(). */
    for (size_t i = 0; i < p->module_count; i++)
        c.module_functions[i] = forge_function_index_build(p->modules[i].functions, p->modules[i].fn_count);
    for (size_t i = 0; i < p->const_count; ++i) expression(&c, p->consts[i].value);
    functions(&c, p->functions, p->fn_count);
    if (p->library.present) functions(&c, p->library.functions, p->library.fn_count);
    for (size_t i = 0; i < p->module_count; ++i) {
        c.module = p->modules[i].name;
        functions(&c, p->modules[i].functions, p->modules[i].fn_count);
    }
    c.module = forge_str("");
    for (size_t i = 0; i < p->native_count; ++i)
        body(&c, NULL, &p->natives[i].body, forge_type_int());
    for (size_t i = 0; i < p->process_count; ++i) {
        c.process = &p->processes[i];
        body(&c, NULL, &c.process->body, forge_type_void());
        if (c.process->has_receive) body(&c, &c.process->receive_param, c.process->on_receive, forge_type_void());
        c.coroutine = true;
        for (size_t j = 0; j < c.process->coro_count; ++j)
            body(&c, c.process->coros[j].params, &c.process->coros[j].body, unknown());
        c.coroutine = false;
    }
    free(c.locals);
    forge_local_free(&c.local_index);
    forge_const_index_free(&c.constants);
    forge_function_index_free(&c.functions);
    forge_function_index_free(&c.library_functions);
    for (size_t i = 0; i < p->module_count; i++)
        forge_function_index_free(&c.module_functions[i]);
    free(c.module_functions);
}
