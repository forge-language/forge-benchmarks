import argparse,difflib,hashlib,json,shutil,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--rebuild',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parent;repo=Path('/home/helloworld0822/coding/forge')
source=root/'source';source.mkdir(exist_ok=True)
for name in ['compiler','tests']:
 shutil.copytree(repo/name,source/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ['CMakeLists.txt','examples/hello.fg','bootstrap/compiler.fg','docs/design-principles.md','ARCHITECTURE.md','LICENSE']:
 path=source/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,path)
shutil.copytree(repo/'build/include',root/'sdk/include',dirs_exist_ok=True)
(root/'sdk/lib').mkdir(exist_ok=True)
for name in ['libforge_std.a','libforge_runtime.a','forge.link']:shutil.copyfile(repo/'build/lib'/name,root/'sdk/lib'/name)
for component in ['runtime','stdlib']:
 target=root/'sdk'/component;target.mkdir(exist_ok=True)
 for name in ['LICENSE','NOTICE']:
  src=repo.parent/('forge-'+component)/name
  if src.exists():shutil.copyfile(src,target/name)
paths=['CMakeLists.txt','compiler/semantic.c','compiler/const_index.h','tests/const_index_test.c','tests/const_lookup_bench.py']
parts=[]
for path in paths:
 before=root/'baseline-source'/path;after=source/path
 parts.append('diff --git a/'+path+' b/'+path+'\n')
 if not before.exists():parts.append('new file mode 100644\n')
 parts.extend(difflib.unified_diff(before.read_text().splitlines(keepends=True) if before.exists() else [],after.read_text().splitlines(keepends=True),fromfile='a/'+path if before.exists() else '/dev/null',tofile='b/'+path))
(root/'compiler-incremental.patch').write_text(''.join(parts))
with tempfile.TemporaryDirectory(prefix='const-patch-',dir='/dev/shm') as folder:
 shutil.copytree(root/'baseline-source',folder,dirs_exist_ok=True)
 subprocess.run(['git','apply','--check',str(root/'compiler-incremental.patch')],cwd=folder,check=True)
 subprocess.run(['git','apply',str(root/'compiler-incremental.patch')],cwd=folder,check=True)
 assert all((Path(folder)/path).read_bytes()==(source/path).read_bytes() for path in paths)
(root/'patch-check.json').write_text(json.dumps({'files_applied_and_matched':paths,'baseline':'before-change compiler/CMake working-tree snapshot','public_tests':'Full final files retained separately; previous public-test bodies are not part of this replay.'},indent=2)+'\n')
if args.rebuild:
 order=['main','source','lexer','parser','ast','semantic','codegen','codegen_js','mod_registry','module_loader','symbols','optimize','driver'];results=[]
 for label,src in [('baseline',root/'baseline-source/compiler'),('candidate',source/'compiler')]:
  target=root/('reconstructed-'+label)
  command=['cc','-O3','-DNDEBUG','-std=c11','-Wall','-Wextra','-I',str(src),'-I',str(root/'sdk/include')]+[str(src/(name+'.c')) for name in order]+[str(root/'sdk/lib/libforge_runtime.a'),'-o',str(target)]
  result=subprocess.run(command,capture_output=True,text=True);assert result.returncode==0,result.stderr
  expected=hashlib.sha256((root/('forge-'+label)).read_bytes()).hexdigest();actual=hashlib.sha256(target.read_bytes()).hexdigest()
  results.append({'label':label,'command':command,'stdout':result.stdout,'stderr':result.stderr,'expected':expected,'actual':actual,'equal':actual==expected})
 (root/'reconstruction.json').write_text(json.dumps(results,indent=2)+'\n')
 assert all(r['equal'] for r in results),results
(root/'REPRODUCE.md').write_text('''# Retained compiler experiment

This baseline is the previous function/local-index working tree, not clean HEAD.
The archive contains the before-change compiler/CMake snapshot, final source,
23-row paired measurements, generated inputs/outputs, exact commands, both
compiler binaries, a common Release SDK and the incremental patch. The final
public tests are retained in full; their pre-change bodies are outside the
incremental patch replay. The patch reconstructs its five affected files exactly.

On the recorded Linux x86_64 host, from this extracted directory:

```
python3 source/tests/const_lookup_bench.py --baseline "$PWD/forge-baseline" --candidate "$PWD/forge-candidate" --root "$PWD/sdk" --output "$PWD/new-measurement" --cpu 2 --pairs 24
python3 differential.py
```

The original differential.py records the session's absolute SDK path; change
that one sdk assignment to the extracted sdk directory to run elsewhere. Both
compiler variants must use the same SDK and source paths. Timing uses CLI wall
clock, one excluded warmup pair, alternating AB/BA order, no concurrent builds,
and byte equality checks for every successful C/JS output pair. CPU 2 describes
the measured host; choose a supported CPU consistently on a different machine.

reconstruction.json records standalone builds of both complete compiler source
snapshots in the same source/link order and with the same Release flags as CMake,
using the retained common runtime archive. They reconstruct both measured ELF
binaries byte for byte on this host. The exact CMake commands are also retained.

The instrumented baseline profile was built separately:

```
cc -std=c11 -O3 -g -pg -DNDEBUG -I compiler -I build/include compiler/*.c build/lib/libforge_runtime.a -pthread -lm -o forge-profile
GMON_OUT_PREFIX=/absolute/gmon taskset -c 2 /absolute/forge-profile /absolute/last-16384.fg --check --forge-root /absolute/build
# Pass the actual generated gmon.PID file to gprof.
```

The measured Release compilers do not use -pg. Full CTest, rebuilt self-host
fixed-point output and sanitizer logs belong to the actual local dependency
checkout. The SDK's local stdlib HTTP fix is based on its pinned revision, and
is unchanged between compilers; see environment.json. No source revision is
published or dependency pin updated by this archive. Sources and static archives
retain their component license notices under sdk/runtime and sdk/stdlib.
''')
manifest={}
for path in sorted(root.rglob('*')):
 if path.is_file() and path.name!='manifest.json':manifest[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Patch replay matched;',len(manifest),'files hashed.')
