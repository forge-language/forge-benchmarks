import hashlib,json,os,random,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent;work=root/'differential';work.mkdir(exist_ok=True)
sdk=Path('/home/helloworld0822/coding/forge/build');rng=random.Random(20261015)
cases=[]
for seed in range(36):
 n=[0,1,16,17,65,257][seed%6]
 declarations=[(f'K_{i:03d}',str(i)) for i in range(n)]
 rng.shuffle(declarations)
 constants=''.join(f'const {name}={value};' for name,value in declarations)
 reads=[rng.randrange(n) for _ in range(20)] if n else []
 functions=''.join(f'fn f_{i}():int{{return K_{q:03d};}}' for i,q in enumerate(reads))
 code=constants+functions+'native main{'+''.join(f'{{let K_{q:03d}:string="local";println(K_{q:03d});}}println(K_{q:03d});' for q in reads[:3])+'return 0;}'
 cases.append(('literal-shuffle-'+str(seed),code,{}))
padding=''.join(f'const K_{i}={i};' for i in range(80))
warm=''.join(f'fn warm_{i}():int{{return K_79;}}' for i in range(20))
for n in [16,17,80,257]:
 prefix=''.join(f'const K_{i}={i};' for i in range(n))
 warmn=''.join(f'fn warm_{i}():int{{return K_{n-1};}}' for i in range(20))
 for text in ['const FIRST=LAST;const LAST=7;','const FIRST=LAST;const LAST=FIRST;',
              'const X=7;const X="later";','const X="first";const X=7;',
              'const FIRST=missing;','const FIRST=7;fn FIRST(x:int):int{return x;}']:
  suffix='native main{return FIRST;}' if 'FIRST' in text else 'native main{let v:int=X;return 0;}'
  cases.append((f'aliases-duplicates-{n}',prefix+text+warmn+suffix,{}))
for body in ['fn bad(SOURCE:string):int{return COPY;}native main{return 0;}',
             'native main{let SOURCE:string;println(COPY);return 0;}',
             'native main{own let SOURCE:string="owned";send 0,Drop,move SOURCE;println(COPY);return 0;}',
             'fn okay(SOURCE:int):int{return COPY;}native main{return 0;}']:
 cases.append(('context',padding+'const SOURCE=7;const COPY=SOURCE;'+warm+body,{}))
for order in [('left','right'),('right','left')]:
 for value in ['7','"text"']:
  modules={'left.fg':padding+'const PICK='+value+';fn read():int{return K_79;}',
           'right.fg':'const PICK=9;fn read():int{return 9;}'}
  cases.append(('import-order',''.join('import '+name+';' for name in order)+warm+'native main{let p:int=PICK;return 0;}',modules))
for n in [17,80,257]:
 prefix=''.join(f'const K_{i}={i};' for i in range(n))
 code='extern fn foreign(callback:int):int;fn callback(x:int):int{return x;}'
 code+=''.join(f'fn call_{i}():int{{return foreign(callback);}}' for i in range(20))+'native main{return 0;}'
 cases.append(('callback-misses',prefix+code,{}))
for source in [padding+warm+'native main{return missing;}',padding+'const BAD=unknown;'+warm+'native main{return 0;}',padding+warm+'native main{let x:string=K_79;return 0;}']:
 cases.append(('diagnostic',source,{}))
os.sched_setaffinity(0,{4});rows=[]
for number,(name,code,files) in enumerate(cases):
 folder=work/f'{number:03d}';folder.mkdir(exist_ok=True);path=folder/'main.fg';path.write_text(code)
 for filename,text in files.items():(folder/filename).write_text(text)
 modes=[]
 for mode in ['--check','--emit-c','--emit-js']:
  values=[]
  for label in ['baseline','candidate']:
   output=folder/(label+('.js' if mode=='--emit-js' else '.c'))
   cmd=[str(root/('forge-'+label)),str(path),mode,'--diagnostics-json','--forge-root',str(sdk)]
   if mode!='--check':cmd+=['-o',str(output)]
   p=subprocess.run(cmd,capture_output=True,timeout=15)
   value={'returncode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
   if p.returncode==0 and mode!='--check':value['output_sha256']=hashlib.sha256(output.read_bytes()).hexdigest()
   values.append(value)
  assert values[0]==values[1],(number,name,mode,values)
  modes.append({'mode':mode,**values[0]})
 rows.append({'case':number,'shape':name,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'modes':modes})
(work/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('differential cases',len(rows),'checks',sum(len(x['modes']) for x in rows),'accepted checks',sum(x['modes'][0]['returncode']==0 for x in rows))
