from pathlib import Path
import shutil,re
p=Path(__file__).resolve().parent;dest=p/'split-runtime';shutil.copytree(p/'candidate-runtime',dest,dirs_exist_ok=True)
original=(p/'baseline-runtime/src/work_queue.c').read_text();legacy=original;cores=[]
functions=[('fr_run_queue_try_push','fr_queue_core_push_run','fr_run_queue_t *q, fr_coro_t *coro'),('take_run','fr_queue_core_take_run','fr_run_queue_t *q, int steal'),('fr_native_queue_try_push','fr_queue_core_push_native','fr_native_queue_t *q, fr_native_fn fn, void *arg'),('take_native','fr_queue_core_take_native','fr_native_queue_t *q, void **arg_out, int steal')]
for old,new,parameters in functions:
 m=re.search(r'^.*\b'+old+r'\([^;\n]*\) \{',legacy,re.M);assert m,old
 start=m.start();opening=legacy.index('{',start);depth=1;end=opening+1
 while depth:
  if legacy[end]=='{':depth+=1
  elif legacy[end]=='}':depth-=1
  end+=1
 text=legacy[start:end];prefix=text[:text.index(old)];body=text[text.index('{'):]
 ret=prefix.removeprefix('static ')
 core='static inline '+ret+new+'('+parameters+', int locked) '+body
 core=core.replace('fr_mutex_lock(q->lock);','if (locked) fr_mutex_lock(q->lock);').replace('fr_mutex_unlock(q->lock);','if (locked) fr_mutex_unlock(q->lock);').replace('NODE_CACHE_LIMIT','FR_QUEUE_NODE_CACHE_LIMIT')
 cores.append(core)
 arguments={'fr_run_queue_try_push':'q, coro','take_run':'q, steal','fr_native_queue_try_push':'q, fn, arg','take_native':'q, arg_out, steal'}[old]
 replacement=prefix+old+'('+parameters+') {\n    return '+new+'('+arguments+', 1);\n}'
 legacy=legacy[:start]+replacement+legacy[end:]
legacy=legacy.replace('#include "work_queue.h"\n#include <stdlib.h>\n\n/* Bound retained memory independently of a queue\'s peak backlog. */\n#define NODE_CACHE_LIMIT 256','#include "work_queue_core.h"')
(dest/'src/work_queue.c').write_text(legacy)
(dest/'src/work_queue_core.h').write_text('#ifndef FORGE_WORK_QUEUE_CORE_H\n#define FORGE_WORK_QUEUE_CORE_H\n\n#include "work_queue.h"\n#include <stdlib.h>\n\n/* Shared structural core. Callers pass a literal lock policy: standalone 1,\n * externally serialized 0. Separate objects keep unused owner entry points\n * out of standalone consumers. Overflow nodes are freed after private unlock. */\n#define FR_QUEUE_NODE_CACHE_LIMIT 256\n\n'+'\n\n'.join(cores)+'\n\n#endif\n')
(dest/'src/work_queue_owned.c').write_text('''#include "work_queue_core.h"

int fr_run_queue_try_push_owned(fr_run_queue_t *q, fr_coro_t *coro) {
    return fr_queue_core_push_run(q, coro, 0);
}
fr_coro_t *fr_run_queue_pop_owned(fr_run_queue_t *q) {
    return fr_queue_core_take_run(q, 0, 0);
}
fr_coro_t *fr_run_queue_steal_owned(fr_run_queue_t *q) {
    return fr_queue_core_take_run(q, 1, 0);
}
int fr_native_queue_try_push_owned(fr_native_queue_t *q, fr_native_fn fn, void *arg) {
    return fr_queue_core_push_native(q, fn, arg, 0);
}
fr_native_fn fr_native_queue_pop_owned(fr_native_queue_t *q, void **arg_out) {
    return fr_queue_core_take_native(q, arg_out, 0, 0);
}
fr_native_fn fr_native_queue_steal_owned(fr_native_queue_t *q, void **arg_out) {
    return fr_queue_core_take_native(q, arg_out, 1, 0);
}
''')
f=dest/'CMakeLists.txt';s=f.read_text().replace('src/ownership.c src/platform.c src/thread.c)','src/ownership.c src/platform.c src/thread.c src/work_queue_owned.c)');f.write_text(s)
