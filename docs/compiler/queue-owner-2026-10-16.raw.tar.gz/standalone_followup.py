import json,subprocess,csv,io,itertools
from pathlib import Path
import dispatch_compare
p=Path(__file__).resolve().parent
variants=['baseline','candidate','order'];permutations=list(itertools.permutations(variants));rows=[]
def invoke(label):
 cmd=['taskset','-c','0',str(p/f'standalone-{label}'),'100000']
 r=subprocess.run(cmd,check=True,capture_output=True,text=True,timeout=30)
 cells={r['operation']+':'+r['size']:float(r['best_ns_per_operation']) for r in csv.DictReader(io.StringIO(r.stdout))};assert len(cells)==8
 return dict(command=cmd,stdout=r.stdout,stderr=r.stderr,cells=cells)
warm={v:invoke(v) for v in variants}
for i in range(24):
 order=permutations[i%6];row={'order':order}
 for v in order:row[v]=invoke(v)
 rows.append(row)
results=[]
for candidate in ['candidate','order']:
 for key in warm['baseline']['cells']:
  samples=[{'baseline':{'time':r['baseline']['cells'][key]},'candidate':{'time':r[candidate]['cells'][key]}} for r in rows]
  results.append(dict(variant=candidate,case=key,paired=dispatch_compare.paired(samples,'time')))
(p/'standalone-followup.json').write_text(json.dumps(dict(method='balanced six permutations,24 triples,excluded warmups,legacy within-process best-of-five',warmups=warm,samples=rows,results=results),indent=2)+'\n')
for r in results:print(r)
