# Queue ownership audit

Capture 2026-10-16. Root HEAD a750b60923bcc71adda025596664dd9a0413f80b, tree ba5b4dc; runtime base dcbb1929b17c2f1d11fd367ecf80c7c87c58a274. These bases do not identify unpublished content: queue-source-manifest.json plus final-runtime/source-project snapshots bind the actual working sources.

Root inspected final work_queue_core.h, both wrapper TUs, private work_queue.h, the complete scheduler queue-access search and caller contexts, owner protocol test, standalone behavior test, final CMake wrapper/timeout registrations and full final result tables. No required production defect found in this slice.

Owner path table is in the canonical queue-owner report. Initialization is unpublished, destruction follows stop/join under exclusive caller lifetime, and every other private head/count/cache/claim/publication path holds sched->lock. No standalone queue API remains in scheduler live operations. Debug inventory runs under the owner. Callbacks and depth re-entry run after owner unlock. Core preserves empty arg_out, null native callback rejection, failed allocation, FIFO/tail stealing and cap 256; overflow free follows conditional private unlock. Separate owned object is last in static archive and is not installed as a header contract.

Current src/include match the tested candidate-runtime byte-for-byte, and CMakeLists matches. Only queue_owner_test differs: stronger phase-local assertions for both steals and final inner-lock check. Those exact changes have passing Release/ASan test logs. Current build/bin/queue_owner_test directly prints all six owned-call counters positive and private mutex locks 0. Final SDK lib SHA256 equals measured candidate 9684329ddf09a4c874c2479df110eabefc24706346941263c53e0e3af1734338.

Baseline/candidate installed public headers compare equal. Legacy work_queue.c.o cmp exits zero. Full standalone executable SHA256 equal bdd3d41cba810ebb34faddf4fdc017db2535ac02f59f12358266461f67ce97a5. This is GCC13.3 Release without LTO evidence, not universal linkage equivalence.

Both missing-owner and nested-lock negative-control logs contain actual intended assertion failures with exit 1. They are initial-variant mutants, honestly labeled; the final split shares the structural semantics but no claim of final-source mutation reruns is made. Protocol registration remains Linux constructor-order-dependent and fail-loud. No TSan pass exists (prior host initialization failed).

All 64 final rows were parsed: 24 measured pairs per row, 3,072 measured invocations and 128 warmup invocations. Frozen binary hashes, affine-oracle checksum, actual CPU masks and per-worker sums were checked for every sample. The report includes all rows, both batches separately, total time and p99 intervals, plus explicit adverse blocked/1024 tails. Throughput candidate accepted with this measured latency tradeoff; no uniform latency/fairness/HTTP claim.

Completed OMO source and final JSONL reviews have terminal reason stop. Their text is secondary evidence: final reviewer incorrectly calls private work_queue.h public, calls existing arg_out guard an addition, and summarizes negative rows too loosely. Root checked actual baseline/source/table instead; report states the accurate private-header contract and specific adverse intervals. No incomplete quota-failed discovery lane counts as approval.

Pre-existing limitations are documented: total worker-start failure, non-NULL terminal coroutine after enqueue allocation failure, independent self-host constructor guards. Pins stay on published versions. No commit: partially reviewed cross-repository WIP remains reviewable, with exact source/artifact snapshots.
