## Verdict

The production diff is sound. I found **no introduced bug in `work_queue.c/h`, `scheduler.c`, or the wrap retargeting**, given the stated invariant (all six scheduler callsites run under `sched->lock`). Reasoning below, then concrete test flaws.

## Preservation checks (all hold)

- **Empty `arg_out`**: `take_native_node` returns `NULL` before touching `*arg_out` (baseline early-return preserved). Callers init `narg = NULL`. Asserted at both layers (`test_owned_operations`, `queue_owner` empty pop/steal with sentinel `&items[999]`).
- **FIFO pop / tail steal**: `take_run_node(q, steal)` head/tail selection is byte-identical to baseline; thief param was already ignored. The alternating interleave (`expected = i&1 ? 999-i/2 : i/2`) correctly exercises both unlink cases (head-only, tail-only, mid) through saturation.
- **Failure returns**: push failure path mutates no state (free-node branch can't fail; malloc failure occurs before link) → returns 0. Native NULL-fn rejected before any locking in both wrappers, matching baseline's pre-lock check.
- **Cache saturation**: recycle-cap logic lives in the shared cores untouched; `free_count == 256` asserted after 1000-push/1000-pop on both queues, then re-verified after the standalone/owned switch.
- **Ownership**: owned ops never touch `q->lock`; standalone wrappers still lock around the identical core, so no behavioral drift between APIs.
- **Unlock/free order**: locked `take_run`/`take_native` unlock **then** free retired nodes — exactly baseline's order (free-after-unwrap preserved for cache overflow). Owned variants free under external-owner exclusion only.
- **`count` reads**: standalone `fr_native_queue_count` still locks; scheduler's two direct `.count` reads happen under `sched->lock` (lock taken in unchanged prologue, unlocked in-hunk), so the `queued <= native_pending` assert still sees a consistent snapshot.
- **Constructor**: unchanged; `q->lock` is created for every published queue and validated in the failure path — the owned contract's precondition holds for any scheduler the caller can obtain.

## Wrap retargeting

CMake `--wrap` lists match the test symbols exactly (queue_owner: 12 wraps = 6 infra + 6 owned; test defines all 12). dispatch/lifecycle now inject failures through the **owned** symbols the scheduler actually calls (line 184 wake push; line 453 submit push) — the only such callsites in `scheduler.c` — so the old `failed_pushes`/batch-limit assertions still fire. `work_queue_test` gets no wraps, as intended.

## What the TLS lock-event test genuinely proves

`guard()` runs on the calling thread before each real op and checks: queue lock registered at construction, **owner held by this thread**, queue lock **not** held — for all six ops, including the failure paths (failed submit push, inert-terminal spawn push both route through wrapped owned pushes). `inner_locks` counts *any* acquisition of a registered queue mutex by *any* thread, so both misuse directions are caught: owned-without-owner (guard abort) and standalone-under/no-lock (`inner_locks > 0`). Callbacks assert `!is_held(owner)` *before* calling `fr_sched_pool_queued`, which re-acquires the owner — proving callbacks run outside the owner and that reentry into scheduler API is safe; `< 10000` bounds reentry backlog (peak possible ≈4001, safe). `skip_first` kills worker 0 with queue 0 preloaded; native-steal determinism holds regardless of the earlier failed submit because `next_queue++` still round-robins the four tasks across queues 1,2,3,**0**. `malloc_failures == 4` matches exactly two injections × two exercises; `completed == 4001+workers` accounting is exact; `items[4000]/[4001]` non-execution and `held_count == 0` after destroy are checked. Registration itself has **no data race**: `constructing` is TLS, the constructor starts no threads, maps are immutable after publication, thread creation happens-before worker reads, `held[]` is per-thread, counters are atomic.

## Concrete flaws

1. **Run-steal assertion is not deterministically forced.** The comment claims "queue zero is nonempty; first failed worker forces both steal functions" — but queue 0's guaranteed occupancy covers the *native* queue only. The sole phase-1 coroutine (`items[4009]`) lands in queue `proc->worker_id % worker_count`; nothing in the shown test or constructor guarantees that equals the failed worker 0. If it doesn't, `owned_calls[2] > 0` (run steal) rests on probabilistic phase-2 contention (2001-yield requeues make it likely, not guaranteed) → potential flake.
2. **Owner identification is coupled to constructor mutex-creation order.** `owner = first fr_mutex_create()` during `constructing`, but the constructor creates `event_loop` *before* `s->lock`. If `fr_event_loop_create`/`fr_cond_create` ever creates a mutex through `fr_mutex_create`, `private_count == 2*workers` and every `guard()` break. Loud (CHECK), not silent — but brittle registration that must be touched whenever a pre-`s->lock` mutex source is added.
3. **Nested-lock regression manifests as a hang, not a red test.** `test_owned_operations` deliberately holds `q->lock` so an accidental inner lock deadlocks; CMake sets `TIMEOUT` only for `lifecycle_regressions` — `work_queue_test` has no visible timeout, so a regression stalls CI rather than failing.
4. **`inner_locks == 0` is asserted before `fr_scheduler_destroy`**, so destroy-time queue-mutex use (explicitly permitted by the header contract: "Init/destroy still own a valid queue mutex") is outside the zero-lock claim. Fine, but the guarantee is scoped to pre-destroy runtime only.
5. Phase 1 presumes the scheduler runs with `worker_count - 1` threads after a failed `fr_thread_start` (existing `workers_started` accounting) — the test depends on that tolerance; no new start-fallback behavior is introduced or claimed here.

Per instructions: no claim about NULL queue locks (mutex NULL lock is an intentional no-op; constructor rejection is a prior-stage fix), no fallback/bootstrap claims, no repo-wide audit — findings are confined to this diff and its tests.
