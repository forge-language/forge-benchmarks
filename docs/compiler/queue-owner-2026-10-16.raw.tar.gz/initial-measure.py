from pathlib import Path
import subprocess,json,sys,csv,io
import dispatch_compare as compare
p=Path(__file__).resolve().parent
for name,extra in [('dispatch-primary',[]),('dispatch-reverse',['--candidate-first'])]:
    cmd=[sys.executable,str(p/'dispatch_compare.py'),'--baseline',str(p/'dispatch-baseline'),'--candidate',str(p/'dispatch-candidate'),'--output',str(p/name),'--pairs','24','--workers','1','4','8','12','--steps','16','1024',*extra]
    with (p/(name+'.log')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)

# Whole-process lock counts are diagnostic only; timing of these binaries is discarded.
records=[]
for workers in [1,4,8,12]:
    for mode in ['native','blocked','coro','mixed']:
        for variant in ['baseline','candidate']:
            cmd=['taskset','-c',','.join(map(str,range(workers))),str(p/f'dispatch-{variant}-instrumented'),mode,str(workers),'20000','16','1009']
            run=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=30)
            d=json.loads(run.stdout);assert d['checksum']==compare.oracle(20000,16,1009)
            line=[s for s in run.stderr.splitlines() if s.startswith('queue-lock-probe:')];assert len(line)==1
            counts=dict((key,int(value)) for key,value in (piece.split('=') for piece in line[0].split()[1:]))
            assert counts['registered']==workers*2 and counts['owner']>0
            assert counts['private']==0 if variant=='candidate' else counts['private']>=40000
            records.append(dict(variant=variant,workers=workers,mode=mode,command=cmd,stdout=run.stdout,stderr=run.stderr,counts=counts))
(p/'lock-counts.json').write_text(json.dumps(records,indent=2)+'\n')

# Legacy standalone fixture: each printed cell is its within-process best of 5.
# Pair those cells across separate AB/BA invocations; do not call them medians.
report=dict(pairs=24,method='taskset CPU0, alternating AB/BA, excluded warmup pair, each legacy cell best of five, standalone single-threaded controls only',warmups={},samples=[],results=[])
def standalone(variant):
    cmd=['taskset','-c','0',str(p/f'standalone-{variant}'),'100000']
    r=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=30)
    cells={row['operation']+':'+row['size']:float(row['best_ns_per_operation']) for row in csv.DictReader(io.StringIO(r.stdout))}
    assert len(cells)==8 and all(value>0 for value in cells.values())
    return dict(command=cmd,stdout=r.stdout,stderr=r.stderr,cells=cells)
for v in ['baseline','candidate']:report['warmups'][v]=standalone(v)
for i in range(24):
    order=['baseline','candidate'] if i%2==0 else ['candidate','baseline']
    sample={'order':order}
    for v in order:sample[v]=standalone(v)
    report['samples'].append(sample)
for key in report['warmups']['baseline']['cells']:
    values=[{v:{'time':sample[v]['cells'][key]} for v in ['baseline','candidate']} for sample in report['samples']]
    report['results'].append(dict(case=key,paired=compare.paired(values,'time')))
(p/'standalone-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print('two full dispatch batches, diagnostic locks and standalone controls complete')
