#include "forge_runtime.h"
#include "work_queue.h"
#include "forge/event.h"
#include "forge/platform.h"
#include "forge/thread.h"
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>
#include <assert.h>

static char *fr_strdup(const char *s) {
    size_t n = strlen(s);
    char *out = (char *)malloc(n + 1);
    if (!out) return NULL;
    memcpy(out, s, n + 1);
    return out;
}

#define MAILBOX_CAP 256

typedef struct fr_mailbox {
    fr_msg_t msgs[MAILBOX_CAP];
    size_t head;
    size_t tail;
    size_t count;
} fr_mailbox_t;

struct fr_coro {
    int id;
    fr_coro_fn fn;
    void *state;
    size_t state_size;
    fr_coro_status_t status;
    int step;
    int on_queue;
    int executing;
    int counted_active;
    int counted_io;
    fr_process_t *proc;
    int await_fd;
    uint32_t await_events;
    int await_ready;
    struct fr_coro *next;
    fr_arena_t *arena;
};

struct fr_process {
    char *name;
    fr_scheduler_t *sched;
    fr_mailbox_t mailbox;
    fr_coro_t *coros;
    fr_coro_t *coro_tail;
    int next_coro_id;
    fr_coro_fn receive_handler;
    size_t receive_state_size;
    int is_supervisor;
    fr_restart_policy_t restart_policy;
    fr_process_t **children;
    size_t child_count;
    int worker_id;
    fr_mutex_t *lock;
    fr_cond_t *msg_cond;
    struct fr_process *next;
};

struct fr_scheduler {
    fr_process_t *processes;
    int worker_count;
    atomic_int running;
    atomic_int workers_started;
    int stopping;
    size_t runnable;
    size_t active_coros;
    size_t waiting_io;
    unsigned next_queue;
    unsigned next_worker;
    int native_pending;
    /* -1 leaves unobserved pools untracked. First multi-worker query derives the
     * claimed count from pending minus queued, under lock; later claims and
     * completions maintain it. Stop retains both the ledger and backlog. */
    int native_executing;
    fr_thread_t **workers;
    fr_run_queue_t *worker_queues;
    fr_native_queue_t *native_queues;
    fr_event_loop_t *event_loop;
    fr_mutex_t *lock;
    fr_cond_t *idle_cond;
    fr_cond_t *state_cond;
};

static _Thread_local fr_coro_t *tls_current_coro = NULL;
static _Thread_local int tls_worker_id = -1;
static _Thread_local fr_scheduler_t *tls_worker_scheduler = NULL;
static _Thread_local int *tls_reductions_remaining = NULL;
static _Atomic(fr_scheduler_t *) g_global_sched = NULL;

fr_coro_t *fr_coro_current(void) {
    return tls_current_coro;
}

fr_arena_t *fr_coro_get_arena(fr_coro_t *coro) {
    if (!coro) return NULL;
    if (!coro->arena) coro->arena = fr_arena_create(0);
    return coro->arena;
}

static fr_arena_t *scheduler_coro_arena_provider(void) {
    return fr_coro_get_arena(tls_current_coro);
}

fr_scheduler_t *fr_scheduler_global(void) {
    return g_global_sched;
}

void fr_scheduler_set_global(fr_scheduler_t *sched) {
    g_global_sched = sched;
}

int fr_sched_pool_available(void) {
    fr_scheduler_t *sched = g_global_sched;
    return sched && sched->running && sched->workers_started;
}

static int default_worker_count(int n) {
    if (n > 0) return n;
    long cpus = fr_platform_available_cpu_count();
    return cpus > 0 ? (int)cpus : 4;
}

static int mailbox_push(fr_mailbox_t *mb, fr_msg_t msg) {
    if (mb->count >= MAILBOX_CAP) return 0;
    mb->msgs[mb->tail] = msg;
    mb->tail = (mb->tail + 1) % MAILBOX_CAP;
    mb->count++;
    return 1;
}

static int mailbox_pop(fr_mailbox_t *mb, fr_msg_t *out) {
    if (mb->count == 0) return 0;
    *out = mb->msgs[mb->head];
    mb->head = (mb->head + 1) % MAILBOX_CAP;
    mb->count--;
    return 1;
}

/* All contribution changes happen under sched->lock, including await while
 * executing and readiness published before the invocation returns. */
static void refresh_coro_counts_locked(fr_scheduler_t *sched, fr_coro_t *coro) {
    int active = coro->executing ||
        (coro->status != FR_CORO_DONE && coro->status != FR_CORO_ERROR);
    int io = coro->status == FR_CORO_WAITING_IO &&
        coro->await_fd >= 0 && !coro->await_ready;
    if (active != coro->counted_active) {
        if (active) sched->active_coros++;
        else sched->active_coros--;
        coro->counted_active = active;
    }
    if (io != coro->counted_io) {
        if (io) sched->waiting_io++;
        else sched->waiting_io--;
        coro->counted_io = io;
    }
}

static void notify_completion_locked(fr_scheduler_t *sched);

#ifndef NDEBUG
static void check_dispatch_inventory_locked(fr_scheduler_t *sched) {
    size_t coroutines = 0, native = 0;
    for (int i = 0; i < sched->worker_count; i++) {
        coroutines += sched->worker_queues[i].count;
        native += sched->native_queues[i].count;
    }
    assert(coroutines <= sched->active_coros);
    assert(coroutines + native == sched->runnable);
}
#else
#define check_dispatch_inventory_locked(sched) ((void)0)
#endif

/* Scheduler state and queue publication share this mutex. A running coroutine
 * stays exclusively owned by its worker until the worker commits its result. */
static void enqueue_coro_locked(fr_scheduler_t *sched, fr_coro_t *coro) {
    if (!coro || coro->on_queue || coro->executing) return;
    if (coro->status != FR_CORO_RUNNING) return;
    int wid = coro->proc->worker_id % sched->worker_count;
    if (!fr_run_queue_try_push_owned(&sched->worker_queues[wid], coro)) {
        coro->status = FR_CORO_ERROR;
        refresh_coro_counts_locked(sched, coro);
        /* A failed wake can retire the last active coroutine while the run
         * controller sleeps. Publish that completion even without a worker. */
        notify_completion_locked(sched);
        check_dispatch_inventory_locked(sched);
        return;
    }
    coro->on_queue = 1;
    sched->runnable++;
    check_dispatch_inventory_locked(sched);
    fr_cond_signal(sched->idle_cond);
}

static void event_resume_cb(fr_event_loop_t *loop, int fd, uint32_t events, void *userdata) {
    (void)loop;
    (void)fd;
    (void)events;
    fr_coro_t *coro = (fr_coro_t *)userdata;
    if (!coro || !coro->proc || !coro->proc->sched) return;
    fr_scheduler_t *sched = coro->proc->sched;
    fr_mutex_lock(sched->lock);
    if (coro->await_fd >= 0) {
        coro->await_ready = 1;
        if (!coro->executing && coro->status == FR_CORO_WAITING_IO) {
            coro->status = FR_CORO_RUNNING;
            enqueue_coro_locked(sched, coro);
        }
        refresh_coro_counts_locked(sched, coro);
    }
    fr_mutex_unlock(sched->lock);
}

#define FR_REDUCTION_BUDGET 2000

static void scan_enqueue_runnable(fr_scheduler_t *sched) {
    for (fr_process_t *p = sched->processes; p; p = p->next) {
        for (fr_coro_t *c = p->coros; c; c = c->next)
            enqueue_coro_locked(sched, c);
    }
}

typedef struct {
    fr_scheduler_t *sched;
    int wid;
} fr_worker_arg_t;

/* The run-loop predicate needs a completion wake only when all work is done.
 * I/O registration has its own wake, and stop still broadcasts to all waiters.
 * Test this predicate while holding the same mutex as fr_scheduler_run. */
static void notify_completion_locked(fr_scheduler_t *sched) {
    if (sched->active_coros == 0 && sched->native_pending == 0)
        fr_cond_signal(sched->state_cond);
}

static void *worker_main(void *arg) {
    fr_worker_arg_t *wa = (fr_worker_arg_t *)arg;
    fr_scheduler_t *sched = wa->sched;
    int wid = wa->wid;
    free(wa);

    /* Keep the creator's affinity. CPU ordinals are not CPU IDs in a sparse
     * mask; placement policy belongs to the caller and the OS scheduler. */
    tls_worker_id = wid;
    tls_worker_scheduler = sched;

    for (;;) {
        fr_mutex_lock(sched->lock);
        check_dispatch_inventory_locked(sched);
        while (sched->running && sched->runnable == 0)
            fr_cond_wait(sched->idle_cond, sched->lock);
        if (!sched->running) { fr_mutex_unlock(sched->lock); break; }

        fr_coro_t *coro = NULL;
        /* Only this scheduler can access these queue objects, and all its
         * publication/claim paths hold sched->lock. A head peek is therefore
         * stable through the owner-serialized queue operation below. The private
         * queue mutex is redundant here; standalone queue APIs still lock. */
        if (sched->active_coros > 0) {
            if (sched->worker_queues[wid].head)
                coro = fr_run_queue_pop_owned(&sched->worker_queues[wid]);
            if (!coro) {
                for (int i = 0; i < sched->worker_count; i++) {
                    if (i == wid || !sched->worker_queues[i].head) continue;
                    coro = fr_run_queue_steal_owned(&sched->worker_queues[i]);
                    if (coro) break;
                }
            }
        }
        if (coro) {
            sched->runnable--;
            coro->on_queue = 0;
            coro->executing = 1;
            fr_mutex_unlock(sched->lock);
            fr_coro_status_t status = FR_CORO_RUNNING;
            int budget = FR_REDUCTION_BUDGET;
            tls_current_coro = coro;
            tls_reductions_remaining = &budget;
            while (budget-- > 0 && sched->running) {
                status = coro->fn(coro, coro->state);
                if (status == FR_CORO_YIELDED) status = FR_CORO_RUNNING;
                if (status != FR_CORO_RUNNING) break;
            }
            tls_reductions_remaining = NULL;
            tls_current_coro = NULL;
            fr_mutex_lock(sched->lock);
            coro->executing = 0;
            if (status == FR_CORO_WAITING_IO && coro->await_ready)
                status = FR_CORO_RUNNING;
            if (status == FR_CORO_WAITING_RECV) {
                fr_mutex_lock(coro->proc->lock);
                if (coro->proc->mailbox.count > 0) status = FR_CORO_RUNNING;
                fr_mutex_unlock(coro->proc->lock);
            }
            coro->status = status;
            refresh_coro_counts_locked(sched, coro);
            enqueue_coro_locked(sched, coro);
            notify_completion_locked(sched);
            fr_mutex_unlock(sched->lock);
            continue;
        }

        void *narg = NULL;
        fr_native_fn nfn = NULL;
        if (sched->native_queues[wid].head)
            nfn = fr_native_queue_pop_owned(&sched->native_queues[wid], &narg);
        if (!nfn) {
            for (int i = 0; i < sched->worker_count; i++) {
                if (i == wid || !sched->native_queues[i].head) continue;
                nfn = fr_native_queue_steal_owned(&sched->native_queues[i], &narg);
                if (nfn) break;
            }
        }
        if (nfn) {
            sched->runnable--;
            if (sched->native_executing >= 0) sched->native_executing++;
            fr_mutex_unlock(sched->lock);
            nfn(narg);
            fr_mutex_lock(sched->lock);
            /* A query can activate tracking while this callback runs. */
            if (sched->native_executing >= 0) {
                assert(sched->native_executing > 0);
                sched->native_executing--;
            }
            sched->native_pending--;
            notify_completion_locked(sched);
        }
        fr_mutex_unlock(sched->lock);
    }
    tls_worker_id = -1;
    tls_worker_scheduler = NULL;
    return NULL;
}

fr_scheduler_t *fr_scheduler_create(int worker_count) {
    fr_scheduler_t *s = (fr_scheduler_t *)calloc(1, sizeof(fr_scheduler_t));
    if (!s) return NULL;
    atomic_init(&s->running, 0);
    atomic_init(&s->workers_started, 0);
    s->native_executing = -1;
    s->worker_count = default_worker_count(worker_count);
    s->event_loop = fr_event_loop_create();
    if (s->event_loop) fr_event_loop_set_cb(s->event_loop, event_resume_cb);
    s->lock = fr_mutex_create();
    s->idle_cond = fr_cond_create();
    s->state_cond = fr_cond_create();
    s->worker_queues = (fr_run_queue_t *)calloc((size_t)s->worker_count, sizeof(fr_run_queue_t));
    s->native_queues = (fr_native_queue_t *)calloc((size_t)s->worker_count, sizeof(fr_native_queue_t));
    s->workers = (fr_thread_t **)calloc((size_t)s->worker_count, sizeof(fr_thread_t *));
    if (!s->event_loop || !s->lock || !s->idle_cond || !s->state_cond ||
        !s->worker_queues || !s->native_queues || !s->workers) {
        fr_scheduler_destroy(s);
        return NULL;
    }
    for (int i = 0; i < s->worker_count; i++) {
        fr_run_queue_init(&s->worker_queues[i]);
        fr_native_queue_init(&s->native_queues[i]);
        if (!s->worker_queues[i].lock || !s->native_queues[i].lock) {
            fr_scheduler_destroy(s);
            return NULL;
        }
    }
    fr_arena_set_coro_provider(scheduler_coro_arena_provider);
    return s;
}

static void discard_native(fr_native_fn fn, void *arg);

void fr_scheduler_destroy(fr_scheduler_t *sched) {
    if (!sched) return;
    fr_scheduler_stop(sched);
    if (sched->worker_queues) {
        for (int i = 0; i < sched->worker_count; i++) {
            fr_run_queue_destroy(&sched->worker_queues[i]);
        }
    }
    if (sched->native_queues) {
        for (int i = 0; i < sched->worker_count; i++) {
            fr_native_queue_destroy_with_cleanup(&sched->native_queues[i], discard_native);
        }
    }
    fr_process_t *p = sched->processes;
    while (p) {
        fr_process_t *next = p->next;
        fr_process_destroy(p);
        p = next;
    }
    fr_event_loop_destroy(sched->event_loop);
    fr_mutex_destroy(sched->lock);
    fr_cond_destroy(sched->idle_cond);
    fr_cond_destroy(sched->state_cond);
    free(sched->worker_queues);
    free(sched->native_queues);
    free(sched->workers);
    free(sched);
}

static void scheduler_start_workers(fr_scheduler_t *sched) {
    if (!sched || sched->workers_started) return;
    sched->workers_started = 1;
    for (int i = 0; i < sched->worker_count; i++) {
        fr_worker_arg_t *wa = (fr_worker_arg_t *)malloc(sizeof(fr_worker_arg_t));
        if (!wa) continue;
        wa->sched = sched;
        wa->wid = i;
        if (fr_thread_start(&sched->workers[i], worker_main, wa) != 0) free(wa);
    }
}

void fr_scheduler_start(fr_scheduler_t *sched) {
    if (!sched) return;
    fr_mutex_lock(sched->lock);
    while (sched->stopping) fr_cond_wait(sched->idle_cond, sched->lock);
    sched->running = 1;
    fr_scheduler_set_global(sched);
    scan_enqueue_runnable(sched);
    scheduler_start_workers(sched);
    fr_mutex_unlock(sched->lock);
}

void fr_scheduler_stop(fr_scheduler_t *sched) {
    if (!sched) return;
    fr_mutex_lock(sched->lock);
    while (sched->stopping) fr_cond_wait(sched->idle_cond, sched->lock);
    sched->stopping = 1;
    sched->running = 0;
    fr_cond_broadcast(sched->idle_cond);
    fr_cond_broadcast(sched->state_cond);
    fr_mutex_unlock(sched->lock);
    for (int i = 0; sched->workers && i < sched->worker_count; i++) {
        if (sched->workers[i]) fr_thread_join(sched->workers[i]);
        sched->workers[i] = NULL;
    }
    fr_mutex_lock(sched->lock);
    sched->workers_started = 0;
    /* Clear the old generation before a waiting start can publish this same
     * scheduler again. An unlocked CAS could erase the new generation. */
    fr_scheduler_t *expected = sched;
    atomic_compare_exchange_strong(&g_global_sched, &expected, NULL);
    sched->stopping = 0;
    fr_cond_broadcast(sched->idle_cond);
    fr_mutex_unlock(sched->lock);
}

static int sched_pool_submit(fr_scheduler_t *sched, fr_native_fn fn, void *arg) {
    if (!sched || !fn) return 0;
    fr_mutex_lock(sched->lock);
    int q = (int)(sched->next_queue++ % (unsigned)sched->worker_count);
    int ok = fr_native_queue_try_push_owned(&sched->native_queues[q], fn, arg);
    if (ok) {
        sched->native_pending++;
        sched->runnable++;
        fr_cond_signal(sched->idle_cond);
    }
    fr_mutex_unlock(sched->lock);
    return ok;
}

int fr_sched_pool_submit(fr_scheduler_t *sched, void (*fn)(void *), void *arg) {
    return sched_pool_submit(sched, fn, arg) ? 0 : -1;
}

size_t fr_sched_pool_queued(fr_scheduler_t *sched) {
    if (!sched) return 0;
    fr_mutex_lock(sched->lock);
    /* One queue is already a constant-cost snapshot; avoid per-callback
     * accounting in this existing small-pool fast path. */
    if (sched->worker_count == 1) {
        size_t count = sched->native_queues[0].count;
        fr_mutex_unlock(sched->lock);
        return count;
    }
    if (sched->native_executing < 0) {
        size_t queued = 0;
        for (int i = 0; i < sched->worker_count; i++)
            queued += sched->native_queues[i].count;
        assert(sched->native_pending >= 0 && queued <= (size_t)sched->native_pending);
        sched->native_executing = sched->native_pending - (int)queued;
    }
    assert(sched->native_pending >= sched->native_executing);
    size_t count = (size_t)(sched->native_pending - sched->native_executing);
    fr_mutex_unlock(sched->lock);
    return count;
}

typedef struct {
    fr_sched_native_fn1_t fn;
    int64_t arg;
} sched_native_arg1_t;

typedef struct {
    fr_sched_native_fn2_t fn;
    int64_t id;
    int64_t total;
    fr_mutex_t *lock;
    int *remaining;
    fr_cond_t *done;
} sched_indexed_ctx_t;

static void sched_native_trampoline1(void *p) {
    sched_native_arg1_t *ctx = (sched_native_arg1_t *)p;
    fr_sched_native_fn1_t fn = ctx->fn;
    int64_t arg = ctx->arg;
    free(ctx);
    fn(arg);
}

static void finish_indexed(sched_indexed_ctx_t *ctx) {
    fr_mutex_lock(ctx->lock);
    (*ctx->remaining)--;
    if (*ctx->remaining == 0) fr_cond_broadcast(ctx->done);
    fr_mutex_unlock(ctx->lock);
    free(ctx);
}

static void sched_native_trampoline2(void *p) {
    sched_indexed_ctx_t *ctx = (sched_indexed_ctx_t *)p;
    ctx->fn(ctx->id, ctx->total);
    finish_indexed(ctx);
}

/* Only the runtime's private wrappers own their arguments. Public submit's
 * opaque arguments remain borrowed and user callbacks are never run here. */
static void discard_native(fr_native_fn fn, void *arg) {
    if (fn == sched_native_trampoline1) free(arg);
    else if (fn == sched_native_trampoline2) finish_indexed(arg);
}

int64_t fr_sched_pool_spawn(fr_sched_native_fn1_t fn, int64_t arg) {
    fr_scheduler_t *sched = g_global_sched;
    if (!sched || !sched->running || !fn) return -1;
    sched_native_arg1_t *ctx = (sched_native_arg1_t *)malloc(sizeof(sched_native_arg1_t));
    if (!ctx) return -1;
    ctx->fn = fn;
    ctx->arg = arg;
    if (!sched_pool_submit(sched, sched_native_trampoline1, ctx)) { free(ctx); return -1; }
    return 0;
}

void fr_sched_pool_spawn_indexed(fr_sched_native_fn2_t fn, int64_t count) {
    fr_scheduler_t *sched = g_global_sched;
    if (!sched || !sched->running || !fn || count <= 0) return;
    if (count > sched->worker_count * 64) count = sched->worker_count * 64;

    /* This API waits for the batch to finish. A worker must not enqueue a
     * nested batch and block on its own pool: one worker (or all busy parents)
     * leaves no worker available to run the children. Keep nested same-pool
     * batches synchronous and inline; callers outside the pool retain the
     * parallel path below. No extra threads or ownership changes are needed. */
    if (tls_worker_scheduler == sched) {
        for (int64_t i = 0; i < count; i++) fn(i, count);
        return;
    }

    fr_mutex_t *lock = fr_mutex_create();
    fr_cond_t *done = fr_cond_create();
    int remaining = 0;
    if (!lock || !done) {
        fr_mutex_destroy(lock);
        fr_cond_destroy(done);
        return;
    }

    for (int64_t i = 0; i < count; i++) {
        sched_indexed_ctx_t *ctx = (sched_indexed_ctx_t *)calloc(1, sizeof(sched_indexed_ctx_t));
        if (!ctx) break;
        ctx->fn = fn;
        ctx->id = i;
        ctx->total = count;
        ctx->lock = lock;
        ctx->remaining = &remaining;
        ctx->done = done;
        fr_mutex_lock(lock);
        remaining++;
        if (!sched_pool_submit(sched, sched_native_trampoline2, ctx)) {
            remaining--;
            free(ctx);
            fr_mutex_unlock(lock);
            break;
        }
        fr_mutex_unlock(lock);
    }

    fr_mutex_lock(lock);
    while (remaining > 0) fr_cond_wait(done, lock);
    fr_mutex_unlock(lock);
    fr_mutex_destroy(lock);
    fr_cond_destroy(done);
}

void fr_scheduler_add_process(fr_scheduler_t *sched, fr_process_t *proc) {
    fr_mutex_lock(sched->lock);
    proc->sched = sched;
    proc->worker_id = (int)(sched->next_worker++ % (unsigned)sched->worker_count);
    proc->next = sched->processes;
    sched->processes = proc;
    for (fr_coro_t *c = proc->coros; c; c = c->next) {
        refresh_coro_counts_locked(sched, c);
        enqueue_coro_locked(sched, c);
    }
    fr_mutex_unlock(sched->lock);
}

fr_event_loop_t *fr_scheduler_event_loop(fr_scheduler_t *sched) {
    return sched ? sched->event_loop : NULL;
}

int fr_scheduler_worker_count(fr_scheduler_t *sched) {
    return sched ? sched->worker_count : 0;
}

void fr_scheduler_run(fr_scheduler_t *sched) {
    if (!sched) return;
    fr_scheduler_start(sched);
    fr_mutex_lock(sched->lock);
    while (sched->running) {
        if (sched->active_coros == 0 && sched->native_pending == 0) break;
        if (sched->waiting_io > 0) {
            /* Never hold state across a blocking poll: callbacks and workers
             * need it to publish readiness/completion. Stop latency is bounded. */
            fr_mutex_unlock(sched->lock);
            fr_event_loop_poll(sched->event_loop, 10);
            fr_mutex_lock(sched->lock);
        } else {
            /* Running jobs and mailbox waiters do not need an event-loop poll.
             * Await registration and worker completion wake this predicate. */
            fr_cond_wait(sched->state_cond, sched->lock);
        }
    }
    fr_mutex_unlock(sched->lock);
    fr_scheduler_stop(sched);
}

fr_process_t *fr_process_create(const char *name) {
    fr_process_t *p = (fr_process_t *)calloc(1, sizeof(fr_process_t));
    if (!p) return NULL;
    p->name = fr_strdup(name ? name : "process");
    p->next_coro_id = 1;
    p->lock = fr_mutex_create();
    p->msg_cond = fr_cond_create();
    if (!p->name || !p->lock || !p->msg_cond) {
        fr_process_destroy(p);
        return NULL;
    }
    return p;
}

void fr_process_destroy(fr_process_t *proc) {
    if (!proc) return;
    fr_coro_t *c = proc->coros;
    while (c) {
        fr_coro_t *next = c->next;
        free(c->state);
        fr_arena_destroy(c->arena);
        free(c);
        c = next;
    }
    for (size_t i = 0; i < proc->mailbox.count; i++) {
        fr_msg_t *m = &proc->mailbox.msgs[(proc->mailbox.head + i) % MAILBOX_CAP];
        if (m->owns_payload && m->payload) free(m->payload);
    }
    fr_mutex_destroy(proc->lock);
    fr_cond_destroy(proc->msg_cond);
    free(proc->children);
    free(proc->name);
    free(proc);
}

fr_scheduler_t *fr_process_scheduler(fr_process_t *proc) {
    return proc->sched;
}

const char *fr_process_name(fr_process_t *proc) {
    return proc ? proc->name : "";
}

void fr_process_set_receive_handler(fr_process_t *proc, fr_coro_fn handler, size_t state_size) {
    proc->receive_handler = handler;
    proc->receive_state_size = state_size;
}

fr_coro_t *fr_coro_spawn(fr_process_t *proc, fr_coro_fn fn, void *init_state, size_t state_size) {
    fr_coro_t *c = (fr_coro_t *)calloc(1, sizeof(fr_coro_t));
    if (!c) return NULL;
    if (!fn || (state_size && !init_state)) { free(c); return NULL; }
    c->fn = fn;
    c->state_size = state_size;
    if (state_size) {
        /* Generated spawn stubs already build an owned, initialized state
         * object. Keep it instead of allocating, copying, and freeing it. */
        c->state = init_state;
    } else {
        c->state = malloc(1);
        if (!c->state) {
            free(c);
            return NULL;
        }
        free(init_state);
    }
    c->status = FR_CORO_RUNNING;
    c->step = 0;
    c->proc = proc;
    c->await_fd = -1;
    if (proc->sched) fr_mutex_lock(proc->sched->lock);
    fr_mutex_lock(proc->lock);
    c->id = proc->next_coro_id++;
    if (!proc->coros) proc->coros = proc->coro_tail = c;
    else { proc->coro_tail->next = c; proc->coro_tail = c; }
    fr_mutex_unlock(proc->lock);
    if (proc->sched) {
        refresh_coro_counts_locked(proc->sched, c);
        enqueue_coro_locked(proc->sched, c);
        fr_mutex_unlock(proc->sched->lock);
    }
    return c;
}

fr_coro_status_t fr_yield(fr_coro_t *coro) {
    (void)coro;
    return FR_CORO_YIELDED;
}

int fr_coro_inline_yield(fr_coro_t *coro, int next_step) {
    if (!coro || coro != tls_current_coro || !tls_worker_scheduler ||
        !tls_reductions_remaining || !tls_worker_scheduler->running ||
        *tls_reductions_remaining <= 0) {
        if (coro) coro->step = next_step;
        return 1;
    }
    --*tls_reductions_remaining;
    return 0;
}

int fr_coro_id(fr_coro_t *coro) {
    return coro ? coro->id : -1;
}

fr_process_t *fr_coro_process(fr_coro_t *coro) {
    return coro ? coro->proc : NULL;
}

int fr_coro_step(fr_coro_t *coro) {
    return coro ? coro->step : 0;
}

void fr_coro_set_step(fr_coro_t *coro, int step) {
    if (coro) coro->step = step;
}

int fr_send(fr_process_t *dst, int tag, int64_t value, void *payload, size_t payload_size) {
    /* A send consumes its heap payload even when delivery is impossible. */
    if (!dst) { free(payload); return 0; }
    fr_msg_t msg = { tag, value, payload, payload_size, payload ? 1 : 0, NULL };
    fr_mutex_lock(dst->lock);
    int accepted = mailbox_push(&dst->mailbox, msg);
    if (accepted) fr_cond_broadcast(dst->msg_cond);
    fr_mutex_unlock(dst->lock);
    if (!accepted) { free(payload); return 0; }
    if (dst->sched) {
        fr_mutex_lock(dst->sched->lock);
        for (fr_coro_t *c = dst->coros; c; c = c->next) {
            if (!c->executing && c->status == FR_CORO_WAITING_RECV) {
                c->status = FR_CORO_RUNNING;
                enqueue_coro_locked(dst->sched, c);
            }
        }
        fr_mutex_unlock(dst->sched->lock);
    }
    return 1;
}

int fr_try_recv(fr_process_t *self, fr_msg_t *out) {
    if (!self || !out) return 0;
    fr_mutex_lock(self->lock);
    int ok = mailbox_pop(&self->mailbox, out);
    fr_mutex_unlock(self->lock);
    return ok;
}

int fr_recv(fr_process_t *self, fr_msg_t *out) {
    if (!self || !out) return 0;
    fr_mutex_lock(self->lock);
    while (!mailbox_pop(&self->mailbox, out)) {
        fr_cond_wait(self->msg_cond, self->lock);
    }
    fr_mutex_unlock(self->lock);
    return 1;
}

void fr_msg_free_payload(fr_msg_t *msg) {
    if (msg && msg->owns_payload && msg->payload) {
        free(msg->payload);
        msg->payload = NULL;
        msg->owns_payload = 0;
    }
}

int64_t fr_await_fd(fr_coro_t *coro, int64_t fd, uint32_t events) {
    if (!coro) return 1;
    if (!coro->proc || !coro->proc->sched || fd < 0) return -1;
    fr_scheduler_t *sched = coro->proc->sched;
    fr_mutex_lock(sched->lock);
    if (coro->await_ready && coro->await_fd == (int)fd) {
        coro->await_ready = 0;
        coro->await_fd = -1;
        fr_event_loop_del(sched->event_loop, (int)fd);
        fr_mutex_unlock(sched->lock);
        return 1;
    }
    coro->await_fd = (int)fd;
    coro->await_events = events;
    coro->await_ready = 0;
    coro->status = FR_CORO_WAITING_IO;
    int ok = fr_event_loop_add(sched->event_loop, (int)fd, events | FR_EVENT_ONESHOT, coro);
    fr_cond_signal(sched->state_cond);
    if (ok < 0) { coro->await_fd = -1; coro->status = FR_CORO_ERROR; }
    refresh_coro_counts_locked(sched, coro);
    fr_mutex_unlock(sched->lock);
    return ok < 0 ? -1 : 0;
}

fr_process_t *fr_supervisor_create(const char *name, fr_restart_policy_t policy) {
    fr_process_t *p = fr_process_create(name);
    if (!p) return NULL;
    p->is_supervisor = 1;
    p->restart_policy = policy;
    return p;
}

void fr_supervisor_add_child(fr_process_t *supervisor, fr_process_t *child) {
    if (!supervisor || !child || supervisor->child_count >= SIZE_MAX / sizeof(fr_process_t *)) return;
    size_t count = supervisor->child_count + 1;
    fr_process_t **children = (fr_process_t **)realloc(
        supervisor->children, count * sizeof(*children));
    if (!children) return;
    children[count - 1] = child;
    supervisor->children = children;
    supervisor->child_count = count;
}

int fr_event_poll(fr_scheduler_t *sched, int timeout_ms) {
    if (!sched || !sched->event_loop) return -1;
    return fr_event_loop_poll(sched->event_loop, timeout_ms);
}

int64_t fr_event_add_read(fr_scheduler_t *sched, int64_t fd) {
    if (!sched || !sched->event_loop || fd < 0) return -1;
    if (fr_event_loop_add(sched->event_loop, (int)fd, FR_EVENT_READ, NULL) < 0) return -1;
    return fd;
}
