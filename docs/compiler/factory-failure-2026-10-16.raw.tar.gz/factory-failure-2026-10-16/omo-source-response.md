I'll audit the cold-path construction changes. Reading the sources and baselines in parallel first.

Now the public header, codegen, and baselines:

Now the codegen main-generation block, spawn-inits helper, and event loop null tolerance:

Checking baseline `fr_coro_spawn`, test registration, codegen helpers, and the out-of-scope behaviors:

Build logs clean. Now checking all in-repo callers of the factories for NULL-handling, and remaining details:

Configuration confirms the patched local runtime was used. Running the runtime test suite for evidence:

All targeted tests pass. Let me check the prior probe artifacts to align on what was already verified, then compose the review:

Audit complete. All sources, baselines, tests, and build/test evidence verified. Final review:

---

# Cold-path construction hardening — read-only audit

**Verdict: Approve.** No correctness bugs found in the audited changes. The five named inspection points all hold up under source-level scrutiny; several plausible-looking claims are rejected below because null-tolerant/zeroed cleanup already suffices. What remains are integration/coverage observations (none introduced by this patch) and the two behaviors you asked me to classify separately.

## 1. Change inventory (candidate vs. baseline)

| File | Delta |
|---|---|
| `src/scheduler.c` | provider publication moved to end of create; per-queue lock check; `fr_process_create` partial-failure NULL return; `fr_supervisor_create` NULL guard; `fr_supervisor_add_child` realloc commit |
| `src/thread.c` | POSIX `fr_mutex_create`/`fr_cond_create`: init-failure → `free` + NULL |
| `include/forge_runtime.h`, `include/forge/thread.h`, `src/work_queue.h`, `README.md` | documentation only |
| `CMakeLists.txt` | factory test registration, Linux-gated (L55–57, L91–95) |
| `tests/factory_test.c` | new; identical to the built copy in `/dev/shm` |
| forge `compiler/codegen.c` | spawn stub: `free(init)+abort` on NULL; `main`: NULL checks for scheduler/process/supervisor |
| forge `tests/factory_faults.c`, `tests/compiler_test.py` | new fault-injection harness + test |

`src/work_queue.c` and `src/arena.c` are byte-identical to baseline. `fr_coro_spawn` is also unchanged from baseline — audited as requested because the new codegen failure path depends on its ownership contract.

## 2. Named inspection points

### 2a. `fr_coro_spawn` — NULL vs non-NULL / enqueue-ERROR ownership (`scheduler.c:689–723`)

Ownership matrix is airtight:

- **NULL returns** at L691 (`calloc`), L692 (`!fn || (state_size && !init_state)`), L701–704 (`malloc(1)` for zero-size state) all occur **before** `init_state` is consumed. Caller retains it — matching the header contract (forge_runtime.h:82–85) and making the generated `free(init)` exactly-once with no double-free.
- **Non-NULL returns always consume**: `state_size > 0` → `c->state = init_state` (L698), freed once at `fr_process_destroy` L660; `state_size == 0` → `free(init_state)` at L705 (generated stubs always pass `sizeof(...) > 0`, so this branch is unreachable from codegen).
- **Enqueue-ERROR path** (`enqueue_coro_locked` L187–194 invoked at L719): run-queue push failure sets `status = FR_CORO_ERROR` and spawns still return **non-NULL**. Verified consistent: `refresh_coro_counts_locked` at L718 counts it active, the L189 refresh on failure un-counts it (`active_coros` net 0, `runnable` never incremented, `on_queue` stays 0, inventory asserts hold). The coroutine is inert but **still owned** — `c->state == init_state` is freed at process destroy. No leak, no double free, completion waiters are signaled (L192). This is silent task-drop under OOM, not an ownership bug; it is baseline behavior, unchanged by this patch, and `factory_faults.c` proves the NULL side empirically (`rejected state freed` count == 1).

### 2b. Generated `free(init)+abort` (`codegen.c:1126–1129`)

- Emitted code is brace-balanced, `init` is in scope (declared L1113), `<stdio.h>`/`<stdlib.h>` are emitted (L3020), and the failure branches of `fr_coro_spawn` leave `init` unconsumed — so `free(init)` cannot double-free (§2a).
- The unconditional `abort()` makes the only residual nit moot: hoisted-let initializer expressions (`emit_coro_spawn_inits`, L866–880) could store nested allocations inside `init`, which `free(init)` alone wouldn't release — but the process terminates immediately, so nothing is reachable after.
- Verified end-to-end by `test_generated_process_construction_failures_release_owned_resources` (all six modes: `none/scheduler/process/supervisor/coroutine/coroutine-real`, exit codes, `live=0 destroys=N`, single rejected-state free) — **passes**.

### 2c. `fr_scheduler_create` — failure destroy before provider publication (`scheduler.c:342–372`)

- Baseline published `fr_arena_set_coro_provider` as its *first* statement — before `calloc` — so a failed create permanently overwrote the caller's provider. Candidate sets it at **L370, strictly after every failure check** (L357–361, L365–368); both failure paths call `fr_scheduler_destroy(s)` first, and destroy never publishes. `factory_test.c` L126/L130 asserts the sentinel provider survives a failed create; it fails on baseline, passes on candidate.
- Destroy-during-failed-create is safe and **does not need any claim beyond what exists**: `fr_scheduler_stop` on a never-started scheduler no-ops through null-tolerant `fr_mutex_lock`/`fr_cond_broadcast` (thread.c L134–140, L154–160), the join loop guards `sched->workers &&` (L437), the global CAS is value-guarded (L445–446, so `foreign_owner`'s surviving global is untouched — asserted at factory_test.c L182), `fr_event_loop_destroy(NULL)` returns immediately (event_loop.c L71), and `free(NULL)` is fine.
- The provider function itself holds **no scheduler reference** (L107–109: `fr_coro_get_arena(tls_current_coro)`), so publishing it on success and never clearing it on destroy cannot dangle; outside a worker `tls_current_coro` is NULL → provider returns NULL → `fr_arena_tls` falls back to TLS arena (arena.c L109–113). Atomic store (arena.c L23–24) makes concurrent creates idempotent.

### 2d. pthread init failure with no destroy (`thread.c:124`, `L144`)

Correct, and I explicitly reject the inverse claim: POSIX leaves a mutex whose `pthread_mutex_init` failed in an unspecified state — calling `pthread_mutex_destroy` on it is UB. `free(m)` alone is the right cleanup, and `factory_test.c`'s `retire_primitive` CHECK (`primitives[i].valid == 0`) would fail the suite if destroy were called. Short-circuit form is also right: `m == NULL` (calloc failure) skips init and falls through to `return NULL`. Windows branch untouched — `InitializeSRWLock`/`InitializeConditionVariable` are infallible, so the new thread.h comment (L14) stays accurate per-platform.

### 2e. Supervisor realloc commit (`scheduler.c:837–846`)

Textbook transactional growth: overflow guard first (`child_count >= SIZE_MAX / sizeof(*children)` — `SIZE_MAX` available via forge_runtime.h's `<stdint.h>`, so `count * sizeof` cannot wrap), temp pointer, `if (!children) return` leaves `children`/`child_count` untouched, then commit both. Matches the new header contract (L119–122). Failure-side verification is empirical: baseline probe `child` → **SIGSEGV (-11)** (unconditional `children[count-1]` on NULL); candidate → `transaction_preserved: true` with retry at `p == old_array, bytes == 2*sizeof(ptr)` (factory_test.c L167–168, probe JSON). `fr_process_destroy` frees only the array (L671) — borrowed children untouched, per contract. The `if (!supervisor || !child)` guards also close the NULL-deref the baseline probe showed for `supervisor` (-11 → clean NULL via the new `if (!p)` at L831).

## 3. Cross-cutting checks

**Partial failure / zeroed cleanup (REJECTED claims):**
- `fr_scheduler_create` mid-loop failure at iteration *i*: queues `0..i-1` have valid locks (destroyed normally), queue *i* has a NULL lock (`fr_mutex_destroy(NULL)` no-ops, thread.c L129), queues `i+1..n` are calloc-zeroed (`fr_run_queue_destroy` L13–23 and `fr_native_queue_destroy_with_cleanup` L79–95 walk NULL heads, tolerate NULL lock, zero their fields). **Null-tolerant zeroed cleanup already suffices — no bug.** `work_queue.h`'s new comment documents exactly this contract, and the only non-test owner of `fr_*_queue_init` (`scheduler.c` L363–364) performs the new lock check before publishing (L365–368). Probe `queue` confirms: baseline returned a scheduler with a NULL queue lock (`owner_null:false`); candidate returns NULL.
- `fr_process_create` partial failure (L648–651): `fr_process_destroy` tolerates NULL `name`/`lock`/`msg_cond`/`children` (L669–672), mailbox count is 0, and a failed primitive was never registered valid — test invariants hold. Probes `process-name/process-lock/process-cond`: baseline returned landmines (`name_null:true`, live-but-broken locks); candidate returns NULL.
- `fr_sched_pool_spawn_indexed` (L562–569) already handled NULL lock/cond with null-tolerant destroys — unchanged, still correct.
- Event-loop failure: `fr_event_loop_create` frees its calloc before returning NULL (event_loop.c L62–64), so `live==0` under `fail_epoll` holds.

**Global publication:** `g_global_sched` is written only at `fr_scheduler_set_global` (L116, atomic), `fr_scheduler_start` (L422), and stop's value-guarded CAS (L446). Neither `fr_scheduler_create` nor its failure-destroy path publishes; destroy's CAS cannot erase another scheduler's registration (`foreign_owner` asserts this). README's new claim ("failed scheduler creation preserves the existing arena provider and global scheduler") is accurate.

**Nullability:** every new/possible NULL is handled at each boundary — runtime internal callers (scheduler.c L357/L565/L648), generated code (codegen.c L3171/L3177/L3189, spawn L1126), and all primitives (`fr_mutex_lock/unlock/wait/signal/broadcast` and all destroys are `if (m)`-guarded). New public contracts are documented at forge_runtime.h L43–44, L74–75, L119–122, thread.h L14.

**ABI:** header diffs are comment-only; no struct, enum, typedef, or signature changed; `fr_scheduler`/`fr_process`/`fr_mutex`/`fr_cond` remain opaque; package version unchanged (SameMajorVersion). Only semantic change: factories can return NULL in more (rare) cases — strictly safer than baseline's partially-constructed objects, and degrades to null-tolerant no-ops even for a caller that ignores the return.

**Platform boundaries:** the `thread.c` change sits in the non-Windows `#else` branch; factory test and its GNU-ld `--wrap` flags are gated to `CMAKE_SYSTEM_NAME STREQUAL "Linux"` (CMakeLists L55–57, L91–95) — correct, since ld64/MSVC have no `--wrap`. `_GNU_SOURCE` handling unchanged; `SIZE_MAX`/`_Thread_local` are C11/portable; probe and test suites are Linux-only by construction.

**Codegen emission details:** `cg.out == out` (codegen.c L3014) and `indent == 1` (L3167), so the mixed `fprintf(out, "    …")` / `cg_line` lines align (cosmetic concern only). No double-destroy: failure paths `return 1` before `fr_scheduler_run`; success destroys once (L3212). Check ordering guarantees no unattached object is live at any failure point — each `if (!proc_N)` sits between its create and its `add_process`, and each `if (!sup_i)` precedes the iteration where `sup_i` gets attached, so `fr_scheduler_destroy(sched)` frees all previously attached processes/supervisors (scheduler.c L389–394).

## 4. Concrete issues (none are correctness bugs in the patch)

1. **Dependency pin not bumped (integration follow-up).** `forge/cmake/Dependencies.cmake:2` pins `FORGE_RUNTIME_REVISION dcbb192` — the pre-patch runtime (`build/_deps/forge_runtime-src/src/scheduler.c:540–549` still has the old `fr_process_create`). Default forge builds (no `-DFORGE_RUNTIME_SOURCE_DIR`) compile the new generated NULL checks against the old runtime: harmless and correct (checks are valid against both), but dormant, and the new runtime header docs don't ship until the pin moves. Your `root-build` used the local override (CMakeCache `FORGE_RUNTIME_SOURCE_DIR=/home/helloworld0822/coding/forge-runtime`), so the tested configuration is the patched pair.
2. **Selfhost codegen coverage gap (pre-existing, not a regression).** `bootstrap/compiler.fg:964–966` still emits `fr_scheduler_create(1)` / `fr_process_create(...)` unchecked, and stage1/2 output confirms it (`build/generated/forge-stage2.c:1372`). Stage0-generated binaries get the new paths; `forge-fg`-generated ones keep baseline exposure (NULL-deref only under OOM, which baseline also had). Out of the stated source scope — recommend a follow-up to mirror the checks in `compiler.fg`.
3. **Unchecked external callers (pre-existing pattern).** Fetched stdlib calls e.g. `build/_deps/forge_stdlib-src/src/http.c:755` / `http_tls.c:284` / `http_uring.c:120` assign `fr_scheduler_create(...)` without a NULL check. Baseline could already return NULL (calloc/event-loop failure); the patch adds native-primitive-init failures as a new, rarer NULL trigger while documenting the contract. Follow-up when adopting the pin: add checks there.
4. **Doc nit (baseline, unchanged).** forge_runtime.h L82–84 says success-owned `init_state` is freed "when the owning process destroys the coroutine", but the `state_size == 0` non-NULL path frees it immediately at spawn (scheduler.c L705). Harmless for contract-following callers (must not touch it after success) and the doc steers zero-size callers to NULL — worth a wording touch someday, not part of this patch.

## 5. Classified separately (out of patch scope, verified unchanged)

- **No-worker-start fallback** (`scheduler.c:405–415`, surfaced via L119–122): `workers_started = 1` is set unconditionally; per-worker `malloc`/`fr_thread_start` failures are silently skipped, so a pool can be under-populated or empty while `running == 1`, `fr_sched_pool_available()` reports available, and `fr_scheduler_run` can wait indefinitely on work no thread will ever claim (only workers drain `native_pending`/queued coros). **Pre-existing — byte-identical in baseline; this patch neither introduces nor mitigates it.** Note `factory_test.c`'s `foreign_owner` only exercises the happy thread-start path, so it does not mask this.
- **Implicit supervisor recovery**: no in-runtime recovery exists to audit — `restart_policy` is stored (L57, L833) and **never read anywhere** in the runtime (grep: only those two sites + the enum); `fr_supervisor_add_child` is config-only and now explicitly documented "Not automatic recovery" (forge_runtime.h L121, README). The related implicit behavior that *does* exist — `fr_scheduler_destroy` cascading through attached processes and supervisors (L389–394) — is also unchanged. **Pre-existing, out of scope.**

## 6. Evidence

- Runtime suite: **9/9 passed** (`ctest` in `release-build`, includes `factory_regressions`, all with `-UNDEBUG` asserts).
- Compiler suite: **`compiler_regressions` passed** (12.2s); the new construction-fault test run individually: **OK, all 6 fault modes** in 2.6s.
- Probe regression pair: baseline → `SIGSEGV` on `supervisor`/`child`, non-NULL broken owners on `queue/process-*/mutex-init/cond-init`; candidate → all status 0, `owner_null:true`, `transaction_preserved:true`.
- Build: runtime built with `-Wall -Wextra`, no warnings; forge root-build (patched local runtime via `FORGE_RUNTIME_SOURCE_DIR`) completed including `forge-selfhost`.

No files were modified during this audit.
