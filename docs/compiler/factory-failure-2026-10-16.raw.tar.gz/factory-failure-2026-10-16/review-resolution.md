# OMO review resolution

Models are reviewers, not authoritative source or test evidence. Exact requests,
terminal JSONL and exported sessions are retained. All three runs finished with
reason=stop. Source review completion and adjudication are recorded below.

## Design review

Accepted: validate every required native primitive and queue lock, free failed
pthread-init storage without destroying it, preserve list pointer/count on failed
realloc, inspect NULL ownership before adding generated cleanup, and test existing
global owners/providers during failed construction.

Rejected: the claim that scheduler partial cleanup requires extra per-queue flags
or reverse-order-only cleanup. Actual queue arrays are calloc-zeroed; queue init
leaves an empty queue with a NULL lock on failure; native primitive constructors
now return only valid pointers or NULL; queue/primitive destruction tolerates
NULL. No worker starts during construction. The independent ledger sweeps each
allocation/init site and rejects destroying failed native primitives or freeing
live ones. Extra flags would duplicate state without establishing a missing
invariant. Existing started scheduler usability and sentinel provider are tested.

## Evidence review

Accepted: retain all adverse primary rows, explain reversed-batch disagreement,
separate emitter behavior from runtime behavior, avoid treating NULL as proof of
cleanup, state Linux-only execution and no TSan pass, and keep coroutine abort,
nested fields, nonNULL enqueue-error, external callers and worker-start limitations
explicit. The report states descriptive individual intervals, not equivalence.

Clarifications supported by source/tests:

- The prompt's shorthand about retaining adverse reverse results was loose. The
  report gives both ratios: reverse 12w/1024=1.096 is favorable with an interval
  including 1. Primary and follow-up are separate, without cherry-picking/pooling.
- `factory: rejected state freed` is an observation marker in __wrap_free. The
  harness does not abort there; it calls real free on the valid rejected state.
  The generated stub calls abort after its explicit diagnostic. No invalid-free
  guard caused the signal. A new `coroutine-real` subcase also fails calloc inside
  the actual fr_coro_spawn implementation, rather than replacing its return value.
  Baseline exits 0 silently with no free marker; candidate frees once, prints the
  generated failure diagnostic and gets SIGABRT. This is a deliberate change in
  failure behavior, not graceful recovery or an effect on normal successful work.
- `process-name` JSON's `name_null:false` with `owner_null:true` means there is no
  returned object to inspect: the probe computes `p && !fr_process_name(p)`.
  It does not indicate a successful name allocation or dereference a freed object.
- Failed queue construction now returns NULL, so the probe intentionally cannot
  submit to it or read its depth. The separate known_inventory test creates a
  valid scheduler, checks pre-start submission/depth=1, runs the job and checks 0.
- Eight named counterfactual probes are bounded. Additional every-observed-site
  sweeps live in factory_test.c, included in the 18/18 ASan+UBSan suite with leak
  detection. The named probes themselves and generated abort cases are not sold
  as separate leak-sanitized executions. Generated clean-return checks observe
  the finite set of returned owner pointers; nested-field leak freedom on abort
  and arbitrary OOM interleavings remain unproved.
- Generated baseline and candidate link the same candidate library by design,
  isolating emitted caller code. Runtime changes have their own frozen-library
  counterfactuals and standalone/combined fault-sweep tests.
- The runtime baseline has two reproduced SIGSEGVs; the generated-C baseline has
  three additional SIGSEGV paths. These are described in their separate sections.
  The unchanged public void child-registration signature is a source-diff claim;
  failed-growth preservation is separately exercised by realloc observations.

No additional benchmark rounds were run after the reversed-order native batch:
there was no new hypothesis justifying more samples. Source object identity for
three selected functions does not settle final placement or causality.

## Completed source review

The exact-source review finished with reason=stop and verdict Approve, reporting
no correctness bug in the current patch. It independently ran runtime 9/9,
compiler_regressions and the specific generated-failure test (all six modes).
Its initial pytest/unittest attempts were unavailable/missing required arguments
and are not counted as passes; the later CTest and correctly parameterized CLI
runs did pass. The complete terminal output/export retain both kinds of attempt.

Accepted: stage0 emission failure ownership and generated owner cleanup; every
queue lock check, delayed provider publication, valid-only native factories and
transactional child growth. It independently rejected extra per-queue flags.

The self-host generator is a real pre-existing coverage gap: compiler.fg:964–970
still emits unchecked scheduler/process creation. The report and architecture now
explicitly limit the new generated behavior to the stage0 C backend. Self-host
fixed-point equality is not promoted into matching failure behavior. The worker
start and automatic recovery boundaries remain separate; a new negative control
shows both frozen versions advertise pool availability and queue a job after all
worker starts fail. It intentionally does not call run or claim a run-timeout test.

Corrections to source-review overstatements/stale observations:

- The fetched/default dependency snapshot is not the current local stdlib pair.
  Local http.c:797–801 and http_uring.c:120–123 check scheduler creation and fall
  back; http_tls.c:284–287 conditionally starts the scheduler, then uses existing
  worker fallback. No general assertion that the current three HTTP paths all
  dereference NULL is accepted. Other C callers still need their own contract audit.
- The early-read init_state comment was already updated during this turn. The final
  header explicitly documents immediate free for zero-sized input, NULL retaining
  ownership, and nonNULL enqueue-error not guaranteeing execution. The model's
  "unchanged doc nit" is stale, not an outstanding source defect.
- NULL-tolerant primitive helpers do not make every unchecked caller safe. In
  particular process-mutating APIs can dereference a NULL process; no blanket
  fallback-to-no-op or external-caller safety claim is accepted.
- Raw state storage cleanup is not proof that nested owned fields are cleaned on
  abort. That limit remains explicit even where the reviewer called it moot.

No new production change was required by the completed review. Narrow test
assertions added during the audit also require successful native destroy/close
return codes and passed separately in Release and ASan+UBSan.
