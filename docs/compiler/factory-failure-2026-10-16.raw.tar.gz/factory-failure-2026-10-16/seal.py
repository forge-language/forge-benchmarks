from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import tarfile
import tempfile

p = Path('/dev/shm/forge-factory-20261015')
raw = p / 'raw'
for name in ['design', 'source', 'evidence']:
    rows = [json.loads(line) for line in (p / f'omo-{name}.jsonl').read_text().splitlines() if line.strip()]
    assert rows[-1]['type'] == 'step_finish' and rows[-1]['part']['reason'] == 'stop', name
    assert (p / f'omo-{name}-export.json').is_file(), name
for directory in ['baseline-runtime', 'candidate-runtime', 'candidate-stdlib', 'candidate-root',
                  'dispatch-controls', 'dispatch-native-reverse', 'selfhost']:
    shutil.copytree(p / directory, raw / directory, dirs_exist_ok=True)
for file in p.iterdir():
    if file.is_file() and file.name != 'write_report.py':
        shutil.copy2(file, raw / file.name)
report = Path('/home/helloworld0822/coding/forge/docs/benchmarks/factory-failure-2026-10-16.md')
shutil.copy2(report, raw / 'report.md')
files = sorted(file for file in raw.rglob('*') if file.is_file() and file.name != 'SHA256SUMS')
assert not any(file.is_symlink() for file in raw.rglob('*'))
manifest = ''.join(hashlib.sha256(file.read_bytes()).hexdigest() + '  ' + str(file.relative_to(raw)) + '\n' for file in files)
(raw / 'SHA256SUMS').write_text(manifest)
archive = p / 'factory-failure-2026-10-16.raw.tar.gz'
with archive.open('wb') as target:
    with gzip.GzipFile(fileobj=target, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            tar.add(raw, arcname='factory-failure-2026-10-16')
with tarfile.open(archive, 'r:gz') as tar:
    for line in manifest.splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256(tar.extractfile('factory-failure-2026-10-16/' + name).read()).hexdigest() == expected, name
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
final = report.with_name(archive.name)
fd, temporary = tempfile.mkstemp(dir=final.parent, prefix='.factory-evidence-')
try:
    with os.fdopen(fd, 'wb') as target, archive.open('rb') as source:
        shutil.copyfileobj(source, target)
        target.flush()
        os.fsync(target.fileno())
    os.chmod(temporary, 0o644)
    os.replace(temporary, final)
finally:
    if os.path.exists(temporary): os.unlink(temporary)
report.with_suffix('.sha256').write_text(sha + '  ' + archive.name + '\n')
print(json.dumps(dict(archive=str(final), bytes=final.stat().st_size, files=len(files)+1, sha256=sha)))
