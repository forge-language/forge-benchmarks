#define _GNU_SOURCE
#include "forge_runtime.h"
#include "forge/thread.h"
#include <pthread.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static const char *mode;
static int mutex_calls, cond_calls, malloc_calls, calloc_calls, realloc_calls;
static void *array_ptr, *first_array;
static int retry_ok;
static void fault(const char *s) { (void)write(2,s,strlen(s)); }
fr_mutex_t *__real_fr_mutex_create(void);
fr_mutex_t *__wrap_fr_mutex_create(void) {
 int n=++mutex_calls;
 if((!strcmp(mode,"queue")&&n==3)||(!strcmp(mode,"process-lock")&&n==1)){fault("fault:mutex-create\n");return NULL;}
 return __real_fr_mutex_create();
}
fr_cond_t *__real_fr_cond_create(void);
fr_cond_t *__wrap_fr_cond_create(void) {
 if(!strcmp(mode,"process-cond")&&++cond_calls==1){fault("fault:cond-create\n");return NULL;}
 return __real_fr_cond_create();
}
void *__real_malloc(size_t);
void *__wrap_malloc(size_t n) {if(!strcmp(mode,"process-name")&&++malloc_calls==1){fault("fault:malloc\n");return NULL;}return __real_malloc(n);}
void *__real_calloc(size_t,size_t);
void *__wrap_calloc(size_t n,size_t s) {if(!strcmp(mode,"supervisor")&&++calloc_calls==1){fault("fault:calloc\n");return NULL;}return __real_calloc(n,s);}
int __real_pthread_mutex_init(pthread_mutex_t *,const pthread_mutexattr_t *);
int __wrap_pthread_mutex_init(pthread_mutex_t *m,const pthread_mutexattr_t *a){if(!strcmp(mode,"mutex-init")){fault("fault:pthread-mutex-init\n");return ENOMEM;}return __real_pthread_mutex_init(m,a);}
int __real_pthread_cond_init(pthread_cond_t *,const pthread_condattr_t *);
int __wrap_pthread_cond_init(pthread_cond_t *c,const pthread_condattr_t *a){if(!strcmp(mode,"cond-init")){fault("fault:pthread-cond-init\n");return ENOMEM;}return __real_pthread_cond_init(c,a);}
void *__real_realloc(void *,size_t);
void *__wrap_realloc(void *p,size_t n){
 if(!strcmp(mode,"child")){
  int call=++realloc_calls;
  if(call==2){fault("fault:realloc\n");return NULL;}
  if(call==3)retry_ok=p==first_array&&n==2*sizeof(fr_process_t *);
 }
 void *r=__real_realloc(p,n);array_ptr=r;if(realloc_calls==1)first_array=r;return r;
}
static void noop(void *p){(void)p;}
int main(int argc,char **argv){
 if(argc!=2)return 2;mode=argv[1];
 if(!strcmp(mode,"queue")){
  fr_scheduler_t *s=fr_scheduler_create(2);if(!s){puts("{\"owner_null\":true}");return 0;}
  int accepted=fr_sched_pool_submit(s,noop,NULL)==0;size_t depth=fr_sched_pool_queued(s);
  printf("{\"owner_null\":false,\"accepted\":%d,\"depth_without_start\":%zu}\n",accepted,depth);fr_scheduler_destroy(s);return 1;
 }
 if(!strcmp(mode,"mutex-init")){fr_mutex_t *m=fr_mutex_create();int bad=m!=NULL;free(m);printf("{\"owner_null\":%s}\n",bad?"false":"true");return bad;}
 if(!strcmp(mode,"cond-init")){fr_cond_t *c=fr_cond_create();int bad=c!=NULL;free(c);printf("{\"owner_null\":%s}\n",bad?"false":"true");return bad;}
 if(!strcmp(mode,"child")){
  fr_process_t *s=fr_supervisor_create("s",FR_RESTART_ALL),*a=fr_process_create("a"),*b=fr_process_create("b"),*c=fr_process_create("c");if(!s||!a||!b||!c)return 3;
  fr_supervisor_add_child(s,a);fr_supervisor_add_child(s,b);fr_supervisor_add_child(s,c);
  int ok=retry_ok&&((fr_process_t **)array_ptr)[0]==a&&((fr_process_t **)array_ptr)[1]==c;
  fr_process_destroy(s);fr_process_destroy(a);fr_process_destroy(b);fr_process_destroy(c);printf("{\"transaction_preserved\":%s}\n",ok?"true":"false");return !ok;
 }
 fr_process_t *p=!strcmp(mode,"supervisor")?fr_supervisor_create("s",FR_RESTART_ALL):fr_process_create("p");
 int bad=p!=NULL;printf("{\"owner_null\":%s,\"name_null\":%s}\n",bad?"false":"true",p&&!fr_process_name(p)?"true":"false");fr_process_destroy(p);return bad;
}
