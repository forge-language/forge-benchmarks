## Design Review — Resource Factories + Generated Startup

**Strengths**
- Free-on-init-failure without destroy is correct: `pthread_mutex_destroy`/`cond_destroy` on uninitialized storage is UB.
- Per-queue lock checks close a real false-success hole (native_queue_count masking a bad queue lock).
- `supervisor_add_child`: temp-pointer realloc + commit-after-success fixes list-loss-on-failure; overflow guard is the right companion.
- Failure injection × ASAN/UBSAN/leaks × baseline counterfactuals is the correct validation matrix.
- Honest scope: worker all-start explicitly not claimed; no new public status APIs.

**Risks / verify**
- **Partial-safe scheduler destroy must track init state** — a per-queue flag, or destroy strictly in reverse-init order stopping at the first gap. Never destroy an uninitialized lock.
- **Coro stub:** confirm `fr_coro_spawn` cannot partially attach state before returning NULL; otherwise caller-side free of raw state risks double-free.
- **Generated main cleanup:** after mid-owner failure, ensure scheduler destroy doesn't leak eventloop resources or silently swallow a second failure.
- **Behavioral change:** previously nonNULL-but-corrupt owners now become NULL. Ignore-return callers may null-deref where they once hit silent UB. Fail-fast is preferable, but flag it for any external/legacy call sites.
- **Overflow guard** on `count+1` must precede the realloc, and `size_t` multiplication (if element size applied) must be checked too.

Direction is sound; harden the partial-cleanup and coro-ownership edges before implementation.
