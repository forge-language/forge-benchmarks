## Verdict

Substantially bounded and honest. The no-speedup/nonregression stance is correct and should stay. Three wording problems and five missing caveats below.

## Contradictory / loose wording

1. **"reverse … retain adverse 12worker results"** conflicts with your own numbers: reverse 12w/1024 total = **1.096** (favorable, CI [0.987, 1.257] straddles 1). Only reverse 12w/16 (0.989) is mildly adverse. What's actually true: *forward* shows significant adverse 12w native (total .952 CI [.921,.982]; .872 CI [.762,.973], both exclude 1); *reverse does not replicate it* (0.989 / 1.096, both CIs include 1). That's an order-dependent disagreement, not retained adversity — the existing "uncertainty/systematic effects unresolved" clause already carries it.
2. **Coroutine narrative tension**: "frees unattached raw init and aborts" vs "intentionally aborts per existing init calloc policy". The abort message `factory: rejected state freed` carries the *test harness* prefix, suggesting a free-guard detecting an invalid free rather than (or besides) a calloc-policy abort. The facts don't identify the mechanism; state both candidates or mark mechanism unresolved.
3. **Baseline generated coroutine exits 0; candidate is -6.** So the generated coroutine case is a clean→abort behavior delta, not a reproduced-fault fix. State this explicitly so "8 fixed + 3 generated exit1" isn't read as a fourth generated fix.

## Missing caveats

- **Leak-freedom of the fixed paths is unproven.** `owner_null:true` = pointer cleared, not memory freed. ASan `detect_leaks=1` is claimed only for the 18/18 runtime+stdlib set; no leak run is stated for the 8-case fault suite or the generated suite. `transaction_preserved` covers only `child`.
- **`process-name` candidate reports `name_null:false` under injected malloc fault** — unexplained (different fault site, or stale pointer post-cleanup). Don't let it read as "name handled".
- **`queue` candidate JSON drops `accepted`/`depth_without_start`** present in baseline — those aspects are no longer evidenced; queue fix evidence = exit 0 + owner cleanup only.
- **Generated baseline and candidate both link the same `root-build/lib`**, so that comparison isolates *emitter output*, not runtime. Runtime claims rest solely on 9/9 + 18/18. (Supports your "fault sweep separately" framing — say it.)
- **Fault suite = 8 named injection points, not exhaustive allocation sites; no TSan/concurrency-race evidence anywhere.** Hot-function identity covers 3 selected symbols, and thread.c offsets shifted (fr_mutex_lock 96→128) confirming layout changed elsewhere — your "selected"/"placement" hedges are correct, keep them.
- Minor: baseline severity is understated if read as "two SIGSEGV" overall — the fault suite has 2 (-11 supervisor, child), *plus* 3 more -11 in generated baseline (scheduler/process/supervisor).
- "Supervisor void registration unchanged" isn't borne out by these facts (it's a diff claim) — fine as a scope statement, just attribute it to the diff, not the measurements.

## Confirmed fine

All 8 candidate cases exit 0; generated 3 → exit 1 with diagnostics and `live=0`. stage3==stage4 hash stated as fixed-point only. Disclaimers (all-worker-start, all C callers, macOS/Windows, pins) are genuine absences of claim. Coroutine bounds (no nested-field, no nonNULL enqueueERROR proof) honest. No further benchmark rounds without a concrete hypothesis — agreed; if one ever emerges, the testable one is AB/BA order × 12-worker placement/first-touch, not more repeats of the same design.
