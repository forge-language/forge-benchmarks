# Retained experiment

Linux x86_64, GCC 13.3.0, CMake and GNU ld are required for the recorded byte
comparisons. See environment.json for exact versions and CPU details. Frozen
executables and static archives are included to identify the exact measured
artifacts. Sources include prior uncommitted optimization work; this experiment's
runtime and codegen deltas are separate from working-tree patches.

Run the portable resource replay from an extracted archive:

    TMPDIR=/dev/shm python3 reproduce.py --work /dev/shm/forge-factory-replay

This rebuilds both runtime libraries, checks their exact bytes against the frozen
libraries, recompiles the same eight failure probes and compares status/stdout/
stderr to the recorded baseline/candidate observations. --full-checks additionally
builds the candidate compiler with both local overrides, runs the full CTest
collection (including generated-failure regression) and the self-host fixed point.

Recorded primary commands (source trees originally under
/home/helloworld0822/coding, outputs under /dev/shm/forge-factory-20261015):

    cmake -S forge-runtime -B release-build -DCMAKE_BUILD_TYPE=Release
    cmake --build release-build -j2
    ctest --test-dir release-build --output-on-failure
    cmake -S forge -B root-build -DCMAKE_BUILD_TYPE=Release -DFORGE_ENABLE_LTO=OFF \
      -DFORGE_RUNTIME_SOURCE_DIR=/home/helloworld0822/coding/forge-runtime \
      -DFORGE_STDLIB_SOURCE_DIR=/home/helloworld0822/coding/forge-stdlib
    cmake --build root-build -j2
    TMPDIR=/dev/shm ctest --test-dir root-build --output-on-failure
    cmake --build root-build --target forge-selfhost-verify -j2
    cmake -S forge-stdlib -B combined-asan-build -DCMAKE_BUILD_TYPE=Debug \
      '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' \
      -DFORGE_RUNTIME_SOURCE_DIR=/home/helloworld0822/coding/forge-runtime
    cmake --build combined-asan-build -j2
    ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 TMPDIR=/dev/shm \
      ctest --test-dir combined-asan-build --output-on-failure

bench-builds.json retains exact compilation commands. Dispatch comparisons:

    python3 dispatch_compare.py --baseline ./bench-baseline --candidate ./bench-candidate \
      --output /dev/shm/dispatch-replay --pairs 24 --workers 1 12 --steps 16 1024
    python3 dispatch_compare.py --baseline ./bench-baseline --candidate ./bench-candidate \
      --output /dev/shm/native-reverse-replay --pairs 32 --workers 1 12 --modes native \
      --steps 16 1024 --candidate-first

The dispatch harness explicitly requires CPUs 0..11 and uses taskset. Adapt both
fixtures consistently on another host. Primary kernel excludes constructor/coro
publication time; total includes selected setup/cleanup, not whole process time.
Do not turn the descriptive confidence intervals or reversed follow-up into a
nonregression claim. Both adverse and favorable rows are retained.

Object function comparisons cover pre-link bytes only, not relocations or final
instruction placement. The generated probe uses a constant candidate runtime and
switches emitted C from frozen old/new compilers, isolating caller behavior.
OOM abort tests disable core dumps. Ledger observations are bounded fault tests,
not a full memory-safety proof or platform certification. Immutable dependency pins
are unchanged. No TSan pass is claimed.

SHA256SUMS covers all retained files except itself. Model JSONL, exact requests,
exports, responses and review-resolution.md retain the review trail. No model
opinion is counted as a passing runtime test.
