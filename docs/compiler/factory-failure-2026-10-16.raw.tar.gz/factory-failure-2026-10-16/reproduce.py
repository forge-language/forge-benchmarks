#!/usr/bin/env python3
"""Linux/GNU toolchain replay; all derived output stays in --work."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--work', type=Path, required=True)
parser.add_argument('--full-checks', action='store_true')
args = parser.parse_args()
here = Path(__file__).resolve().parent
work = args.work.resolve()
work.mkdir(parents=True, exist_ok=True)
env = {**os.environ, 'TMPDIR': str(work)}

def run(command, **kwargs):
    return subprocess.run(list(map(str, command)), env=env, check=True, **kwargs)

def no_core():
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

wrap = ['-Wl,--wrap=' + name for name in ('fr_mutex_create', 'fr_cond_create',
        'malloc', 'calloc', 'realloc', 'pthread_mutex_init', 'pthread_cond_init')]
for variant in ('baseline', 'candidate'):
    source = here / (variant + '-runtime')
    build = work / (variant + '-runtime-build')
    run(['cmake', '-S', source, '-B', build, '-DCMAKE_BUILD_TYPE=Release', '-DBUILD_TESTING=OFF'])
    run(['cmake', '--build', build, '-j2'])
    lib = build / 'lib/libforge_runtime.a'
    expected = (here / ('libforge_runtime-' + variant + '.a')).read_bytes()
    assert lib.read_bytes() == expected, f'{variant}: static library bytes differ'
    binary = work / ('factory-' + variant)
    run(['cc', '-std=c11', '-O3', '-I', source / 'include', here / 'factory_probe.c',
         lib, '-pthread', *wrap, '-o', binary])
    recorded = json.loads((here / (variant + '-probes.json')).read_text())['cases']
    for case in recorded:
        result = subprocess.run([str(binary), case['case']], capture_output=True, text=True,
                                timeout=10, preexec_fn=no_core, env=env)
        assert (result.returncode, result.stdout, result.stderr) == (
            case['status'], case['stdout'], case['stderr']), (variant, case['case'], result)

if args.full_checks:
    build = work / 'root-build'
    run(['cmake', '-S', here / 'candidate-root', '-B', build,
         '-DCMAKE_BUILD_TYPE=Release', '-DFORGE_ENABLE_LTO=OFF',
         '-DFORGE_RUNTIME_SOURCE_DIR=' + str(here / 'candidate-runtime'),
         '-DFORGE_STDLIB_SOURCE_DIR=' + str(here / 'candidate-stdlib')])
    run(['cmake', '--build', build, '-j2'])
    run(['ctest', '--test-dir', build, '--output-on-failure'])
    run(['cmake', '--build', build, '--target', 'forge-selfhost-verify', '-j2'])
print('resource-factory replay passed')
