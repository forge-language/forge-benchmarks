#include "forge_runtime.h"
#include "forge/thread.h"
#include <stdio.h>
static int attempts, completed;
int __wrap_fr_thread_start(fr_thread_t **out,fr_thread_fn fn,void *arg) {
    (void)fn;(void)arg;*out=NULL;attempts++;return -1;
}
static void job(void *arg){(void)arg;completed++;}
int main(void) {
    fr_scheduler_t *s=fr_scheduler_create(2);
    if(!s)return 2;
    fr_scheduler_start(s);
    int available=fr_sched_pool_available();
    int submitted=fr_sched_pool_submit(s,job,NULL);
    size_t queued=fr_sched_pool_queued(s);
    fr_scheduler_stop(s);
    fr_scheduler_destroy(s);
    printf("{\"start_attempts\":%d,\"available\":%d,\"submit_status\":%d,\"queued\":%zu,\"completed\":%d}\n",attempts,available,submitted,queued,completed);
    return 0;
}
