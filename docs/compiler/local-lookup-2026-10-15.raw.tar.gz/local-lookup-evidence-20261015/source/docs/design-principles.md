# Forge design principles

**Safe ownership. Massive concurrency. Native speed.**

These goals describe one design: explicit ownership makes resource costs visible,
lightweight processes make independent work practical, and native compilation
keeps that work efficient. Performance changes must preserve the program's
meaning and the ability of other processes to make progress.

Forge is experimental. Full ownership, alias and lifetime checking remain work
to do. These principles guide implementation and review; they do not certify
memory safety or establish performance for unmeasured programs.

## Preserve observable behavior

An optimization needs a reason that the replacement computes the same result,
including failure. Respect the [integer contract](integer-arithmetic.md), operand
evaluation counts, short-circuiting, side effects and live values. A mathematically
equivalent formula can still be wrong when Forge multiplication wraps. An empty
loop can still have a trapping initializer. Allocation failure and rejected sends
are part of resource behavior, not exceptions to correctness.

When equivalence depends on input bounds, check those bounds before entering the
specialized path. Retain the original checked implementation for other inputs
and unsupported targets. Decline a transformation when its proof is incomplete.
Keep compiler proof scans and synthetic-name searches bounded as well: compilation
time and memory are costs users experience.

Derived compiler data belongs to the pass that uses it. Build lookup indexes
after declarations are loaded, borrow names only while their storage is valid,
and release the indexes before that storage changes or the request ends. Preserve
declaration order and namespace precedence when accelerating lookup. Document
the remaining scans and allocation costs; a faster index does not make every
part of compilation logarithmic or establish a new type rule.

Charge setup to work actually performed. A declaration or imported module alone
does not justify building a cache. Bound deferred setup explicitly, and measure
unqueried owners, sparse queries and early hits alongside expensive searches.

Name indexes should lead back to the current binding. Read initialization and
ownership state from that binding, and pair index updates with every scope change.
Use stable positions across owner-array reallocations, check layout assumptions
at compile time, and fail explicitly when an internal index contradicts its owner.
Reusing scratch capacity must respect the lifetime of keys from earlier scopes.

For example, binary modular exponentiation can use reciprocal multiplication
when every intermediate product fits signed int64. A power-of-two divisor also
permits masking, provided the reduction preserves the sign of each wrapped
product. Other inputs retain the original checked operations. The compiler recognizes bindings and operations;
function names, benchmark names and expected output values are not proof.

## Make ownership and resource costs explicit

Moving a value should have a specified owner before and after the operation,
including failure paths. A copy, arena lifetime, mailbox transfer and borrowed
alias have different costs and obligations; document the actual boundary.
Stage0 currently copies an owned string into a mailbox payload on send. This is
not evidence of zero-copy ownership or complete lifetime checking.

Remove redundant allocation or copying only when the affected resource is private
and its lifetime is established. A fast path must not lose cleanup or expose a
partly constructed object on failure. Keep runtime and standard-library ABI
changes in their owning repositories and pin tested dependency revisions.

## Concurrency includes progress

A throughput improvement must preserve the scheduler's synchronization and
cooperative yield boundaries. Faster code between yields does not authorize
removing a yield or holding a shared lock longer. Review cancellation, mailbox
lifetime, idle wakeups and progress of competing work when those paths change.

Measure fairness, errors and tail latency alongside completed work. Distinguish
spawned processes, open connections, in-flight requests and application users.
A finite connection cohort does not establish sustained service capacity, and a
cached response workload does not establish application performance with a
database, TLS or routing.

## Earn speed with reproducible evidence

Use the same source workload, inputs, toolchain flags and dependency revisions
for a comparison. Check outputs independently before accepting timings. Alternate
baseline and candidate runs, record the environment, retain raw samples and
report variation. Include guard misses and existing fast paths when adding a
specialization; extra code and dispatch have costs too.

Measure the compiled program produced by the compiler being proposed. Build
dependencies must invalidate downstream artifacts when their compiler changes;
passing a check against stale output is not evidence for the current source. Label
experiments that patch generated C as prototypes. Keep discarded approaches and
their evidence available, especially when a proxy such as fewer syscalls improves
while the actual workload slows down. A speedup belongs to the measured workload
and environment; it is not a language-wide guarantee.

Prefer reusable transformations with small, reviewable proofs. If an optimization
adds complexity without a measured benefit, improve or remove it. Native speed
includes keeping ordinary programs and the compiler practical to understand.

## AI work stays inspectable

**AI builds. AI tests. AI reviews. Humans decide.**

Use independent agent review to challenge arithmetic proofs, binding assumptions,
failure paths and measurement methodology. Preserve the actual requests and
completed findings. A launched task, routing failure or partial response is not
a completed review. Resolve findings against source and executable evidence;
agreement among agents does not replace verification.

Describe what changed, what was measured and what remains unverified. Human
maintainers retain release and merge decisions under the [RFC process](../RFC_PROCESS.md).

## Evidence for an optimization review

- State the recognized operation, its preconditions and the equivalence argument.
- Exercise accepted inputs, guard boundaries, failure paths and rejected shapes
  against an independent oracle. Cover applicable backends and public entry points.
- Provide reproducible before/after commands, source and raw measurements with
  the scope and limitations of the performance claim.
- Run relevant regressions and self-hosting checks; record any checks that could
  not be performed instead of treating them as passes.

See the [architecture](../ARCHITECTURE.md), [roadmap](../ROADMAP.md) and
[historical optimization experiments](optimization-rules.md).
