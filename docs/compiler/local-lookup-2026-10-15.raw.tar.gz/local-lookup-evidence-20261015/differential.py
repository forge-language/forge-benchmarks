from pathlib import Path
import subprocess,json,hashlib
p=Path('/dev/shm/forge-locals-20261015');out=p/'differential';out.mkdir(exist_ok=True)
compilers={'baseline':p/'forge-baseline','candidate':Path('build/bin/forge').resolve()}
patterns={
 'shadow':('let value:int=41;','{let value:string="inner";println(value);}println(value);return 0;',0),
 'for':('let value:string="outer";','for(let value:int=0;value<2;value=value+1){println(value);}println(value);return 0;',0),
 'if_ok':('let value:int;','if(flag){value=1;}else{value=2;}println(value);return 0;',0),
 'if_bad':('let value:int;','if(flag){value=1;}println(value);return 0;',1),
 'match':('let value:int;','match flag{0=>{value=1;}_=>{value=2;}}println(value);return 0;',0),
 'move_bad':('own let payload:string="owned";','send 0,Drop,move payload;println(payload);return 0;',1),
 'move_return':('own let payload:string="owned";','if(flag){send 0,Drop,move payload;return 0;}println(payload);return 0;',0),
 'move_loop':('own let payload:string="owned";','while(flag){send 0,Drop,move payload;}return 0;',1),
 'move_shadow':('own let payload:string="outer";','for(let i:int=0;i<2;i=i+1){own let payload:string="inner";send 0,Drop,move payload;}println(payload);return 0;',0),
 'initializer':('let value:int=41;','{let value:string=value;}return 0;',1),
}
rows=[]
for n in [0,16,32,33,64,128]:
 for name,(initial,tail,wanted) in patterns.items():
  source=out/f'{name}-{n}.fg'
  pad=''.join(f'let p{i}:int=seed+{i};' for i in range(n))
  source.write_text('fn work(flag:int):int{'+initial+'let seed:int=7;'+pad+tail+'}fn after():string{let seed:string="after";return seed;}native main{work(0);println(after());return 0;}')
  results={}
  for label,compiler in compilers.items():
   r=subprocess.run([str(compiler),str(source),'--check','--diagnostics-json'],capture_output=True,text=True,timeout=20)
   results[label]={'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
  assert results['baseline']==results['candidate'],(source,results)
  assert results['baseline']['returncode']==wanted,(source,wanted,results)
  hashes={}
  if wanted==0:
   for label,compiler in compilers.items():
    c=source.with_name(source.stem+'-'+label+'.c')
    r=subprocess.run([str(compiler),str(source),'--emit-c','-o',str(c)],capture_output=True,text=True,timeout=20)
    assert r.returncode==0,r.stderr
    hashes[label]=hashlib.sha256(c.read_bytes()).hexdigest()
   assert len(set(hashes.values()))==1,(source,hashes)
  rows.append({'source':str(source),'locals':n,'pattern':name,'results':results,'c_sha256':hashes})
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'cases agree on status/diagnostics; all accepted emitted C identical')
