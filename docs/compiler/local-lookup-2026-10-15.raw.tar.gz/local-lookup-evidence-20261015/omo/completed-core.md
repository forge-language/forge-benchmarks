**Verdict: no counterexample under the stated preconditions. All seven invariants hold.**

**1. Bounds & decreasing chains.** Slots are 1-based (`i+1`) into `heads`; `entries` indices are `slot-1`. Activation and push cap entries at `count`/`count+1` ≤ capacity. `rehash` walks `i` ascending, setting `next = heads[bucket]` then `heads[bucket] = i+1`, so every link points to a strictly smaller index; walks terminate. Lookup can never cycle or index past `count-1`.

**2. Latest-shadow order.** Both `rehash` (ascending rebuild) and `push` (append + head-insert) place the highest index of a bucket at its head, so `find`’s head-first walk returns the latest binding. Growth to `capacity*2` buckets rehashes the full active set with the same ascending order, preserving shadow order.

**3. Reverse truncate through collisions.** Because entries are pushed in ascending index order, the entry being removed (`i` descending from `count-1`) is always the head of its bucket. The `heads[bucket] != i+1` check is therefore exact, and restoring `heads[bucket] = entries[i].next` correctly re-links any colliding predecessor. Mismatch only fires on caller/scope corruption, as intended.

**4. Pooled reuse.** Truncate-to-zero sets `active = false` and resets `probes`; subsequent `push` only bumps `count` (no hashing). `find`’s lazy activation re-copies only `0..count-1` from the live bindings, so popped keys are never rehashed. Non-zero truncate leaves `active` true and unlinks only the removed suffix—also correct.

**5. Activation copies.** `memcpy(&index->entries[i].name, bindings + i*stride, sizeof(ForgeStr))` reads the first member by value (pointer+len), never a pointer into the reallocating bindings array. Index/heads reallocs store only indices, so owner growth is safe. Name `data` is borrowed per the documented contract; pop removes it before any stale deref.

**6. Hash vs `forge_str_eq`.** The FNV loop stops at the first NUL (`name.data[i]`), matching `strncmp`’s NUL-stop; `name.len` is mixed into the final hash, so equal-length strings differing only after a NUL still collide consistently with `strncmp`’s “equal” result, and different lengths never match (checked first in `forge_str_eq`). Agreement holds including embedded NULs.

**7. Capacity arithmetic.** `maximum` bounds both `entries` bytes and the `capacity*2` `heads` allocation (`SIZE_MAX/sizeof(heads)/2`). Doubling is guarded by `capacity > maximum/2` before `capacity *= 2` and before `capacity*2` in push/activation. `count > SIZE_MAX/stride` guards the scan stride. All `forge_die` paths fail closed.

**Minor note (not a bug under preconditions):** `forge_local_hash` dereferences `name.data` when `len > 0`; a NULL `data` with nonzero `len` would be UB, but the contract (names borrowed from live bindings) excludes that. Caller-side “mirror every push/pop and pass live `count`” is enforced by the `count != index->count` die in `find`, not silently tolerated.

Core index is sound.
