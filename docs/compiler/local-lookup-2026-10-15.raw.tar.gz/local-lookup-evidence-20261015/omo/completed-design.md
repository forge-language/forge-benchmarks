I detect **investigation/design-review** intent — read-only audit of specific local-variable machinery plus a design plan for a per-pass adaptive name index. Routing: targeted `codegraph_explore` on the named symbols only, then synthesis. No edits, no network, no unrelated files.

Core primitives retrieved. Now I need the full `statement()` body (STMT_FOR + snapshot/restore sites) and every `local_count` mutation in codegen.c.

Two gaps remain: every `local_count` write site in codegen.c, and the 3 `cg_push_local` / 10 `cg_lookup_local` caller contexts (pop discipline + coroutine flattening).

Mutation-site census is nearly complete. Remaining: `emit_let` push context, `emit_block_stmts` callers (while/match/block pop discipline), and semantic `body()` callers (coroutine/process scope-zero).

Final census check — all `local()` callers and any address-taking of `c->locals` (pointer-escape risk):

Line 56 (`return i == SIZE_MAX ? NULL : &c->locals[i]`) contradicts the earlier codegraph render of `local()`. Verifying ground truth directly:

The file now contains `forge_local_find`/`forge_local_push` — absent from my first snapshot. Either concurrent edits are underway or a partial index implementation already exists. Checking immediately:

A draft `local_index.h` implementation already exists in the working tree (uncommitted), wired into both files. Reading it — it's the direct subject of this design review:

Draft found. Verifying remaining design-critical details on current disk: `cg_lookup_local` fallback, `Check`/`Codegen` initialization of the index, and a fresh mutation-site census (file changed since my first snapshot):

# Design Review: Per-Pass Adaptive Local-Name Index

**Ground truth note:** the working tree already contains an uncommitted draft of exactly this design — new `compiler/local_index.h`, hooks wired into `semantic.c`/`codegen.c`, plus test additions (git status: `M` ×3 + `??` ×2). My initial codegraph fetch served a stale pre-draft index (linear `local()`); this review is grounded in the **current on-disk draft**. Line-level implementation audit + test runs deferred per instructions. `codegen_js.c` (fixed 1024-entry `locals[]`) is out of scope.

---

## 1. Mutation-site census (every stack change, hook status)

**compiler/semantic.c** — owner: `c->count` / `c->locals`

| Site | Operation | Hook |
|---|---|---|
| `declare()` :58–61 | `count++` (params via `body`, `STMT_LET`) | `forge_local_push` ✓ |
| `block()` :429–434 | `count → saved` | `forge_local_truncate` ✓ |
| `STMT_FOR` :370 | `count → outer` (after joins) | `forge_local_truncate` ✓ |
| `body()` :437–438 | `count → 0` (function/process/coro boundary) | `forge_local_truncate` ✓ |
| `local()` :54–57 | lookup → index | `forge_local_find` ✓ (but see gap G1) |
| teardown :528 | free | `forge_local_free` ✓ |
| `snapshot`/`restore`/joins (IF :318–336, WHILE :340–350, FOR :353–368, MATCH :403–423) | `initialized` flags by absolute index | **no hook needed** — count-neutral ✓ |
| `STMT_LET` owned write (`locals[count-1].owned`) | field write | no hook ✓ |

**compiler/codegen.c** — owner: `cg->local_count` / `cg->locals`

| Site | Operation | Hook |
|---|---|---|
| `cg_begin_function` :80–81 | `count → 0` | `forge_local_truncate(…,0)` ✓ |
| `cg_push_local` :310–316 (params ×3 call paths, coro flat lets, `emit_local_let`) | `count++` | `forge_local_push` ✓ |
| `emit_block_stmts` :1134–1136 | restore (if/while/for-body/match-arms/nested block) | `truncate(saved)` ✓ |
| `STMT_FOR` :2531/2581 | save-before-init / restore | `truncate(saved)` ✓ |
| `emit_coro_fn` :1098 | bare `local_count = 0` (**was the one unpaired write**) | `truncate(…,0)` ✓ |
| `cg_is_local` :265–267 / `cg_lookup_local` :323–326 | lookup | `find` ✓; miss fallback `forge_type_int()` **preserved** for the one unguarded call site (`:396`) |
| teardown :307 | free | ✓ |
| `moved_count`/`hoisted_count`/`invariant_mod_count` resets | unrelated counters | correctly untouched ✓ |

No naked un-hooked writes remain: rg shows every `count =` paired adjacently with `truncate`. `Check c = {.program = p}` (:498) and `Codegen cg = {…}` (:2986/:3012) zero-init `local_index` via designated initializers ✓. One index per pass instance (`functions()` / `codegen_emit`), freed at pass end — "per-pass" ✓.

**Safety net:** `forge_local_find` hard-dies on `count != index->count` ("scope mismatch"), and `truncate` asserts the popped entry is its bucket head. Any future missed hook fails closed instead of returning wrong names — this is the design's strongest property. Invariant worth documenting at the `locals` field declarations: *every write to `count` must be paired with `truncate` before the next `find`.*

## 2. Scope / initializer ordering

- **`let`**: init expression type-checked **before** `declare` → push. Self-referential init sees the *outer* binding; index push lands after evaluation ✓.
- **`if`**: cond → `n` snapshot → block (pops internally to `n`) → then-snapshot → `restore` → else-block → joins over `[0,n)` — construct-level count never changes, so **no construct hook exists or is needed** ✓.
- **`for`**: `outer` → init push → `n` snapshot → body (self-pops to `n`) → step → optional re-run → joins over `[0,n)` → **`truncate(outer)` last**. Joins write flags into `[outer,n)` while still counted live; the for-init binding's joined flag dies with its entry ✓ ordering correct.
- **`while` / `match`**: per-arm `restore` + `block` are count-neutral; joins are index-addressed flag writes only ✓ no hook.
- **`restore()`/`snapshot()`**: touch only `initialized` (bool array keyed by absolute binding position). The index stores names + bucket links only — zero interference by construction ✓.
- **Function boundary**: `truncate(0)` runs *before* `count = 0`, then params push — double `truncate(0)` (coro `:1098` → `cg_begin_function` `:1104`) is idempotent ✓.
- **Push protocol**: both owners increment their counter *first*, then `forge_local_push` appends at `index->count` — counters converge each time ✓.

## 3. Conformance vs the stated requirements

| Requirement | Verdict |
|---|---|
| Lookups return binding indices, not `Local*` | **Partial** — `forge_local_find` → `SIZE_MAX`/index ✓; codegen side pointer-free ✓; but semantic `local()` still wraps to `Local*` (**G1**) |
| Reverse lookup, latest name wins | ✓ linear scans descend; rehash inserts ascending so head = highest index, links strictly decrease |
| Cache stores borrowed names + bucket links only | ✓ `ForgeLocalEntry {ForgeStr name; size_t next}` — no type/initialized/owned |
| Push hooks update live cache | ✓ `declare`/`cg_push_local` |
| Reverse pop restores colliding/shadowed heads | ✓ suffix-pop in descending order makes each entry provably the bucket head; restore `heads[b] = entry.next` reconnects both hash collisions and shadowed same-name predecessors |
| Scope zero disables cache, reuses capacity | ✓ `truncate(0)` → `active=false`, `probes=0`; buffers freed only at `forge_local_free`; reactivation reallocs only if `capacity` grows |
| Expensive histories activate chained buckets; cheap stay linear | ✓ `!active && count > 32 && probes/4 >= count`; `probes` accumulates *actual scanned elements* (misses ≈ full scans, top-of-stack hits ≈ 1) and resets only at scope zero |
| Function-array realloc must not invalidate entries | ✓ entries hold `ForgeStr` by value (AST-borrowed data, not array slots) + integer indices; backfill `memcpy`'s from live array at activation; no `Local*`/`&locals[i]` stored |

Also correct: **no negative/memoized lookups** — probe keys like `forge_str(builder)` (stack buffers, :1936 etc.) enter the cache only via push, never via find ✓. Hash folds length and stops at NUL to mirror `forge_str_eq`/`strncmp` semantics ✓. Head sentinel `i+1` keeps binding 0 distinguishable from empty ✓.

## 4. Residual hazards (design-level)

- **G1 — `local()` facade returns `Local*`** (semantic :54–57). Five sites (`EXPR_IDENT`, `EXPR_FIELD`, `STMT_ASSIGN`, `STMT_SEND`, `thread_spawn`) still hold pointers into a reallocating array. Safe *today* only because no `declare()` can occur between `local()` and last use (`expression()` never declares; `STMT_SEND` localizes after both expressions) — an implicit invariant nothing enforces. Contract cleanup: return `size_t`, index at use sites, or document the invariant.
- **G2 — stride coupling**: `find` `memcpy`s `ForgeStr` from `bindings + i*stride`, assuming `ForgeStr` is the first member of `Local` and `ForgeLocal`. `stride < sizeof(ForgeStr)` dies, but a silently *reordered/prefixed* struct corrupts lookups. Needs `static_assert(offsetof(...) == 0)` (implementation audit item).
- **G3 — coroutine flat-locals (pre-existing, now index-visible)**: `emit_coro_fn` pre-pushes params + **all** `collect_coro_lets` — including both arms of an `if`. Mutually-exclusive same-name lets (`if c { let x:int } else { let x:string }`) both go flat; the *else* copy is the whole-coroutine head until the arm's own `emit_local_let` re-pushes the correct copy inside its block. Correct because (a) type-sensitive uses only occur inside arm blocks where the inner copy is head, (b) cross-scope uses are rejected by semantic, (c) fresh-name probes are existence-only. Inner duplicate pops at block exits restore the flat head via the shadow-restore path ✓ — but pin this with an `--emit-c` test (below). Branch handling in `collect_coro_lets` is the one place where "latest wins" can point at a *different branch's* type; everything else is lexical.
- **G4 — `local()` NULL path after `error()`**: `error_at` exits(1), so `l->type` post-error is unreachable — index conversion must keep the guard *before* deref, same order.
- **G5 — codegen_js divergence**: JS backend keeps its own fixed 1024 linear `locals[]` — fine to exclude now, but note the two backends' local-resolution logic is drifting.

## 5. High-value test cases

**Behavior preservation / ordering**
1. Shadow round-trip: nested redeclare → after block exit, outer binding's index/type/`initialized` identical to reference reverse scan (both passes).
2. `for` truncation: `for (let i=…) {}` then a second `let i` → distinct binding; joins/owned-flags on the discarded loop var unchanged (ownership/diagnostics suites already extended in the diff — verify in impl audit).
3. Owned-string joins through `if/while/match` with index active — golden outputs byte-identical to linear baseline (differential run of full test suite is the cheap version of this).
4. Realloc boundary: >16 semantic / >8 codegen locals, then look up index 0 — borrowed-name + index safety across `forge_array_reserve` doubling.
5. Desync fail-closed: unit test that skips one hook → expect `local index scope mismatch` die (locks the pairing invariant).

**Adaptive machinery**
6. Forced-linear vs forced-activated runs of the same random scope generator → every lookup returns the same index (activation invariance).
7. Threshold: `count=33` + ≈4 full misses activates; `count≤32` never activates regardless of lookup volume; probes reset at function boundary.
8. Capacity reuse: fn1 activates (allocates), fn2 stays linear, fn3 reactivates — index capacity monotonic, no free in between.
9. Engineered same-bucket name pair: push both, pop suffix → assertion in `truncate` holds and the older name still resolves (head restore).

**Coroutine / codegen**
10. Coro with lets at nested depths, shadowed inner let, **both** `for` paths (inline :2552 and yield-desugared :2568), and same-name probes in the following spawn fn (empty index, `count=0` early return).
11. Branch-duplicate flat lets (G3) — assert emitted C types inside each arm match the arm-local declarations.
12. Fresh-name loops (`builder`/`byte`/… collision probes) with index active → generated names byte-identical to baseline (probe determinism; structurally, probe strings can never appear in entries since only push inserts).

**Deferred to the implementation audit:** line-level review of `local_index.h` (rehash growth math at `count == buckets/2`, `memcpy` aliasing, activation hysteresis), running `ctest`, reviewing the test/README/CMake/ARCHITECTURE diffs already staged, and the G2 static_assert.
