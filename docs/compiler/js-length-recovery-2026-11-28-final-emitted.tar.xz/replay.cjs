const assert = require("node:assert/strict");
const {execFileSync} = require("node:child_process");
const {createHash} = require("node:crypto");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const [, , output] = process.argv;
if (!output) throw Error("Usage: taskset -c CPU node replay.cjs OUTPUT.json");
const archive = path.resolve(__dirname);
const hash = bytes => createHash("sha256").update(bytes).digest("hex");
const affinity = fs.readFileSync("/proc/self/status","utf8").match(/^Cpus_allowed_list:\s*(\S+)/m)[1];
if (!/^\d+$/.test(affinity)) throw Error("Pin the parent process to one CPU");
const shapes = [
  ["historical_long","historical","x",1024,"界😀",256,35000],
  ["previous_long","previous","x",1024,"界😀",256,35000],
  ["previous_short_ascii","previous","INFO",1," status=ok",1,120000],
  ["previous_ascii_16384","previous","x",16384,"y",16384,4000],
];
const report = {utc:new Date().toISOString(), pairs:10, affinity, node:process.version,
  cpu_model:os.cpus()[0].model, platform:os.version(), node_sha256:hash(fs.readFileSync(process.execPath)),
  sha256:Object.fromEntries(["historical","final","previous","bridge","replay"].map(name =>
    [name+".cjs",hash(fs.readFileSync(path.join(archive,name+".cjs")))])), cases:{}};
function quantile(nums,q) {
  const sorted=nums.slice().sort((x,y)=>x-y);
  const index=(sorted.length-1)*q, j=Math.floor(index);
  return sorted[j] + (index-j)*(sorted[Math.ceil(index)]-sorted[j]);
}
const work=fs.mkdtempSync(path.join(os.tmpdir(),"forge-length-replay-"));
try {
  for (const [index, row] of shapes.entries()) {
    const [name,baseline,left,leftCount,right,rightCount,iterations]=row;
    const inputs=[left.repeat(leftCount),right.repeat(rightCount)];
    const config={operation:"length",iterations,inputs,boxed:false};
    const configPath=path.join(work,"config.json");
    const serialized=JSON.stringify(config);
    fs.writeFileSync(configPath,serialized);
    const expected=String(iterations*(Buffer.byteLength(inputs[0])+Buffer.byteLength(inputs[1])));
    const samples=[];
    for (let pair=0;pair<report.pairs;pair++) {
      const order=(pair+index)%2===0?[baseline,"final"]:["final",baseline];
      const values={};
      for (const label of order) {
        const result=JSON.parse(execFileSync(process.execPath,["--require",path.join(archive,"bridge.cjs"),
          path.join(archive,label+".cjs"),configPath],{encoding:"utf8",timeout:120000}));
        assert.equal(result.result,expected);
        assert.ok(result.ns>0);
        values[label]=result;
      }
      samples.push({order,values});
    }
    const paired=samples.map(s=>100*(s.values.final.ns/s.values[baseline].ns-1));
    const ms=label=>quantile(samples.map(s=>s.values[label].ns),0.5)/1e6;
    report.cases[name]={baseline,inputs_repeats:[[left,leftCount],[right,rightCount]],iterations,
      config_sha256:hash(serialized),expected,samples,median_ms:{baseline:ms(baseline),final:ms("final")},
      paired_change_pct:{median:quantile(paired,0.5),q1:quantile(paired,0.25),q3:quantile(paired,0.75)}};
    console.log(name,ms(baseline).toFixed(2),ms("final").toFixed(2),quantile(paired,0.5).toFixed(1)+"%");
  }
  fs.writeFileSync(output,JSON.stringify(report,null,2)+"\n");
} finally {
  fs.rmSync(work,{force:true,recursive:true});
}
