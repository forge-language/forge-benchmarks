"use strict";
const __forge=(()=>{
const wrap=v=>BigInt.asIntN(64,v),numeric=v=>typeof v==='boolean'?BigInt(v):v;
const arithmetic=(a,b,op)=>{a=numeric(a);b=numeric(b);if(typeof a==='bigint'&&typeof b==='bigint'){if((op==='div'||op==='mod')&&(b===0n||(a===-9223372036854775808n&&b===-1n)))throw new RangeError('Forge integer division');return wrap(op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b);}a=Number(a);b=Number(b);return op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b;};
const bytes=s=>new TextEncoder().encode(s),decode=b=>new TextDecoder('utf-8',{fatal:true}).decode(b);
let substringDecoder;
const substring=(s,a,n)=>{
  if(a<0n||n<0n)return null;
  if(shortString(s)&&typeof a==='bigint'&&typeof n==='bigint'&&!/[^\x00-\x7f]/.test(s))
    return s.slice(Number(a),Number(a+n));
  const part=bytes(s).subarray(Number(a),Number(a+n));
  if(!substringDecoder)substringDecoder=new TextDecoder('utf-8',{fatal:true});
  return substringDecoder.decode(part);};
const eq=(a,b)=>{a=numeric(a);b=numeric(b);return typeof a==='number'&&typeof b==='bigint'||typeof a==='bigint'&&typeof b==='number'?Number(a)===Number(b):a===b;},i=v=>BigInt(v);
const cbytes=s=>{s=s==null?'':s;const end=s.indexOf(String.fromCharCode(0));return bytes(end<0?s:s.slice(0,end));};
const shortString=s=>typeof s==='string'&&s.length<=64;
const beforeNul=s=>{const end=s.indexOf('\0');return end<0?s:s.slice(0,end);};
let shortEncoder,shortBuffer;
const encodePrefix=s=>{
  if(!shortEncoder)shortEncoder=new TextEncoder();
  if(!shortEncoder.encodeInto)return -1;
  if(!shortBuffer)shortBuffer=new Uint8Array(3*64);
  return shortEncoder.encodeInto(s,shortBuffer).written;};
const index=(s,n)=>{
  if(typeof s!=='string')return s[Number(n)];
  if(typeof n==='bigint'){
    const j=Number(n);
    if(j<0||j>=3*s.length)return -1n;
    if(s.length<=64||j<189){
      const size=encodePrefix(s);
      if(size>=0)return j<size?BigInt(shortBuffer[j]):-1n;
    }
  }
  const b=bytes(s),j=Number(n);
  return j<0||j>=b.length?-1n:BigInt(b[j]);};
const loopIndex=(cache,s,n)=>{
  if(typeof s!=='string'||typeof n!=='bigint'||s.length<=64||s.length>65536)return index(s,n);
  const j=Number(n);
  if(cache.text!==s){
    if(j<189||j>=3*s.length)return index(s,n);
    cache.data=bytes(s);cache.text=s;
  }
  return j<0||j>=cache.data.length?-1n:BigInt(cache.data[j]);};
const handles=new Map();let next=1n;const store=v=>{const h=next++;handles.set(h,v);return h;};
const view=h=>handles.get(h),builder=h=>{const b=handles.get(h);return b&&b.kind==='builder'?b:null;};
const reserve=(b,n)=>{if(n<=b.data.length)return;let cap=Math.max(64,b.data.length);while(cap<n)cap*=2;const d=new Uint8Array(cap);d.set(b.data.subarray(0,b.len));b.data=d;};
const range=(v,a,n)=>{if(!v||v.kind!=='view'||a<0n||n<0n)return null;const size=BigInt(v.data.length),from=a<size?a:size,left=size-from;return [Number(from),Number(n<left?n:left)];};
const appendBytes=(h,d)=>{const b=builder(h);if(!b)return 0n;reserve(b,b.len+d.length);b.data.set(d,b.len);b.len+=d.length;return h;};
return {add:(a,b)=>typeof a==='string'&&typeof b==='string'?a+b:arithmetic(a,b,'add'),sub:(a,b)=>arithmetic(a,b,'sub'),mul:(a,b)=>arithmetic(a,b,'mul'),div:(a,b)=>arithmetic(a,b,'div'),mod:(a,b)=>arithmetic(a,b,'mod'),eq,ne:(a,b)=>!eq(a,b),lt:(a,b)=>a<b,le:(a,b)=>a<=b,gt:(a,b)=>a>b,ge:(a,b)=>a>=b,index,loopIndex,println:(...v)=>console.log(v.map(x=>typeof x==='boolean'?(x?'1':'0'):String(x)).join('')),
fr_str_len:s=>{const n=shortString(s)?encodePrefix(s):-1;return i(n<0?bytes(s).length:n);},
fr_str_concat:(a,b)=>a+b,fr_str_eq:(a,b)=>i(a===b),fr_str_sub:substring,fr_str_contains:(s,x)=>i(s.includes(x)),fr_str_trim:s=>s.trim(),fr_str_char_at:index,fr_str_append:(s,c)=>{if(c<0n||c>127n)throw new RangeError('JavaScript strings require valid UTF-8');return s+String.fromCharCode(Number(c));},fr_str_append_str:(s,t)=>s+t,fr_str_from_int:String,fr_str_arena_reset:()=>{handles.clear();return 0n;},
fr_str_view:s=>store({kind:'view',data:cbytes(s)}),fr_str_view_len:h=>{const v=view(h);return i(v&&v.kind==='view'?v.data.length:0);},
fr_str_view_at:(h,n)=>{
  const v=view(h);if(!v||v.kind!=='view')return -1n;
  if(typeof n==='bigint'){
    const pos=Number(n);
    return pos<0||pos>=v.data.length?-1n:BigInt(v.data[pos]);
  }
  return n<0n||n>=BigInt(v.data.length)?-1n:BigInt(v.data[Number(n)]);},
fr_str_view_sub:(h,a,n)=>{const v=view(h),r=range(v,a,n);return r?decode(v.data.subarray(r[0],r[0]+r[1])):null;},
fr_str_view_matches:(h,a,s)=>{
  const v=view(h);
  if(!v||v.kind!=='view'||s==null||a<0n||a>BigInt(v.data.length))return 0n;
  let from=Number(a),needle,length;
  if(typeof s==='string'){
    let j=0;
    for(;j<s.length;j++){
      const c=s.charCodeAt(j);
      if(c===0)return 1n;
      if(c>127)break;
      if(v.data[from++]!==c)return 0n;
    }
    if(j===s.length)return 1n;
    s=s.slice(j);
    if(s.length<=64){
      s=beforeNul(s);
      length=encodePrefix(s);
      if(length>=0)needle=shortBuffer;
    }
  }
  if(!needle){needle=cbytes(s);length=needle.length;}
  if(length>v.data.length-from)return 0n;
  for(let j=0;j<length;j++)if(v.data[from+j]!==needle[j])return 0n;
  return 1n;},
fr_str_view_append_byte:(h,c)=>{const v=view(h);if(!v||v.kind!=='view')return 0n;return store({kind:'view',data:cbytes(decode(v.data)+String.fromCharCode(Number(c)))});},
fr_str_builder:()=>store({kind:'builder',data:new Uint8Array(0),len:0}),fr_str_builder_with_capacity:n=>{if(n<0n||n>BigInt(Number.MAX_SAFE_INTEGER))return 0n;try{return store({kind:'builder',data:new Uint8Array(Number(n)),len:0});}catch{return 0n;}},fr_str_builder_append:(h,s)=>{
  if(shortString(s)){
    s=beforeNul(s);
    const n=encodePrefix(s);
    if(n>=0)return appendBytes(h,shortBuffer.subarray(0,n));
    return appendBytes(h,bytes(s));
  }
  return appendBytes(h,cbytes(s));},
fr_str_builder_append_view:(h,vh,a,n)=>{const v=view(vh),r=range(v,a,n);return r?appendBytes(h,v.data.subarray(r[0],r[0]+r[1])):0n;},
fr_str_builder_char:(h,c)=>{const b=builder(h);if(!b||c<=0n||c>255n)return 0n;reserve(b,b.len+1);b.data[b.len++]=Number(c);return h;},
fr_str_builder_finish:h=>{const b=builder(h);return b?decode(b.data.subarray(0,b.len)):null;},fr_str_builder_finish_take:h=>{const b=builder(h);if(!b)return null;const s=decode(b.data.subarray(0,b.len));b.data=new Uint8Array(0);b.len=0;return s;},
fr_abs_i:x=>x<0n?-x:x,fr_abs_f:Math.abs,fr_min_i:(a,b)=>a<b?a:b,fr_max_i:(a,b)=>a>b?a:b,fr_clamp_i:(x,a,b)=>x<a?a:x>b?b:x,fr_pow_i:(a,b)=>{if(b<0n)return 0n;let r=1n;while(b>0n){if(b&1n)r=wrap(r*a);a=wrap(a*a);b>>=1n;}return r;},fr_time_now_ms:()=>i(Date.now()),
fr_json_get_string:(s,k)=>{const v=JSON.parse(s)[k];return typeof v==='string'?v:'';},fr_json_get_int:(s,k)=>{const v=JSON.parse(s)[k];if(!Number.isSafeInteger(v))throw new RangeError('Use the lossless browser JSON module');return i(v);},fr_json_stringify_str:(k,v)=>JSON.stringify({[k]:v}),fr_json_stringify_int:(k,v)=>'{'+JSON.stringify(k)+':'+String(v)+'}'};})();
function fr_lower(fr_url) { const f=globalThis.ForgeNative?.["lower"]; if(typeof f!=='function') throw new Error('Missing Forge JavaScript FFI'); return f(fr_url); }
function fr_measure(fr_repository,fr_substring) { const f=globalThis.ForgeNative?.["measure"]; if(typeof f!=='function') throw new Error('Missing Forge JavaScript FFI'); return f(fr_repository,fr_substring); }
function fr_canonical_repo(fr_url) {
  let fr_value=fr_lower(fr_url);
  let fr_n=__forge.fr_str_len(fr_value);
  if ((Boolean(__forge.gt(fr_n,(4n))) && Boolean(__forge.ne(__forge.fr_str_eq(__forge.fr_str_sub(fr_value,__forge.sub(fr_n,(4n)),(4n)),".git"),(0n))))) {
    fr_value=__forge.fr_str_sub(fr_value,(0n),__forge.sub(fr_n,(4n)));
  }
  return fr_value;
}

function fr_substring(fr_value,fr_start,fr_length) {
  return __forge.fr_str_sub(fr_value,fr_start,fr_length);
}

function __forge_main() {
  fr_measure(fr_canonical_repo,fr_substring);
  return (0n);
}
__forge_main();
