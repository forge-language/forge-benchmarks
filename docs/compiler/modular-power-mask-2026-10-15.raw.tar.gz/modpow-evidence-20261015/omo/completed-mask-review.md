READ-ONLY audit of `emit_bounded_mod_pow` (codegen.c:2273–2302), the final power-of-two path only.

## Verdict: Correct. No counterexample found.

**Emitted shape** (renamed): `d>1 && (d&(d-1))==0 && e>0` → `mask=d-1`; `f=(u64)base&mask`; if `base<0 && f` then `f-=d` (u64); `r=1, pw=(u64)e`; bit0 folds `r=f` else `r=1`; `pw>>=1`; loop: `p=f*f; f=p&mask; if((p>>63)&&f) f-=d;` then if bit set same for `r*=f`; `pw>>=1`; `return __forge_i64_bits(r)`.

**1. Truncating-remainder lemma (proven).** For d=2^k, any int64 n with bit pattern u: n≡u (mod 2^64) hence n≡(u&mask)=r0 (mod d) since d|2^64. The unique truncating remainder in (−d,d) with sign(n) or zero is exactly: `r0` if n≥0 or r0=0, else `r0−d`. The emitted guard `p>>63` is precisely sign(n) as two's-complement int64; `r0!=0` is the zero case. Applied both at init (n=base, signed test on `base`) and after each product (n=wrapped product). Matches C99/Forged `%` on int64 exactly.

**2. Guard subtraction is safe.** Only runs with r0∈[1,d−1], d≤2^62 (2^63 is negative as int64 so excluded by `d>1`). Result 2^64+r0−d ∈ [2^64−2^62+1, 2^64−1]: pure unsigned wrap (defined), bit 63 set, low k bits still ≡ r0 (mod d), and the bit pattern is exactly the int64 value r0−d. No UB anywhere: all arithmetic in the path is uint64; the only signed expression `(d&(d-1))` is short-circuit-protected by `d>1` (so INT64_MIN never reaches `d-1`).

**3. Recurrence equivalence (proven).** Two's-complement property: low 64 bits of true product a·b equal (uint64)a·(uint64)b — identical to Forge's `__forge_mul_i64` wrap. Both source and fast path then apply truncating `%`/mask-reduction to the *same wrapped value*, so each step computes the identical bit pattern. Init: `r=f` when bit0 set equals source `1*factor%d` since |f|<d implies rem(1·f)=f. Squaring order: after init, factor=base^1, pw holds bits≥1; loop j squares to base^{2^{j+1}} then conditionally multiplies — matches source's bit-(j+1) iteration exactly. Source's final dead square is correctly omitted (factor unused after). LSB-first structure, no off-by-one.

**4. Requested cases (all verified by the lemma).**
- d=2, 2^31, 2^32, 2^62: all pass guard, mask correct, 2^63 excluded by signed `d>1`.
- base=INT64_MIN (u=2^63): r0=0 for all four d → f=0, no subtract; rem=0. ✓ INT64_MIN+1: r0=1 → f=1−d (e.g. d=2^31 gives −2147483647 = true C remainder; checked against trunc(n/d) by hand). ✓ base=−1: f=d−1−d=−1 for every d. ✓ base=2^62−1, d=2^62: f=base. ✓
- e=0: guard `e>0` rejects; falls through to unchanged reciprocal/wrapping body which returns 1 (loop never runs) — matches source. e=1: r=f, loop skipped. e=2,3: traced, match source bit-for-bit. e=INT64_MAX: `(u64)e` legal after signed `e>0`; 62 loop iterations, terminates; source `power/2` on nonneg ≡ `>>=1`. ✓

**5. Traps retained.** Fast path requires d>1, so d=0 (mod-by-zero), d=1, and all negative d (incl. −1, INT64_MIN) fall through to the unchanged body — its initial `base%modulus` trap and any INT64_MIN/−1 behavior are untouched. For entered cases (d power-of-two ≥2, any base, e≥1) the source recurrence divides only by d or 2 and multiplies wrapping, so no trap is skipped.

**6. Scoping/emission order.** Fast path emits *before* the reciprocal `#if` block and returns unconditionally on entry; its eight locals close at line 2302, so the reciprocal block's same names don't collide. `__forge_i64_bits` (line 2804) is the correct return conversion (result may be a negative remainder bit pattern like 0xFFFF…FF for −1).

**Bottom line:** signed truncating-remainder equivalence, full recurrence equivalence (including the intentional skipped first ×1 and dead final square), unsigned guard-subtraction safety, and zero/−1 trap retention are all proven; the specific d/base/exponent grid checks out with no counterexample.
