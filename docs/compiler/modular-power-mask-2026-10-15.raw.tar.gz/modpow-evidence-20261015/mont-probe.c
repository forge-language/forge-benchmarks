#include <stdint.h>
int64_t checked_residue(int64_t,int64_t,int64_t);
static inline uint64_t reduce(uint64_t n,uint64_t d,uint32_t inv){
 uint64_t q=(uint64_t)(uint32_t)((uint64_t)(uint32_t)n*inv)*d;
 uint64_t r=(n>>32)+d-(q>>32);
 return r>=d?r-d:r;
}
int64_t frlib_powers_residue(int64_t a,int64_t e,int64_t mod){
 if(a>=0 && e>0 && mod>2097152 && mod<=3037000499){
  uint64_t d=(uint64_t)mod,k=(uint64_t)e,x,r;
  if((d&(d-1))==0){
   uint64_t mask=d-1;
   x=(uint64_t)a&mask;r=1;
   if(k&1)r=x;k>>=1;
   while(k){x=x*x&mask;if(k&1)r=r*x&mask;k>>=1;}
   return (int64_t)r;
  }
  if(d&1){
   uint32_t inv=(uint32_t)d;
   for(unsigned i=0;i<4;i++) inv=(uint32_t)((uint64_t)inv*(UINT64_C(2)-d*inv));
   x=(((uint64_t)a%d)<<32)%d;
   while(!(k&1)){x=reduce(x*x,d,inv);k>>=1;}
   r=x;k>>=1;
   while(k){x=reduce(x*x,d,inv);if(k&1)r=reduce(r*x,d,inv);k>>=1;}
   return (int64_t)reduce(r,d,inv);
  }
 }
 return checked_residue(a,e,mod);
}
