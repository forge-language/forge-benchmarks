#ifndef FRLIB_POWERS_H
#define FRLIB_POWERS_H

#include <stdint.h>

int64_t frlib_powers_residue(int64_t a, int64_t bits, int64_t d);

#endif
