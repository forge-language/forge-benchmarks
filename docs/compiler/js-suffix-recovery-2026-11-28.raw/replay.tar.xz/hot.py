"""Replay original substring cases with longer warmup and measurement on their original inputs."""
import js_substring_bench as runner

iterations = {
    "short_late_utf8": 192000,
    "long_prefix": 12000,
    "long_ascii_prefix": 12000,
    "repository": 192000,
}
original_cases = runner.cases


def hot_cases():
    for name, operation, inputs, count in original_cases():
        if name in iterations:
            yield name, operation, inputs, iterations[name]


if __name__ == "__main__":
    runner.cases = hot_cases
    runner.main()
