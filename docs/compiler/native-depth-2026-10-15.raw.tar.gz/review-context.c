struct fr_scheduler {
    fr_process_t *processes;
    int worker_count;
    atomic_int running;
    atomic_int workers_started;
    int stopping;
    size_t runnable;
    size_t active_coros;
    size_t waiting_io;
    unsigned next_queue;
    unsigned next_worker;
    int native_pending;
    fr_thread_t **workers;
    fr_run_queue_t *worker_queues;
    fr_native_queue_t *native_queues;
    fr_event_loop_t *event_loop;
    fr_mutex_t *lock;
    fr_cond_t *idle_cond;
    fr_cond_t *state_cond;
};


static void *worker_main(void *arg) {
    fr_worker_arg_t *wa = (fr_worker_arg_t *)arg;
    fr_scheduler_t *sched = wa->sched;
    int wid = wa->wid;
    free(wa);

    int cpus = fr_platform_cpu_count();
    if (cpus > 0) fr_thread_pin_cpu(wid % cpus);
    tls_worker_id = wid;
    tls_worker_scheduler = sched;

    for (;;) {
        fr_mutex_lock(sched->lock);
        while (sched->running && sched->runnable == 0)
            fr_cond_wait(sched->idle_cond, sched->lock);
        if (!sched->running) { fr_mutex_unlock(sched->lock); break; }

        fr_coro_t *coro = fr_run_queue_pop(&sched->worker_queues[wid]);
        if (!coro) {
            for (int i = 0; i < sched->worker_count; i++) {
                if (i == wid) continue;
                coro = fr_run_queue_steal(&sched->worker_queues[i], &sched->worker_queues[wid]);
                if (coro) break;
            }
        }
        if (coro) {
            sched->runnable--;
            coro->on_queue = 0;
            coro->executing = 1;
            fr_mutex_unlock(sched->lock);
            fr_coro_status_t status = FR_CORO_RUNNING;
            int budget = FR_REDUCTION_BUDGET;
            tls_current_coro = coro;
            tls_reductions_remaining = &budget;
            while (budget-- > 0 && sched->running) {
                status = coro->fn(coro, coro->state);
                if (status == FR_CORO_YIELDED) status = FR_CORO_RUNNING;
                if (status != FR_CORO_RUNNING) break;
            }
            tls_reductions_remaining = NULL;
            tls_current_coro = NULL;
            fr_mutex_lock(sched->lock);
            coro->executing = 0;
            if (status == FR_CORO_WAITING_IO && coro->await_ready)
                status = FR_CORO_RUNNING;
            if (status == FR_CORO_WAITING_RECV) {
                fr_mutex_lock(coro->proc->lock);
                if (coro->proc->mailbox.count > 0) status = FR_CORO_RUNNING;
                fr_mutex_unlock(coro->proc->lock);
            }
            coro->status = status;
            refresh_coro_counts_locked(sched, coro);
            enqueue_coro_locked(sched, coro);
            notify_completion_locked(sched);
            fr_mutex_unlock(sched->lock);
            continue;
        }

        void *narg = NULL;
        fr_native_fn nfn = fr_native_queue_pop(&sched->native_queues[wid], &narg);
        if (!nfn) {
            for (int i = 0; i < sched->worker_count; i++) {
                if (i == wid) continue;
                nfn = fr_native_queue_steal(&sched->native_queues[i], &narg);
                if (nfn) break;
            }
        }
        if (nfn) {
            sched->runnable--;
            fr_mutex_unlock(sched->lock);
            nfn(narg);
            fr_mutex_lock(sched->lock);
            sched->native_pending--;
            notify_completion_locked(sched);
        }
        fr_mutex_unlock(sched->lock);
    }
    tls_worker_id = -1;
    tls_worker_scheduler = NULL;
    return NULL;
}


static int sched_pool_submit(fr_scheduler_t *sched, fr_native_fn fn, void *arg) {
    if (!sched || !fn) return 0;
    fr_mutex_lock(sched->lock);
    int q = (int)(sched->next_queue++ % (unsigned)sched->worker_count);
    int ok = fr_native_queue_try_push(&sched->native_queues[q], fn, arg);
    if (ok) {
        sched->native_pending++;
        sched->runnable++;
        fr_cond_signal(sched->idle_cond);
    }
    fr_mutex_unlock(sched->lock);
    return ok;
}

int fr_sched_pool_submit(fr_scheduler_t *sched, void (*fn)(void *), void *arg) {
    return sched_pool_submit(sched, fn, arg) ? 0 : -1;
}

size_t fr_sched_pool_queued(fr_scheduler_t *sched) {
    if (!sched) return 0;
    fr_mutex_lock(sched->lock);
    size_t count = 0;
    for (int i = 0; i < sched->worker_count; i++)
        count += fr_native_queue_count(&sched->native_queues[i]);
    fr_mutex_unlock(sched->lock);
    return count;
}

