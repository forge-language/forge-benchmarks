# Reproduce native depth accounting

Runtime base: dcbb1929b17c2f1d11fd367ecf80c7c87c58a274. The compiler's runtime
pin stays unchanged. runtime.patch applies to that base, benchmarks.patch to the
recorded benchmark base. patch-check.json verifies every changed file against
its archived baseline; reconstruction.json rebuilds both runtime archives byte
for byte. The original and proposed sources are included separately.

From the extracted archive on the recorded Linux host, with GCC 13.3.0:

```
cc -std=c11 -O3 -Wall -Wextra source-benchmarks/benchmark/native_depth_bench.c -I sdk/include libforge_runtime-baseline.a -pthread -o bench-baseline
cc -std=c11 -O3 -Wall -Wextra source-benchmarks/benchmark/native_depth_bench.c -I sdk/include libforge_runtime-candidate.a -pthread -o bench-candidate
python3 source-benchmarks/benchmark/native_depth_compare.py --baseline "$PWD/bench-baseline" --candidate "$PWD/bench-candidate" --output "$PWD/new-paired-results" --pairs 24
```

The CPU map is explicit: producer CPU 10, worker masks drawn from
0,2,4,6,8,1,3,5,7,9. Controller and fixture verify every observed thread mask.
Adapt them consistently on another host. Query-only cases have no worker
threads; worker counts there describe configured queues. Do not run builds
or test suites alongside measurements.

For single-observation activation diagnostics, compile the same source twice
with -DFORGE_DEPTH_SINGLE_QUERY=1 to bench-sparse-baseline/bench-sparse-candidate.
sparse_compare.py records the original session's absolute controller/source
paths; point those paths to the extracted source-benchmarks directory to repeat
on another machine. It performs one depth query, then submits the native jobs
with no further queries. The default source build is byte-identical to the
main measured binary; the diagnostic variant is separately labeled.

Standalone runtime regression/sanitizer commands:

```
cmake -S source-runtime -B runtime-check -DCMAKE_BUILD_TYPE=Release
cmake --build runtime-check -j2
ctest --test-dir runtime-check --output-on-failure
cmake -S source-runtime -B runtime-asan -DCMAKE_BUILD_TYPE=Debug '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer'
cmake --build runtime-asan -j2
ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir runtime-asan --output-on-failure
```

The full project suite and selfhost fixed point used explicit local runtime and
stdlib source overrides. Compiler source is unchanged by this runtime patch.
The supplied installed SDK contains the same local stdlib HTTP candidate as
both measurements. Existing library/source license notices are retained.

preexisting-lifecycle.json contains actual failures, not passing tests: both
libraries leak an internal queued spawn wrapper on destroy and hang on a
concurrent start during stop. The lifecycle probe is isolated; its timeout
terminates its own process. These findings remain follow-up work. ThreadSanitizer
failed before main on this host and is not credited as a pass.

All three rejected/intermediate prototypes retain source, libraries, binaries,
controllers and complete result matrices. They are not pooled into the final
confidence intervals. Empty/single queue costs, no-query controls, sparse
activation, completion percentiles and per-worker counts remain visible.
