#include <stddef.h>
#include "/home/helloworld0822/coding/forge-runtime/src/scheduler.c"
int main(void){printf("%zu %zu %zu\n",sizeof(fr_scheduler_t),offsetof(fr_scheduler_t,native_pending),offsetof(fr_scheduler_t,workers));return 0;}
