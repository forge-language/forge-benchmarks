#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ForgeStd::stdlib" for configuration "Release"
set_property(TARGET ForgeStd::stdlib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ForgeStd::stdlib PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libforge_std.a"
  )

list(APPEND _cmake_import_check_targets ForgeStd::stdlib )
list(APPEND _cmake_import_check_files_for_ForgeStd::stdlib "${_IMPORT_PREFIX}/lib/libforge_std.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
