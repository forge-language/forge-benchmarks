
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was ForgeConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
find_dependency(ForgeRuntime 0.3 CONFIG)
find_dependency(ForgeStd 0.3 CONFIG)
set_and_check(FORGE_ROOT_DIR "${PACKAGE_PREFIX_DIR}")
set_and_check(FORGE_BIN_DIR "${PACKAGE_PREFIX_DIR}/bin")
set_and_check(FORGE_LIB_DIR "${PACKAGE_PREFIX_DIR}/lib")
set_and_check(FORGE_INCLUDE_DIR "${PACKAGE_PREFIX_DIR}/include")
if(NOT TARGET Forge::forge)
    add_executable(Forge::forge IMPORTED)
    set_target_properties(Forge::forge PROPERTIES IMPORTED_LOCATION "${FORGE_BIN_DIR}/forge${CMAKE_EXECUTABLE_SUFFIX}")
endif()
if(NOT TARGET Forge::forge_runtime)
    add_library(Forge::forge_runtime INTERFACE IMPORTED)
    set_property(TARGET Forge::forge_runtime PROPERTY INTERFACE_LINK_LIBRARIES ForgeRuntime::runtime)
endif()
if(NOT TARGET Forge::forge_std)
    add_library(Forge::forge_std INTERFACE IMPORTED)
    set_property(TARGET Forge::forge_std PROPERTY INTERFACE_LINK_LIBRARIES ForgeStd::stdlib)
endif()
set(FORGE_EXECUTABLE Forge::forge)
set(FORGE_RUNTIME_TARGET Forge::forge_runtime)
# Use the actual imported archive targets for file timestamp dependencies of
# custom Forge compiler commands; legacy interface aliases only forward links.
set(FORGE_BUILD_DEPS Forge::forge ForgeRuntime::runtime ForgeStd::stdlib)
if(CMAKE_C_COMPILER)
    set(FORGE_CC_ARGS --cc "${CMAKE_C_COMPILER}")
endif()
include("${CMAKE_CURRENT_LIST_DIR}/ForgeLibrary.cmake")
check_required_components(Forge)
