from pathlib import Path
import hashlib,importlib.util,json,math,os,statistics,subprocess
root=Path(__file__).resolve().parent
controller=Path('/home/helloworld0822/coding/forge-benchmarks/benchmark/native_depth_compare.py')
spec=importlib.util.spec_from_file_location('compare',controller);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
os.sched_setaffinity(0,{10});rows=[]
for workers in [2,4,8]:
 samples=[]
 for pair in range(-1,24):
  seed=71+(pair+1)*719;order=['baseline','candidate'] if pair%2==0 else ['candidate','baseline'];sample={'pair':pair,'order':order}
  for label in order:
   command=[str(root/('bench-sparse-'+label)),'control',str(workers),'20000','16',str(seed)]
   p=subprocess.run(command,capture_output=True,text=True,check=True,timeout=30);value=json.loads(p.stdout)
   assert value['checksum']==m.reference('control',20000,16,seed) and 'polls=1\n' in p.stderr
   masks=[tuple(int(c) for c in line.split('=',1)[1].split(',') if c) for line in p.stderr.splitlines() if line.startswith('affinity:')]
   assert masks.count((10,))==1 and masks.count(tuple(sorted([0,2,4,6,8,1,3,5,7,9][:workers])))==workers
   value.update(command=command,stderr=p.stderr);sample[label]=value
  if pair>=0:samples.append(sample)
 ratios=[x['baseline']['wall_ns']/x['candidate']['wall_ns'] for x in samples]
 rows.append({'workers':workers,'samples':samples,'speedup':math.exp(statistics.mean(map(math.log,ratios))),'ci95':m.confidence(ratios)})
 (root/'sparse-results.json').write_text(json.dumps({'method':'One preflight queued-depth query activates ledger, then no more depth queries during 20000 jobs. Same public callbacks and independent oracle as main comparison. 24 AB/BA pairs, one excluded warmup pair.','source_sha256':hashlib.sha256(Path('/home/helloworld0822/coding/forge-benchmarks/benchmark/native_depth_bench.c').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'results':rows},indent=2)+'\n')
 print(workers,rows[-1]['speedup'],rows[-1]['ci95'],flush=True)
