from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile,tempfile
root=Path(__file__).resolve().parent
runtime=Path('/home/helloworld0822/coding/forge-runtime');bench=Path('/home/helloworld0822/coding/forge-benchmarks');forge=Path('/home/helloworld0822/coding/forge')
shutil.copytree(runtime,root/'source-runtime',dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git','.omo','build','build-*','__pycache__'))
bench_paths=['CMakeLists.txt','README.md','benchmark/native_depth_bench.c','benchmark/native_depth_compare.py']
for name in bench_paths+['LICENSE','PROVENANCE.md']:
 p=root/'source-benchmarks'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(bench/name,p)
for name in ['CMakeLists.txt','README.md']:
 p=root/'benchmark-baseline'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','HEAD:'+name],cwd=bench))
def patch(repo,newfiles):
 value=subprocess.check_output(['git','diff','--binary'],cwd=repo)
 for name in newfiles:
  p=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=repo,capture_output=True);assert p.returncode==1,p.stderr;value+=p.stdout
 return value
rp=root/'runtime.patch';rp.write_bytes(patch(runtime,['tests/native_depth_test.c']))
bp=root/'benchmarks.patch';bp.write_bytes(patch(bench,['benchmark/native_depth_bench.c','benchmark/native_depth_compare.py']))
runtime_paths=['CMakeLists.txt','README.md','include/forge_runtime.h','src/scheduler.c','tests/native_depth_test.c']
checks=[]
for label,repo,patch_path,paths in [('runtime',runtime,rp,runtime_paths),('benchmarks',bench,bp,bench_paths)]:
 with tempfile.TemporaryDirectory(prefix='native-depth-patch-',dir='/dev/shm') as folder:
  if label=='runtime':
   stream=subprocess.check_output(['git','archive','HEAD'],cwd=repo)
   with tarfile.open(fileobj=io.BytesIO(stream)) as archive:archive.extractall(folder,filter='data')
  else:shutil.copytree(root/'benchmark-baseline',folder,dirs_exist_ok=True)
  subprocess.run(['git','apply','--check',str(patch_path)],cwd=folder,check=True)
  subprocess.run(['git','apply',str(patch_path)],cwd=folder,check=True)
  assert all((Path(folder)/p).read_bytes()==(repo/p).read_bytes() for p in paths)
 checks.append({'component':label,'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files_applied_and_matched':paths,'patch_sha256':hashlib.sha256(patch_path.read_bytes()).hexdigest()})
(root/'patch-check.json').write_text(json.dumps(checks,indent=2)+'\n')
for name in ['docs/design-principles.md','docs/benchmarks/native-depth-2026-10-15.md','ARCHITECTURE.md']:
 target=root/'source-project'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(forge/name,target)
(root/'REPRODUCE.md').write_text('''# Reproduce native depth accounting

Runtime base: dcbb1929b17c2f1d11fd367ecf80c7c87c58a274. The compiler's runtime
pin stays unchanged. runtime.patch applies to that base, benchmarks.patch to the
recorded benchmark base. patch-check.json verifies every changed file against
its archived baseline; reconstruction.json rebuilds both runtime archives byte
for byte. The original and proposed sources are included separately.

From the extracted archive on the recorded Linux host, with GCC 13.3.0:

```
cc -std=c11 -O3 -Wall -Wextra source-benchmarks/benchmark/native_depth_bench.c -I sdk/include libforge_runtime-baseline.a -pthread -o bench-baseline
cc -std=c11 -O3 -Wall -Wextra source-benchmarks/benchmark/native_depth_bench.c -I sdk/include libforge_runtime-candidate.a -pthread -o bench-candidate
python3 source-benchmarks/benchmark/native_depth_compare.py --baseline "$PWD/bench-baseline" --candidate "$PWD/bench-candidate" --output "$PWD/new-paired-results" --pairs 24
```

The CPU map is explicit: producer CPU 10, worker masks drawn from
0,2,4,6,8,1,3,5,7,9. Controller and fixture verify every observed thread mask.
Adapt them consistently on another host. Query-only cases have no worker
threads; worker counts there describe configured queues. Do not run builds
or test suites alongside measurements.

For single-observation activation diagnostics, compile the same source twice
with -DFORGE_DEPTH_SINGLE_QUERY=1 to bench-sparse-baseline/bench-sparse-candidate.
sparse_compare.py records the original session's absolute controller/source
paths; point those paths to the extracted source-benchmarks directory to repeat
on another machine. It performs one depth query, then submits the native jobs
with no further queries. The default source build is byte-identical to the
main measured binary; the diagnostic variant is separately labeled.

Standalone runtime regression/sanitizer commands:

```
cmake -S source-runtime -B runtime-check -DCMAKE_BUILD_TYPE=Release
cmake --build runtime-check -j2
ctest --test-dir runtime-check --output-on-failure
cmake -S source-runtime -B runtime-asan -DCMAKE_BUILD_TYPE=Debug '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer'
cmake --build runtime-asan -j2
ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir runtime-asan --output-on-failure
```

The full project suite and selfhost fixed point used explicit local runtime and
stdlib source overrides. Compiler source is unchanged by this runtime patch.
The supplied installed SDK contains the same local stdlib HTTP candidate as
both measurements. Existing library/source license notices are retained.

preexisting-lifecycle.json contains actual failures, not passing tests: both
libraries leak an internal queued spawn wrapper on destroy and hang on a
concurrent start during stop. The lifecycle probe is isolated; its timeout
terminates its own process. These findings remain follow-up work. ThreadSanitizer
failed before main on this host and is not credited as a pass.

All three rejected/intermediate prototypes retain source, libraries, binaries,
controllers and complete result matrices. They are not pooled into the final
confidence intervals. Empty/single queue costs, no-query controls, sparse
activation, completion percentiles and per-worker counts remain visible.
''')
exclude={'release-build','asan-build','tsan-build','benchmark-build','baseline-rebuild','candidate-rebuild'}
manifest={}
for p in sorted(root.rglob('*')):
 relative=p.relative_to(root)
 if p.is_file() and not (set(relative.parts)&exclude) and p.name!='manifest.json':manifest[str(relative)]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Both patches replay exactly;',len(manifest),'files hashed.')
