#define _GNU_SOURCE
#include "forge_runtime.h"
#include "forge/thread.h"
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static uint64_t now_ns(clockid_t clock) {struct timespec t;clock_gettime(clock,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
static atomic_size_t done;
typedef struct {uint64_t input,result;unsigned steps;} item_t;
static uint64_t expected(uint64_t x,unsigned steps){for(unsigned i=0;i<steps;i++)x=x*UINT64_C(6364136223846793005)+UINT64_C(1442695040888963407);return x;}
static void job(void *arg){item_t *p=arg;p->result=expected(p->input,p->steps);atomic_fetch_add_explicit(&done,1,memory_order_release);}
static void noop(void *arg){(void)arg;}
int main(int argc,char **argv){
 if(argc!=6)return 2;
 const char *mode=argv[1];int workers=atoi(argv[2]);size_t count=strtoull(argv[3],NULL,10);unsigned steps=(unsigned)strtoul(argv[4],NULL,10);uint64_t seed=strtoull(argv[5],NULL,10);
 if(workers<1||workers>128||count<1||count>10000000)return 3;
 fr_scheduler_t *s=fr_scheduler_create(workers);if(!s)return 4;
 uint64_t sum=0,wall,cpu;
 if(!strcmp(mode,"query")){
  for(unsigned i=0;i<steps;i++)if(fr_sched_pool_submit(s,noop,NULL))return 5;
  wall=now_ns(CLOCK_MONOTONIC);cpu=now_ns(CLOCK_PROCESS_CPUTIME_ID);
  for(size_t i=0;i<count;i++)sum+=fr_sched_pool_queued(s);
  cpu=now_ns(CLOCK_PROCESS_CPUTIME_ID)-cpu;wall=now_ns(CLOCK_MONOTONIC)-wall;
  if(sum!=(uint64_t)count*steps)return 6;
 }else{
  int queried=!strcmp(mode,"queried");if(!queried&&strcmp(mode,"control"))return 7;
  item_t *items=calloc(count,sizeof(*items));if(!items)return 8;
  for(size_t i=0;i<count;i++)items[i]=(item_t){seed+(uint64_t)i,0,steps};
  fr_scheduler_start(s);
  item_t warm[64];for(unsigned i=0;i<64;i++){warm[i]=(item_t){i,0,1};if(fr_sched_pool_submit(s,job,&warm[i]))return 9;}
  while(atomic_load_explicit(&done,memory_order_acquire)!=64)fr_thread_yield();atomic_store(&done,0);
  wall=now_ns(CLOCK_MONOTONIC);cpu=now_ns(CLOCK_PROCESS_CPUTIME_ID);
  size_t polls=0;
  for(size_t i=0;i<count;i++){
   if(queried)while(++polls&&fr_sched_pool_queued(s)>=2048)fr_thread_yield();
   if(fr_sched_pool_submit(s,job,&items[i]))return 10;
  }
  while(atomic_load_explicit(&done,memory_order_acquire)!=count)fr_thread_yield();
  fr_scheduler_stop(s);
  cpu=now_ns(CLOCK_PROCESS_CPUTIME_ID)-cpu;wall=now_ns(CLOCK_MONOTONIC)-wall;
  for(size_t i=0;i<count;i++){if(items[i].result!=expected(items[i].input,steps))return 11;sum+=items[i].result;}
  if(fr_sched_pool_queued(s)!=0)return 12;
  free(items);
  fprintf(stderr,"polls=%zu\n",polls);
 }
 fr_scheduler_destroy(s);
 printf("{\"mode\":\"%s\",\"workers\":%d,\"count\":%zu,\"steps\":%u,\"seed\":%llu,\"wall_ns\":%llu,\"cpu_ns\":%llu,\"checksum\":%llu}\n",mode,workers,count,steps,(unsigned long long)seed,(unsigned long long)wall,(unsigned long long)cpu,(unsigned long long)sum);
 return 0;
}
