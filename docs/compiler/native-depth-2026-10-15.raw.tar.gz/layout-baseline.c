#include <stddef.h>
#include "/dev/shm/forge-native-depth-20261015/scheduler-baseline.c"
int main(void){printf("%zu %zu %zu\n",sizeof(fr_scheduler_t),offsetof(fr_scheduler_t,native_pending),offsetof(fr_scheduler_t,workers));return 0;}
