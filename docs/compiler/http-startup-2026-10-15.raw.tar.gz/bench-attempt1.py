import json,os,platform,random,socket,statistics,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent
samples=[]
def affinity(cores):
 return lambda:os.sched_setaffinity(0,cores)
def cpu_seconds(pid):
 total=0
 for t in Path(f'/proc/{pid}/task').iterdir():
  f=(t/'stat').read_text().rsplit(')',1)[1].split()
  total+=int(f[11])+int(f[12])
 return total/os.sysconf('SC_CLK_TCK')
def listener_count(pid,port):
 inodes=set()
 for line in Path('/proc/net/tcp').read_text().splitlines()[1:]:
  f=line.split()
  if f[3]=='0A' and int(f[1].split(':')[1],16)==port:inodes.add(f[9])
 ours={os.readlink(p) for p in Path(f'/proc/{pid}/fd').iterdir()}
 return sum('socket:['+i+']' in ours for i in inodes)
def case(variant,mode):
 with socket.socket() as r:r.bind(('127.0.0.1',0));port=r.getsockname()[1]
 p=subprocess.Popen([str(root/f'server-{variant}'),mode,str(port)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=affinity({0,1}))
 try:
  assert int(p.stdout.readline())==port
  p.stdin.write(b'g');p.stdin.flush()
  warm_errors=0;until=time.monotonic()+3
  while True:
   try:
    with socket.create_connection(('127.0.0.1',port),timeout=.5) as s:
     s.sendall(b'GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n');data=b''
     while True:
      b=s.recv(4096)
      if not b:break
      data+=b
     if not data.endswith(b'startup preserved'):raise OSError('bad warmup response')
    break
   except OSError:
    warm_errors+=1
    if time.monotonic()>until:raise
  def load(ms):
   r=subprocess.run([str(root/'load'),str(port),str(ms),'4'],capture_output=True,text=True,check=True,preexec_fn=affinity({8,9,10,11}),timeout=5)
   value=json.loads(r.stdout);assert value['errors']==0,value;return value
  load(200)
  listeners=listener_count(p.pid,port);assert listeners==2,(variant,mode,listeners)
  before=cpu_seconds(p.pid);result=load(1000);after=cpu_seconds(p.pid)
  result.update(variant=variant,mode=mode,listeners=listeners,server_cpu_seconds=after-before,warmup_startup_errors=warm_errors)
  return result
 finally:
  p.terminate();p.communicate(timeout=3)
for mode in ['mt','hybrid']:
 for pair in range(24):
  order=['baseline','candidate'] if pair%2==0 else ['candidate','baseline']
  for variant in order:
   row=case(variant,mode);row['pair']=pair;samples.append(row)
  (root/'benchmark.json').write_text(json.dumps({'samples':samples},indent=2)+'\n')
  if pair%6==5:print(mode,pair+1,'pairs',flush=True)
rng=random.Random(20261015);summaries={}
for mode in ['mt','hybrid']:
 pairs=[]
 for pair in range(24):
  vals={r['variant']:r for r in samples if r['mode']==mode and r['pair']==pair}
  pairs.append(vals)
 ratios=[p['candidate']['rps']/p['baseline']['rps'] for p in pairs]
 boot=sorted(statistics.median(rng.choices(ratios,k=24)) for _ in range(10000))
 summaries[mode]={'paired_rps_ratio_median':statistics.median(ratios),'paired_rps_ratio_bootstrap_95ci':[boot[250],boot[9750]],'variants':{}}
 for variant in ['baseline','candidate']:
  vals=[p[variant] for p in pairs]
  summaries[mode]['variants'][variant]={key:statistics.median(v[key] for v in vals) for key in ['rps','p50_us','p95_us','p99_us','server_cpu_seconds']}
 summaries[mode]['errors']=sum(p[v]['errors'] for p in pairs for v in ['baseline','candidate'])
 summaries[mode]['warmup_startup_errors']=sum(p[v]['warmup_startup_errors'] for p in pairs for v in ['baseline','candidate'])
result={'environment':{'kernel':platform.release(),'allowed_cpus':sorted(os.sched_getaffinity(0)),'server_cpus':[0,1],'client_cpus':[8,9,10,11],'pairs':24,'measured_ms':1000,'warmup_ms':200,'clients':4},'summary':summaries,'samples':samples}
(root/'benchmark.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(summaries,indent=2),flush=True)
