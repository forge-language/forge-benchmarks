# Reproduce the retained Linux experiment

The compiler dependency pin is unchanged. The supplied stdlib.patch applies to
forge-stdlib 6aa28667b83009a415ab2d7ac13ef6c675af7012. First apply it to a local
checkout, then configure Forge with explicit local source overrides:

```
cmake -S forge -B build -DCMAKE_BUILD_TYPE=Release -DFORGE_RUNTIME_SOURCE_DIR=/absolute/forge-runtime -DFORGE_STDLIB_SOURCE_DIR=/absolute/forge-stdlib
cmake --build build -j2
TMPDIR=/dev/shm ctest --test-dir build --output-on-failure
```

For the native standalone fixture, this archive includes both static stdlib
variants and the unchanged runtime archive. Rebuild on the recorded Linux host
with GCC 13.3.0 and OpenSSL 3, from the archive directory:

```
cc -O3 server.c -I sdk/stdlib/include -I sdk/runtime/include libforge_std-baseline.a libforge_runtime.a -Wl,--wrap=fr_platform_cpu_count -pthread -lm -lssl -lcrypto -o server-baseline
cc -O3 server.c -I sdk/stdlib/include -I sdk/runtime/include libforge_std-candidate.a libforge_runtime.a -Wl,--wrap=fr_platform_cpu_count -pthread -lm -lssl -lcrypto -o server-candidate
cc -O3 -Wall -Wextra load.c -pthread -o load
python3 check.py ./server-baseline baseline-startup-rerun.json
python3 check.py ./server-candidate candidate-startup-rerun.json
python3 socket_probe.py
python3 fanout_probe.py
python3 bench.py
```

bench.py resolves its fixtures relative to its own directory. It uses port 50321, server CPUs 0/1,
client CPUs 8/9/10/11, four clients, 200ms warmup, 1s measurements, and 24 AB/BA
pairs for each mode. These CPU masks describe the measured host; they must be
adapted consistently for a different machine. Do not run measurements alongside
builds or test suites. Report errors and all failed attempts, not just medians.

To rebuild the sanitizer test separately:

```
cmake -S forge-stdlib -B asan-build -DFORGE_RUNTIME_SOURCE_DIR=/absolute/forge-runtime -DCMAKE_BUILD_TYPE=Debug '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' -DFORGE_ENABLE_GPU=OFF -DFORGE_ENABLE_IO_URING=OFF
cmake --build asan-build --target http_startup_test -j2
ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir asan-build -R http_startup_regressions --output-on-failure
```

The baseline regression failure binary used http_startup_test-before-final-review.c.
Its output is retained separately. The final test additionally checks a
getsockname failure, mixed bind/thread failure, and exclusive inline fallback.
