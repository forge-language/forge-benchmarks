import hashlib,io,json,shutil,subprocess,tarfile,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
stdlib=Path('/home/helloworld0822/coding/forge-stdlib')
runtime=Path('/home/helloworld0822/coding/forge-runtime')
forge=Path('/home/helloworld0822/coding/forge')
patch=subprocess.check_output(['git','diff','--binary'],cwd=stdlib)
new=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null','tests/http_startup_test.c'],cwd=stdlib,capture_output=True)
assert new.returncode==1,new.stderr
patch+=new.stdout
(root/'stdlib.patch').write_bytes(patch)
paths=['CMakeLists.txt','README.md','src/http.c','tests/http_startup_test.c']
with tempfile.TemporaryDirectory(prefix='http-patch-check-',dir='/dev/shm') as folder:
 snapshot=subprocess.check_output(['git','archive','HEAD'],cwd=stdlib)
 with tarfile.open(fileobj=io.BytesIO(snapshot)) as archive:archive.extractall(folder,filter='data')
 subprocess.run(['git','apply','--check',str(root/'stdlib.patch')],cwd=folder,check=True)
 subprocess.run(['git','apply',str(root/'stdlib.patch')],cwd=folder,check=True)
 assert all((Path(folder)/p).read_bytes()==(stdlib/p).read_bytes() for p in paths)
(root/'patch-check.json').write_text(json.dumps({'baseline_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=stdlib,text=True).strip(),'applied_and_matched':paths,'patch_sha256':hashlib.sha256(patch).hexdigest()},indent=2)+'\n')
for source,target in [(stdlib/'src/http.c','http-candidate.c'),(stdlib/'CMakeLists.txt','stdlib-CMakeLists.txt'),(stdlib/'README.md','stdlib-README.md'),(stdlib/'tests/http_startup_test.c','http_startup_test.c'),(forge/'build/lib/libforge_std.a','libforge_std-candidate.a')]:shutil.copyfile(source,root/target)
for source,target in [(stdlib/'include',root/'sdk/stdlib/include'),(runtime/'include',root/'sdk/runtime/include')]:shutil.copytree(source,target,dirs_exist_ok=True)
for repo,name in [(stdlib,'stdlib'),(runtime,'runtime')]:
 for license_name in ['LICENSE','NOTICE']:
  if (repo/license_name).exists():shutil.copyfile(repo/license_name,root/'sdk'/name/license_name)
(root/'REPRODUCE.md').write_text('''# Reproduce the retained Linux experiment

The compiler dependency pin is unchanged. The supplied stdlib.patch applies to
forge-stdlib 6aa28667b83009a415ab2d7ac13ef6c675af7012. First apply it to a local
checkout, then configure Forge with explicit local source overrides:

```
cmake -S forge -B build -DCMAKE_BUILD_TYPE=Release -DFORGE_RUNTIME_SOURCE_DIR=/absolute/forge-runtime -DFORGE_STDLIB_SOURCE_DIR=/absolute/forge-stdlib
cmake --build build -j2
TMPDIR=/dev/shm ctest --test-dir build --output-on-failure
```

For the native standalone fixture, this archive includes both static stdlib
variants and the unchanged runtime archive. Rebuild on the recorded Linux host
with GCC 13.3.0 and OpenSSL 3, from the archive directory:

```
cc -O3 server.c -I sdk/stdlib/include -I sdk/runtime/include libforge_std-baseline.a libforge_runtime.a -Wl,--wrap=fr_platform_cpu_count -pthread -lm -lssl -lcrypto -o server-baseline
cc -O3 server.c -I sdk/stdlib/include -I sdk/runtime/include libforge_std-candidate.a libforge_runtime.a -Wl,--wrap=fr_platform_cpu_count -pthread -lm -lssl -lcrypto -o server-candidate
cc -O3 -Wall -Wextra load.c -pthread -o load
python3 check.py ./server-baseline baseline-startup-rerun.json
python3 check.py ./server-candidate candidate-startup-rerun.json
python3 socket_probe.py
python3 fanout_probe.py
python3 bench.py
```

bench.py resolves its fixtures relative to its own directory. It uses port 50321, server CPUs 0/1,
client CPUs 8/9/10/11, four clients, 200ms warmup, 1s measurements, and 24 AB/BA
pairs for each mode. These CPU masks describe the measured host; they must be
adapted consistently for a different machine. Do not run measurements alongside
builds or test suites. Report errors and all failed attempts, not just medians.

To rebuild the sanitizer test separately:

```
cmake -S forge-stdlib -B asan-build -DFORGE_RUNTIME_SOURCE_DIR=/absolute/forge-runtime -DCMAKE_BUILD_TYPE=Debug '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' -DFORGE_ENABLE_GPU=OFF -DFORGE_ENABLE_IO_URING=OFF
cmake --build asan-build --target http_startup_test -j2
ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir asan-build -R http_startup_regressions --output-on-failure
```

The baseline regression failure binary used http_startup_test-before-final-review.c.
Its output is retained separately. The final test additionally checks a
getsockname failure, mixed bind/thread failure, and exclusive inline fallback.
''')
manifest={}
for p in sorted(root.rglob('*')):
 if not p.is_file() or 'asan-build' in p.relative_to(root).parts or p.name in ['manifest.json']:continue
 manifest[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('patch replay matched; manifest files:',len(manifest))
