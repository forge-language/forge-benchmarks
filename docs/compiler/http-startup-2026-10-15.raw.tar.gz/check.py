import json, socket, subprocess, sys
from pathlib import Path
rows=[]
for mode in ['forever','mt','hybrid','uring']:
 for iteration in range(5):
  with socket.socket() as reservation:
   reservation.bind(('127.0.0.1',0)); chosen=reservation.getsockname()[1]
  p=subprocess.Popen([sys.argv[1],mode,str(chosen)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  sockets=[]; results=[]
  try:
   port=int(p.stdout.readline())
   for i in range(8):
    s=socket.create_connection(('127.0.0.1',port),timeout=2);s.settimeout(2)
    s.sendall(b'GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n');sockets.append(s)
   p.stdin.write(b'g');p.stdin.flush()
   for s in sockets:
    try:
     data=b''
     while not data.endswith(b'startup preserved'):
      chunk=s.recv(4096)
      if not chunk:break
      data+=chunk
     results.append('ok' if data.endswith(b'startup preserved') and b'200 OK' in data else 'bad:'+repr(data))
    except OSError as e:results.append(type(e).__name__+':'+str(e))
  finally:
   for s in sockets:s.close()
   p.terminate();p.communicate(timeout=3)
  rows.append(dict(mode=mode,iteration=iteration,results=results))
Path(sys.argv[2]).write_text(json.dumps(rows,indent=2)+'\n')
for mode in ['forever','mt','hybrid','uring']:
 vals=[v for r in rows if r['mode']==mode for v in r['results']]
 print(mode,len(vals),sum(x=='ok' for x in vals),sorted(set(vals)))
