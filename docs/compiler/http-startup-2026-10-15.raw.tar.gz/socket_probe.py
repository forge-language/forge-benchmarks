import json,socket,platform
out={'kernel':platform.release()}
a=socket.socket();a.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);a.bind(('127.0.0.1',0));a.listen(32)
port=a.getsockname()[1]
def bind_peer():
 b=socket.socket();b.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);b.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEPORT,1)
 try:b.bind(('127.0.0.1',port));b.listen(32);return b,None
 except OSError as e:b.close();return None,repr(e)
b,error=bind_peer();out['before_enable_bind_error']=error
assert b is None
a.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEPORT,1)
b,error=bind_peer();out['after_enable_bind_error']=error
assert b is not None
out['distinct_listeners']=[a.fileno(),b.fileno()]
a.close();b.close();print(json.dumps(out,indent=2))
