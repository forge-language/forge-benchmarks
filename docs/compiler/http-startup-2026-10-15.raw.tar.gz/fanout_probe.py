import collections,json,select,socket
out={}
for late in [False,True]:
 a=socket.socket();a.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
 if not late:a.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEPORT,1)
 a.bind(('127.0.0.1',0));a.listen(8192);port=a.getsockname()[1]
 if late:a.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEPORT,1)
 b=socket.socket();b.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);b.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEPORT,1);b.bind(('127.0.0.1',port));b.listen(8192)
 counts=collections.Counter()
 for i in range(2000):
  with socket.create_connection(('127.0.0.1',port),timeout=2) as client:
   ready,_,_=select.select([a,b],[],[],2)
   assert ready
   for listener in ready:
    conn,_=listener.accept();counts['original' if listener is a else 'new']+=1;conn.close()
 a.close();b.close();out['late' if late else 'prebind']=dict(counts)
print(json.dumps(out,indent=2))
