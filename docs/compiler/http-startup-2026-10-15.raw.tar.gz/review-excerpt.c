int64_t fr_http_listen(int64_t port) {
    int64_t sock = fr_tcp_listen(port);
    if (sock < 0) return -1;
    if (sock >= FR_HTTP_MAX_SERVERS) {
        fr_tcp_close(sock);
        return -1;
    }
    if (port == 0) {
        struct sockaddr_in addr;
#if defined(FORGE_OS_WINDOWS)
        int addr_len = sizeof(addr);
#else
        socklen_t addr_len = sizeof(addr);
#endif
        if (getsockname((fr_socket_t)sock, (struct sockaddr *)&addr, &addr_len) < 0) {
            fr_tcp_close(sock);
            return -1;
        }
        /* Additional workers must join this port, not request new ports. */
        port = ntohs(addr.sin_port);
    }
    g_servers[sock].listen_sock = sock;
    g_servers[sock].port = port;
    g_servers[sock].cached_resp = NULL;
    g_servers[sock].cached_len = 0;
    g_servers[sock].sendfile_fd = -1;
    g_servers[sock].sendfile_len = 0;
    g_servers[sock].tls_ctx = NULL;
    return sock;
}

typedef struct {
    int listen_fd;
    fr_http_server_state_t *srv;
    int worker_id;
    void (*loop_fn)(int listen_fd, fr_http_server_state_t *srv);
} http_worker_ctx_t;

static void *http_worker_main(void *arg) {
    http_worker_ctx_t *ctx = (http_worker_ctx_t *)arg;
    int cpus = fr_platform_cpu_count();
    if (cpus > 0) fr_thread_pin_cpu(ctx->worker_id % cpus);
    ctx->loop_fn(ctx->listen_fd, ctx->srv);
    return NULL;
}

void fr_http_spawn_workers(int64_t server, fr_http_server_state_t *srv, int threads,
                           void (*loop_fn)(int listen_fd, fr_http_server_state_t *srv)) {
    if (!srv || !loop_fn) return;
    fr_http_tune_server();

    int cpus = fr_platform_cpu_count();
    if (cpus < 1) cpus = 1;
    int accept_workers = (int)(threads > 0 ? threads : cpus);

    if (accept_workers == 1) {
        loop_fn((int)server, srv);
        return;
    }

    /* Keep the listening queue alive across worker startup. Some systems permit
     * enabling reuseport on a bound listener; others require it before bind.
     * In either case correctness does not depend on enabling it here: if an
     * additional bind fails, workers can accept from the original socket.
     * Do not enable it in http_listen: that would change exclusive-bind behavior
     * before the caller elects to start a multi-worker server. */
#if defined(SO_REUSEPORT) && (defined(FORGE_OS_LINUX) || defined(FORGE_OS_MACOS))
    int reuseport = 1;
    setsockopt((int)server, SOL_SOCKET, SO_REUSEPORT, &reuseport, sizeof(reuseport));
#endif

    http_worker_ctx_t *ctxs = (http_worker_ctx_t *)calloc((size_t)accept_workers, sizeof(http_worker_ctx_t));
    if (!ctxs) {
        loop_fn((int)server, srv);
        return;
    }

    int started = 0;
    for (int i = 0; i < accept_workers; i++) {
        int64_t fd = i == 0 ? server : fr_tcp_listen_reuseport(srv->port);
        if (fd < 0) {
#if defined(FORGE_OS_LINUX) || defined(FORGE_OS_MACOS)
            fd = server;
#else
            /* The generic accept loop polls; do not multiply idle spinning
             * when this platform cannot provide separate worker listeners. */
            break;
#endif
        }
        ctxs[started].listen_fd = (int)fd;
        ctxs[started].srv = srv;
        ctxs[started].worker_id = started;
        ctxs[started].loop_fn = loop_fn;
        fr_thread_t *tid = NULL;
        if (fr_thread_start(&tid, http_worker_main, &ctxs[started]) != 0) {
            if (fd != server) fr_sock_close((int)fd);
            if (i == 0) {
                free(ctxs);
                loop_fn((int)server, srv);
                return;
            }
            continue;
        }
        fr_thread_detach(tid);
        started++;
    }

    /* Worker zero owns the original listening queue. Keep its context and all
     * other detached-worker contexts alive for the lifetime of the service. */
    fr_platform_sleep_forever();
}

