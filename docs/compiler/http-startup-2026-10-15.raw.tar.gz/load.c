#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>
#define SAMPLES 1000000
static uint64_t now_ns(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return (uint64_t)t.tv_sec*1000000000+t.tv_nsec; }
static pthread_barrier_t gate;
static uint64_t deadline;
struct client {struct sockaddr_in addr; uint32_t *latency; size_t count,errors;};
static void *run(void *p) {
 struct client *c=p; pthread_barrier_wait(&gate);
 while(now_ns()<deadline) {
  uint64_t begin=now_ns(); int phase=0,saved_errno=0; int ok=1,fd=socket(AF_INET,SOCK_STREAM,0);
  char data[2048]; size_t used=0;
  if(fd<0){ok=0;saved_errno=errno;}
  if(ok){struct timeval t={2,0};setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&t,sizeof(t));setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&t,sizeof(t));}
  if(ok)phase=1;
  if(ok&&connect(fd,(struct sockaddr*)&c->addr,sizeof(c->addr))){ok=0;saved_errno=errno;}
  const char *q="GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n";size_t left=strlen(q);
  if(ok)phase=2;
  while(ok&&left){ssize_t n=send(fd,q,left,MSG_NOSIGNAL);if(n<=0){ok=0;saved_errno=errno;break;}q+=n;left-=(size_t)n;}
  if(ok)phase=3;
  while(ok){ssize_t n=recv(fd,data+used,sizeof(data)-1-used,0);if(n<0){ok=0;saved_errno=errno;break;}if(!n)break;used+=(size_t)n;if(used==sizeof(data)-1){ok=0;break;}}
  if(fd>=0)close(fd);
  data[used]=0;
  char *body=strstr(data,"\r\n\r\n");
  if(!ok||strncmp(data,"HTTP/1.1 200 OK\r\n",17)||!body||strcmp(body+4,"startup preserved")){if(c->errors<4)fprintf(stderr,"request error phase=%d errno=%d bytes=%zu\n",phase,saved_errno,used);c->errors++;continue;}
  if(c->count<SAMPLES)c->latency[c->count]=(uint32_t)((now_ns()-begin)/1000);
  c->count++;
 }
 return NULL;
}
static int compare(const void *a,const void *b){uint32_t x=*(const uint32_t*)a,y=*(const uint32_t*)b;return(x>y)-(x<y);}
int main(int argc,char **argv){
 if(argc!=4)return 2;
 signal(SIGPIPE,SIG_IGN);int threads=atoi(argv[3]),port=atoi(argv[1]),ms=atoi(argv[2]);
 if(threads<1||threads>128||ms<1)return 3;
 struct client *c=calloc((size_t)threads,sizeof(*c));pthread_t *t=calloc((size_t)threads,sizeof(*t));if(!c||!t)return 4;
 pthread_barrier_init(&gate,NULL,(unsigned)threads+1);
 for(int i=0;i<threads;i++){c[i].addr.sin_family=AF_INET;c[i].addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK);c[i].addr.sin_port=htons((uint16_t)port);c[i].latency=malloc(SAMPLES*sizeof(uint32_t));if(!c[i].latency||pthread_create(&t[i],NULL,run,&c[i]))return 5;}
 uint64_t begin=now_ns();deadline=begin+(uint64_t)ms*1000000;pthread_barrier_wait(&gate);
 size_t count=0,errors=0;for(int i=0;i<threads;i++){pthread_join(t[i],NULL);count+=c[i].count;errors+=c[i].errors;if(c[i].count>SAMPLES)return 6;}
 double seconds=(now_ns()-begin)/1e9;uint32_t *all=malloc((count?count:1)*sizeof(uint32_t));if(!all)return 7;size_t offset=0;
 for(int i=0;i<threads;i++){memcpy(all+offset,c[i].latency,c[i].count*sizeof(uint32_t));offset+=c[i].count;free(c[i].latency);}qsort(all,count,sizeof(uint32_t),compare);
 printf("{\"requests\":%zu,\"errors\":%zu,\"seconds\":%.9f,\"rps\":%.3f,\"p50_us\":%u,\"p95_us\":%u,\"p99_us\":%u,\"per_client_requests\":[",count,errors,seconds,count/seconds,count?all[count/2]:0,count?all[count*95/100]:0,count?all[count*99/100]:0);
 for(int i=0;i<threads;i++)printf("%s%zu",i?",":"",c[i].count);
 puts("]}");free(all);free(c);free(t);return 0;
}
