#define _GNU_SOURCE
#include "forge/http.h"
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
int __wrap_fr_platform_cpu_count(void) { return 2; }
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    int s = (int)fr_http_listen(atoi(argv[2]));
    if (s < 0) return 3;
    struct sockaddr_in addr;
    socklen_t len = sizeof(addr);
    if (getsockname(s, (struct sockaddr *)&addr, &len)) return 4;
    fr_http_prepare(s, "startup preserved");
    printf("%u\n", (unsigned)ntohs(addr.sin_port)); fflush(stdout);
    if (getchar() != 'g') return 5;
    if (!strcmp(argv[1], "mt")) fr_http_serve_mt(s, 2);
    else if (!strcmp(argv[1], "hybrid")) fr_http_serve_hybrid(s, 2);
    else if (!strcmp(argv[1], "uring")) fr_http_serve_uring(s, 2);
    else if (!strcmp(argv[1], "forever")) fr_http_serve_forever(s);
    else return 6;
    return 7;
}
