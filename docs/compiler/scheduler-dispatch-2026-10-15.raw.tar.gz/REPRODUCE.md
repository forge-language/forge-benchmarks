# Reproduce scheduler dispatch and failed-publication completion

These are local candidates. The immutable runtime base is
`dcbb1929b17c2f1d11fd367ecf80c7c87c58a274`, stdlib base
`6aa28667b83009a415ab2d7ac13ef6c675af7012`. Pins are unchanged.
The dispatch baseline already has the native-depth, lifecycle and affinity fixes.
The separate anchor predates affinity but includes native-depth/lifecycle fixes.
Do not substitute the pristine runtime for either performance baseline.

Use Linux, GCC 13.3.0/glibc 2.39, CMake, Python 3, Ninja for the compiler project,
POSIX threads and a GNU-compatible linker. All output directories below are new.
Source snapshots exclude repository metadata, build trees and generated caches.
They retain licenses and the prior compiler/stdlib work needed by the local tests.

## Integrity, patches and byte-exact reconstruction

```sh
python3 - <<'VERIFY'
from pathlib import Path
import hashlib, json
m = json.loads(Path('manifest.json').read_text())
for name, entry in m['files'].items():
    p = Path(name)
    assert p.stat().st_size == entry['bytes'], name
    assert hashlib.sha256(p.read_bytes()).hexdigest() == entry['sha256'], name
print(len(m['files']), 'files verified')
VERIFY
export TMPDIR=/dev/shm
python3 verify_patches.py
python3 rebuild_variants.py
```

The patch script verifies runtime-incremental.patch against baseline-source,
runtime-cumulative.patch against pinned-runtime-source and the inherited stdlib
patch against pinned-stdlib-source. Every candidate source file is compared after
application. The inherited stdlib changes are from earlier steps, not new dispatch
changes. The source pair is coordinated: new runtime pin behavior must not be
combined blindly with an older stdlib that still implicitly pins workers.

rebuild_variants.py reconstructs all six runtime archives and five noninstrumented
dispatch binaries byte for byte, recorded in reconstruction.json. It preserves
source basenames to retain ELF file symbols. anchor-reconstruction.json records
byte equality for both anchor executables. Archive/object reconstruction was
verified with this toolchain; different compiler/build paths need not reproduce
the Forge driver itself byte for byte.

## Final runtime, compiler project and sanitizers

```sh
cmake -S source-runtime -B /dev/shm/forge-dispatch-repro-runtime -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build /dev/shm/forge-dispatch-repro-runtime -j2
ctest --test-dir /dev/shm/forge-dispatch-repro-runtime --output-on-failure
cmake -S source-project -B /dev/shm/forge-dispatch-repro-project -G Ninja -DCMAKE_BUILD_TYPE=Release -DFORGE_ENABLE_LTO=OFF -DFORGE_RUNTIME_SOURCE_DIR="$PWD/source-runtime" -DFORGE_STDLIB_SOURCE_DIR="$PWD/source-stdlib"
cmake --build /dev/shm/forge-dispatch-repro-project -j2
ctest --test-dir /dev/shm/forge-dispatch-repro-project --output-on-failure
cmake --build /dev/shm/forge-dispatch-repro-project --target forge-selfhost-verify -j2
cmake -S source-stdlib -B /dev/shm/forge-dispatch-repro-sanitized -DFORGE_RUNTIME_SOURCE_DIR="$PWD/source-runtime" -DCMAKE_BUILD_TYPE=Debug '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer'
cmake --build /dev/shm/forge-dispatch-repro-sanitized -j2
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir /dev/shm/forge-dispatch-repro-sanitized --output-on-failure
```

The final runtime passes 8/8 Release and separate ASan/UBSan/leak suites; the
combined sanitized stdlib/runtime passes 17/17. The project passes 31/31. The
self-host stage3/stage4 generated C are byte-identical, with fingerprints in
metadata.json. The recorded stage0 compiler hash is unchanged in this step;
runtime archive fingerprints are recorded separately. No stale self-host output
is used as the check.

Debug runtime builds independently sum private queue counts under the owner
mutex. Release removes those checks and adds no readiness counter/field. Tests
cover late attachment/spawn, queued stop/restart, partial worker creation forcing
steal, initial/requeue failures, receiver wake during native work and the missing
last-task completion wake. Existing suites cover I/O and mailbox wake/commit races,
reduction budgets, native depth and terminal cleanup.

```sh
cmake -S source-runtime -B /dev/shm/forge-dispatch-repro-tsan -DCMAKE_BUILD_TYPE=Debug '-DCMAKE_C_FLAGS=-fsanitize=thread -fno-omit-frame-pointer'
cmake --build /dev/shm/forge-dispatch-repro-tsan --target dispatch_test -j2
/dev/shm/forge-dispatch-repro-tsan/bin/dispatch_test
```

The recorded TSan target builds but cannot initialize here (exit 66, unexpected
memory mapping). It is unavailable, not a passing race result. Only Linux/glibc
was executed; no general concurrency/ownership/allocator-exhaustion certification
follows from these tests.

## Missing completion wake counterfactual

failed-wake-baseline.json and failed-wake-candidate.json retain exact link commands
and outcomes. Both link current tests/dispatch_test.c through the existing public
ABI with GNU wraps for fr_run_queue_try_push, fr_thread_start, fr_cond_wait and
fr_cond_signal. Run `dispatch-baseline wake-failure`: it intentionally exits 1 at
the missing-signal assertion. Run `dispatch-candidate wake-failure`: it exits 0,
signals the controller's exact condition and joins it.

The test's real wait-entry markers establish a committed WAITING_RECV worker and
sleeping controller before an external send. Taking the scheduler mutex in send
orders after those waits release it. Rejected publication retires the last task;
no worker received that resumption. Baseline failure is immediate rather than an
inference from a timeout. Signal observation plus actual join validates the fixed
path. Mailbox acceptance and callback completion remain distinct.

## Main dispatch matrix

```sh
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-benchmarks/benchmark/dispatch_bench.c libforge_runtime-baseline.a -pthread -o /dev/shm/dispatch-repro-baseline
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-benchmarks/benchmark/dispatch_bench.c libforge_runtime-candidate.a -pthread -o /dev/shm/dispatch-repro-candidate
python3 source-benchmarks/benchmark/dispatch_compare.py --baseline /dev/shm/dispatch-repro-baseline --candidate /dev/shm/dispatch-repro-candidate --pairs 24 --candidate-first --output /dev/shm/dispatch-repro-matrix
```

The controller requires allowed Linux CPU IDs 0..11; adapt both masks consistently
on another host. It verifies every live thread's inherited mask and explicit pool
size. Producer and workers share the selected CPUs. Each invocation computes
20,000 LCG results, with exact-once/per-item checks and an independent affine
checksum oracle. oracle-check.json records 54 small/wrap-boundary comparisons
against a Python loop.

head-guard-benchmark/results.json retains 32 rows x24 AB/BA pairs, 1,536 measured
invocations and 30,720,000 jobs. Modes are native, native beside 32 parked receivers,
yielded coroutines and half mixed. All workers enter a warm gate before timed
release. Coro publication is outside kernel timing; native publication is inside.
Total additionally includes lifecycle/setup/receiver cleanup. Modes are not
cross-ranked as identical work. Gate primitive setup/teardown, item setup and
verification/sort are outside timing. p99 samples result timestamps inside
callbacks before bookkeeping, using common release for coros and submission time
for native jobs. No in-flight bound is imposed on native publication.

The excluded warmup pair remains in each row. Paired log-geomean/bootstrap
intervals use 5,000 resamples and are descriptive individual sampling estimates,
without multiplicity, post-selection or shared-host systematic-bias protection.
All samples remain; wide four-worker intervals are not filtered out. A small
single-worker coroutine cost remains, so no universal non-inferiority claim is made.

## Rejected variants and mechanism diagnostics

active-guard-probe/results.json records eight-pair W=12 exploration: existing
active count skips pure-native probes but cannot skip scans beside parked receivers.
queued-guard-benchmark/results.json records the exact-counter prototype's full
32x24 matrix. Its heavy-coro controls regress; added stores and changed layout were
not causally separated. head-guard-probe/results.json is the separate eight-pair
W=8/12 heavy preflight. head-order-comparison/results.json compares the unselected
local-head-first candidate against the selected head candidate at W=1/16steps over
24 pairs. Labels mean those exact frozen binaries, not a shared baseline across
all series. None is pooled with the final matrix.

mechanism-probes.json and head-mechanism-probes.json are separate instrumented
runs (2,000 jobs, 12 workers). GNU wraps count coroutine queue primitives only.
Baseline uses 24,000 calls for native/parked modes; final uses zero, and exactly
one successful primitive per queued coroutine in coro/mixed modes. They are not
timing evidence. Exact build commands are in fixture-builds.json and
head-fixture-builds.json; instrumentation needs source-runtime/src and
FORGE_DISPATCH_INSTRUMENT plus --wrap=fr_run_queue_pop/fr_run_queue_steal.

layout-probes.json reports private sizeof/offsets and glibc usable allocation:
baseline/final120/120, counter128/136. The included probe source paths are the
original absolute capture paths; adapt those includes if reproducing layout
outside this workspace. They are not a public scheduler ABI or peak-RSS claim.

## Direct combined-candidate anchor before CPU-affinity changes

```sh
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-benchmarks/benchmark/affinity_bench.c libforge_runtime-pre-affinity.a -pthread -o /dev/shm/dispatch-repro-anchor-baseline
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-benchmarks/benchmark/affinity_bench.c libforge_runtime-candidate.a -pthread -o /dev/shm/dispatch-repro-anchor-candidate
python3 source-benchmarks/benchmark/affinity_compare.py --baseline /dev/shm/dispatch-repro-anchor-baseline --candidate /dev/shm/dispatch-repro-anchor-candidate --pairs 24 --mask-sizes 4 12 --steps 16 1024 --candidate-first --output /dev/shm/dispatch-repro-anchor
```

pre-affinity-anchor/results.json retains eight rows x24 pairs. The baseline is
pre-affinity-source and the separate old archive; both sides use identical gated
affinity fixture source, inputs, toolchain and verified CPU masks. This is a direct
combined-change comparison, not multiplication of historical ratios. Full-mask
auto ratios recover the prior measured cost in this workload, while the four-CPU
auto heavy p99 cost remains despite lower batch time. Equal-count four-worker
controls improve both batch and p99. Neither study establishes HTTP capacity,
CPU quota behavior, general fairness or bounded waiting.

## OMO review trace

Four completed Sisyphus/opencode reviews use opencode/mimo-v2.6-flash-free: design,
rejected counter source, selected head source, selected measurement/anchor excerpt.
Their JSONL and exported sessions preserve real requests and responses. They are
not four approvals of the final code. Incorrect steal-deposit/count assumptions
were resolved against source; the real last-task failed-publication wake concern
was reproduced and fixed. Initialization-before-enqueue is covered by source and
late-attachment regression. The evidence review saw 1/12-worker and anchor excerpts;
4/8-worker data are in the complete report/raw controller output, without claiming
model review of omitted rows. Wall/p99, combined-anchor and remaining-cost scope
are explicit in report.md. No child-agent delegation or automatic safety guarantee
is asserted.
