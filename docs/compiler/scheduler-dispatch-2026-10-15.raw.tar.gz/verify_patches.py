#!/usr/bin/env python3
"""Create and verify runtime patch boundaries plus inherited stdlib changes."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess
import tempfile

p = Path(__file__).resolve().parent
records = []
for name, base, candidate in [
    ('runtime-incremental', 'baseline-source', 'source-runtime'),
    ('runtime-cumulative', 'pinned-runtime-source', 'source-runtime'),
    ('stdlib-inherited-cumulative', 'pinned-stdlib-source', 'source-stdlib'),
]:
    base, candidate = p / base, p / candidate
    names = sorted({f.relative_to(base) for f in base.rglob('*') if f.is_file()} |
                   {f.relative_to(candidate) for f in candidate.rglob('*') if f.is_file()})
    patch, changed = [], []
    for rel in names:
        old, new = base / rel, candidate / rel
        before = old.read_bytes() if old.is_file() else b''
        after = new.read_bytes() if new.is_file() else b''
        if before == after:
            continue
        changed.append(str(rel))
        patch.append(f'diff --git a/{rel} b/{rel}\n')
        if not old.exists():
            patch.append('new file mode 100644\n')
        if not new.exists():
            patch.append('deleted file mode 100644\n')
        patch.extend(difflib.unified_diff(before.decode().splitlines(keepends=True),
                                         after.decode().splitlines(keepends=True),
                                         fromfile=f'a/{rel}' if old.exists() else '/dev/null',
                                         tofile=f'b/{rel}' if new.exists() else '/dev/null'))
    target = p / (name + '.patch')
    target.write_text(''.join(patch))
    with tempfile.TemporaryDirectory() as temp:
        temp = Path(temp)
        shutil.copytree(base, temp, dirs_exist_ok=True)
        subprocess.run(['git', 'apply', str(target)], cwd=temp, check=True, capture_output=True)
        for rel in names:
            actual, expected = temp / rel, candidate / rel
            assert actual.is_file() == expected.is_file(), str(rel)
            if expected.is_file():
                assert actual.read_bytes() == expected.read_bytes(), str(rel)
    records.append({'patch': target.name, 'base': base.name, 'candidate': candidate.name,
                    'changed_files': changed, 'every_source_file_matches': True,
                    'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
(p / 'patch-checks.json').write_text(json.dumps(records, indent=2) + '\n')
print('All three patches applied and matched every candidate source file')
