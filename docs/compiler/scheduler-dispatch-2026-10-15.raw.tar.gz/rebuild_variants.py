#!/usr/bin/env python3
"""Rebuild every measured runtime archive and its uninstrumented C fixture."""
from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).resolve().parent
variants = [
    ('baseline', 'baseline-source', 'libforge_runtime-baseline.a', 'bench-baseline'),
    ('active-guard', 'active-guard-source', 'libforge_runtime-active-guard.a', 'bench-active-guard'),
    ('queued-guard', 'queued-guard-source', 'libforge_runtime-queued-guard.a', 'bench-queued-guard'),
    ('head-guard', 'source-runtime', 'libforge_runtime-candidate.a', 'bench-head-guard'),
    ('head-first', 'head-first-source', 'libforge_runtime-head-first.a', 'bench-head-first'),
    ('pre-affinity', 'pre-affinity-source', 'libforge_runtime-pre-affinity.a', None),
]
records = []
for name, directory, frozen, fixture in variants:
    build = p / 'reconstructed' / name
    commands = [
        ['cmake', '-S', str(p / directory), '-B', str(build), '-DCMAKE_BUILD_TYPE=Release', '-DBUILD_TESTING=OFF'],
        ['cmake', '--build', str(build), '-j2'],
    ]
    row = {'variant': name, 'source': directory, 'commands': []}
    for command in commands:
        result = subprocess.run(command, capture_output=True, text=True)
        row['commands'].append({'command': command, 'status': result.returncode,
                                'stdout': result.stdout, 'stderr': result.stderr})
        assert result.returncode == 0, row
    actual = build / 'lib/libforge_runtime.a'
    expected = p / frozen
    row['archive_equal'] = actual.read_bytes() == expected.read_bytes()
    row['archive_sha256'] = hashlib.sha256(actual.read_bytes()).hexdigest()
    assert row['archive_equal'], row
    if fixture:
        target = build / 'fixture'
        command = ['cc', '-O3', '-std=c11', '-Wall', '-Wextra', '-I', str(p / 'source-runtime/include'),
                   str(p / 'source-benchmarks/benchmark/dispatch_bench.c'), str(actual), '-pthread', '-o', str(target)]
        result = subprocess.run(command, capture_output=True, text=True)
        row['commands'].append({'command': command, 'status': result.returncode,
                                'stdout': result.stdout, 'stderr': result.stderr})
        assert result.returncode == 0, row
        row['fixture_equal'] = target.read_bytes() == (p / fixture).read_bytes()
        row['fixture_sha256'] = hashlib.sha256(target.read_bytes()).hexdigest()
        assert row['fixture_equal'], row
    records.append(row)
(p / 'reconstruction.json').write_text(json.dumps(records, indent=2) + '\n')
print('All six archives and five dispatch fixtures reconstructed byte for byte')
