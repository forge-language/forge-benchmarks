#define _GNU_SOURCE
#include <stdio.h>
#include <malloc.h>
#include "/dev/shm/forge-dispatch-20261015/queued-guard-source/src/scheduler.c"
int main(void){fr_scheduler_t *s=fr_scheduler_create(1);if(!s)return 1;printf("{\"size\":%zu,\"usable\":%zu,\"pending_offset\":%zu,\"workers_offset\":%zu}\n",sizeof(*s),malloc_usable_size(s),offsetof(fr_scheduler_t,native_pending),offsetof(fr_scheduler_t,workers));fr_scheduler_destroy(s);return 0;}
