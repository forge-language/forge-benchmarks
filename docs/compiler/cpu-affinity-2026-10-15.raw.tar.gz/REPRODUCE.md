# Reproduce the local CPU-affinity candidate

These source snapshots are local candidates, not published dependency updates.
Runtime base: dcbb1929b17c2f1d11fd367ecf80c7c87c58a274.
Stdlib base: 6aa28667b83009a415ab2d7ac13ef6c675af7012.
The before-performance library already includes the native-depth and lifecycle
changes; use baseline-source for this incremental boundary, not the pristine base.
metadata.json and fingerprints.json record exact hashes, outcomes and review IDs.

Use Linux, GCC 13.3.0/glibc 2.39, CMake, Python 3, Ninja for the project, POSIX
threads and GNU ld wrapping. Performance fixtures require allowed CPU IDs 0..11;
adapt both variants and the controller consistently on another host. Existing
output directories are rejected. The measurements are finite and shared-host.

## Verify every retained file

```sh
python3 - <<'VERIFY'
from pathlib import Path
import hashlib, json
m = json.loads(Path('manifest.json').read_text())
for name, entry in m['files'].items():
    p = Path(name)
    assert p.stat().st_size == entry['bytes'], name
    assert hashlib.sha256(p.read_bytes()).hexdigest() == entry['sha256'], name
print(len(m['files']), 'files verified')
VERIFY
```

## Runtime and source patches

```sh
export TMPDIR=/dev/shm
cmake -S source-runtime -B /dev/shm/forge-affinity-repro-runtime -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build /dev/shm/forge-affinity-repro-runtime -j2
ctest --test-dir /dev/shm/forge-affinity-repro-runtime --output-on-failure
python3 verify_patches.py
```

Runtime Release passes seven suites. The patch utility regenerates four patches,
applies them in temporary copies and compares every source file byte for byte:
incremental patches use baseline-source/baseline-stdlib; cumulative patches use
pinned-runtime-source/pinned-stdlib-source. The pristine snapshots come from the
exact immutable revisions, with no repository metadata or generated caches.

reconstruction.json contains exact CMake commands and hashes for both frozen
runtime archives, including byte-exact Release rebuilds from baseline-source and
source-runtime with BUILD_TESTING=OFF. fixture-reconstruction.json similarly
rebuilds all four measured benchmark binaries byte for byte. Keep the retained
C source basename affinity_bench.c when repeating ELF byte comparisons.

## Full project, current stdlib and pinned-runtime compatibility

```sh
cmake -S source-project -B /dev/shm/forge-affinity-repro-project -G Ninja -DCMAKE_BUILD_TYPE=Release -DFORGE_ENABLE_LTO=OFF -DFORGE_RUNTIME_SOURCE_DIR="$PWD/source-runtime" -DFORGE_STDLIB_SOURCE_DIR="$PWD/source-stdlib"
cmake --build /dev/shm/forge-affinity-repro-project -j2
ctest --test-dir /dev/shm/forge-affinity-repro-project --output-on-failure
cmake --build /dev/shm/forge-affinity-repro-project --target forge-selfhost-verify -j2
cmake -S source-stdlib -B /dev/shm/forge-affinity-repro-pinned -DCMAKE_BUILD_TYPE=Release -DFORGE_RUNTIME_SOURCE_DIR="$PWD/pinned-runtime-source"
cmake --build /dev/shm/forge-affinity-repro-pinned -j2
ctest --test-dir /dev/shm/forge-affinity-repro-pinned --output-on-failure
```

The final project run passes 30 suites. Current stdlib with the exact older pinned
runtime passes 13. Matched new runtime headers/archives select the available-count
API; matched older headers/archives select the online fallback. Mixing new headers
with an arbitrary older archive is not supported by capability detection.
The macro advertises a count API, not a placement guarantee. Old Linux explicit
pinning remains a no-op when the selected runtime is old.

The candidate stage0 compiler's hash changes because its linked platform object
changes. Stage3/stage4 generated C are identical; fingerprints.json records both
facts. Different project/SDK build paths can change compiler or generated-path
bytes, so no byte-exact compiler reconstruction claim is made here.

## Sanitizers

```sh
cmake -S source-stdlib -B /dev/shm/forge-affinity-repro-sanitized -DFORGE_RUNTIME_SOURCE_DIR="$PWD/source-runtime" -DCMAKE_BUILD_TYPE=Debug '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer'
cmake --build /dev/shm/forge-affinity-repro-sanitized -j2
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir /dev/shm/forge-affinity-repro-sanitized --output-on-failure
```

The combined current stdlib/runtime run passes 16 suites, including inherited HTTP
masks and auto worker counts, startup fault cases, large int64 pin IDs, synthetic
large CPU masks, allocation/probe failures, exact bound and per-thread behavior.
The separate runtime-only sanitizer run passes seven. This is Linux/glibc evidence;
Windows/macOS/musl and real high-ID CPU hardware were not exercised. io_uring is
unavailable, so its enabled path is untested. TLS builds but capacity is unmeasured.
The prior host TSan initialization failure is unresolved; there is no passing
TSan result in this artifact.

## Counterfactuals

counterfactual-results.json retains exact build/run outcomes using the existing
public ABI. Baseline count and pin modes fail, while baseline inheritance passes.
The naive-enable library is baseline-source built with
-DCMAKE_C_FLAGS=-DFORGE_OS_LINUX=1: pin mode passes, but its automatic worker pin
escapes the creator's singleton high-CPU mask and inherit mode fails. Candidate
passes all modes. Each process restores its own lifetime by exiting.

binding-counterfactual.json builds the old and new threading.c against the same
existing ABI. Input 2^32+7 reaches the old helper as CPU 7; the new binding never
forwards it. A standalone link wrapper records the argument rather than actually
changing test-host placement. The normal runtime test separately checks real
explicit pinning and OS rejection.

## Original performance series and focused confirmation

```sh
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-original-benchmark/benchmark/affinity_bench.c libforge_runtime-baseline.a -pthread -o /dev/shm/affinity-repro-original-baseline
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-original-benchmark/benchmark/affinity_bench.c libforge_runtime-candidate.a -pthread -o /dev/shm/affinity-repro-original-candidate
python3 source-original-benchmark/benchmark/affinity_compare.py --baseline /dev/shm/affinity-repro-original-baseline --candidate /dev/shm/affinity-repro-original-candidate --pairs 24 --output /dev/shm/affinity-repro-original
python3 source-focused-controller/affinity_compare.py --baseline /dev/shm/affinity-repro-original-baseline --candidate /dev/shm/affinity-repro-original-candidate --pairs 24 --mask-sizes 12 --steps 16 --candidate-first --output /dev/shm/affinity-repro-focused
```

The first series uses 64 warmup jobs without a per-worker gate. The tiny full-mask
auto row's cost prompted a 24-pair focused confirmation with reversed first order;
it remained slower in point estimate. benchmark/results.json and
full-mask-confirmation/results.json retain both outcomes. probe/results.json is
the earlier two-pair fixture smoke run, excluded from the reported matrices.

## Every-worker gated series

```sh
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-benchmarks/benchmark/affinity_bench.c libforge_runtime-baseline.a -pthread -o /dev/shm/affinity-repro-gated-baseline
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-benchmarks/benchmark/affinity_bench.c libforge_runtime-candidate.a -pthread -o /dev/shm/affinity-repro-gated-candidate
python3 source-benchmarks/benchmark/affinity_compare.py --baseline /dev/shm/affinity-repro-gated-baseline --candidate /dev/shm/affinity-repro-gated-candidate --pairs 24 --candidate-first --output /dev/shm/affinity-repro-gated
```

This fixture gates a warmup callback on every worker before releasing them.
gated-benchmark/results.json retains all 16 rows x24 pairs. The full-mask tiny
auto point still costs about 7%; restricted-mask batches improve, while some p99
latencies regress substantially. All data stay separate, with no removal or
pooling. Bootstrap intervals are descriptive individual sampling intervals,
without multiplicity/systematic-bias protection or non-inferiority guarantees.

Each invocation verifies every live thread mask, worker count, per-item exact-once
execution and LCG output. The Python oracle uses affine exponentiation, independently
checked against 54 small/boundary loop cases. Kernel time includes submit through
stop/join. Total includes create/start, warmup, mask inspection and destroy; item
setup, output verification/sorting and gate primitive setup/teardown are outside.
The producer has no in-flight limit, so queue latency and total batch throughput
are distinct. No service capacity, fairness or CPU-quota result follows.

## OMO

Three completed Sisyphus/opencode reviews use opencode/mimo-v2.6-flash-free:
design, implementation excerpt, evidence/compatibility. Their JSONL and full
session exports contain actual requests and answers. One malformed CLI invocation
failed before creating a session and is not counted. Suggestions were reconciled
against source and tests, including matching-header compatibility, the preserved
void best-effort API, no cross-thread count cache and statistical/tail caveats.
No delegated child-review claim or automatic safety certification is made.
