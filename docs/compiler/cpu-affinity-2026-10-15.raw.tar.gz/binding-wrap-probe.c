#include "forge/threading.h"
#include <stdint.h>
#include <stdio.h>
static int calls;
void __wrap_fr_thread_pin_cpu(int cpu){calls++;fprintf(stderr,"forwarded_cpu=%d\n",cpu);}
int main(void){fr_threading_pin((INT64_C(1)<<32)+7);return calls?1:0;}
