#define _GNU_SOURCE
#include "forge_runtime.h"
#include "forge/thread.h"
#include <sched.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static cpu_set_t expected;
static atomic_int mismatch;
static void inspect(void *unused) {
    (void)unused;
    cpu_set_t actual;
    if (sched_getaffinity(0,sizeof(actual),&actual) || !CPU_EQUAL(&actual,&expected)) atomic_store(&mismatch,1);
}
int main(int argc,char **argv) {
    if(argc!=2)return 2;
    cpu_set_t original;
    if(sched_getaffinity(0,sizeof(original),&original))return 3;
    int last=-1;
    for(int cpu=0;cpu<CPU_SETSIZE;cpu++)if(CPU_ISSET(cpu,&original))last=cpu;
    if(last<0)return 4;
    CPU_ZERO(&expected);CPU_SET(last,&expected);
    if(!strcmp(argv[1],"pin")) {
        fr_thread_pin_cpu(last);
        cpu_set_t actual;
        if(sched_getaffinity(0,sizeof(actual),&actual))return 5;
        int good=CPU_EQUAL(&actual,&expected);
        fprintf(stderr,"pin expected_cpu=%d actual_count=%d match=%d\n",last,CPU_COUNT(&actual),good);
        return good?0:1;
    }
    if(sched_setaffinity(0,sizeof(expected),&expected))return 6;
    int auto_count=!strcmp(argv[1],"count");
    fr_scheduler_t *s=fr_scheduler_create(auto_count?0:1);
    if(!s)return 7;
    int workers=fr_scheduler_worker_count(s);
    if(auto_count) {
        fprintf(stderr,"auto on CPU %d expected=1 actual=%d\n",last,workers);
        fr_scheduler_destroy(s);
        return workers==1?0:1;
    }
    if(fr_sched_pool_submit(s,inspect,NULL))return 8;
    fr_scheduler_run(s);fr_scheduler_destroy(s);
    fprintf(stderr,"inherited CPU %d mismatch=%d\n",last,atomic_load(&mismatch));
    return atomic_load(&mismatch)?1:0;
}
