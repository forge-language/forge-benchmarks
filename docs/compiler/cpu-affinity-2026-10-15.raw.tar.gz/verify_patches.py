#!/usr/bin/env python3
"""Regenerate each patch and prove full byte equality with the candidate tree."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess
import tempfile

a = Path(__file__).resolve().parent
checks = []
for name in ['runtime', 'stdlib']:
    candidate = a / ('source-' + name)
    for kind, base in [('incremental', a / ('baseline-source' if name == 'runtime' else 'baseline-stdlib')),
                       ('cumulative', a / ('pinned-' + name + '-source'))]:
        names = sorted({p.relative_to(base) for p in base.rglob('*') if p.is_file()} |
                       {p.relative_to(candidate) for p in candidate.rglob('*') if p.is_file()})
        patch, changed = [], []
        for rel in names:
            old, new = base / rel, candidate / rel
            before = old.read_bytes() if old.is_file() else b''
            after = new.read_bytes() if new.is_file() else b''
            if before == after:
                continue
            changed.append(str(rel))
            patch.append(f'diff --git a/{rel} b/{rel}\n')
            if not old.exists():
                patch.append('new file mode 100644\n')
            if not new.exists():
                patch.append('deleted file mode 100644\n')
            patch.extend(difflib.unified_diff(before.decode().splitlines(keepends=True),
                                             after.decode().splitlines(keepends=True),
                                             fromfile=f'a/{rel}' if old.exists() else '/dev/null',
                                             tofile=f'b/{rel}' if new.exists() else '/dev/null'))
        path = a / f'{name}-{kind}.patch'
        path.write_text(''.join(patch))
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            shutil.copytree(base, tmp, dirs_exist_ok=True)
            subprocess.run(['git', 'apply', str(path)], cwd=tmp, check=True, capture_output=True)
            for rel in names:
                got, expected = tmp / rel, candidate / rel
                assert got.is_file() == expected.is_file(), str(rel)
                if expected.is_file():
                    assert got.read_bytes() == expected.read_bytes(), str(rel)
        checks.append({'component': name, 'kind': kind, 'base_snapshot': base.name,
                       'changed_files': changed, 'all_source_files_match_after_apply': True,
                       'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(a / 'patch-checks.json').write_text(json.dumps(checks, indent=2) + '\n')
print('All four patches applied; every retained source file matched')
