from pathlib import Path
import json,random,subprocess
base=Path('/dev/shm/forge-semantic-20261015');out=base/'differential';out.mkdir(exist_ok=True)
rng=random.Random(20261015);rows=[]
for count in [0,1,16,17,64,257]:
 for prefix in ['work_', 'shared_'+('long_prefix_'*24)]:
  for owner in ['top','module','library']:
   fns=[];first={}
   for i in range(count):
    name=prefix+str((i*37)%max(1,count//3));ty=rng.choice(['int','string'])
    first.setdefault(name,ty);fns.append(f'fn {name}(x:{ty}):int{{return {i};}}')
   for kind in ['valid','bad','missing']:
    name=rng.choice(list(first)) if first and kind!='missing' else prefix+'missing'
    ty=first.get(name,'int');argument='1' if (ty=='int')==(kind!='bad') else '"text"'
    wanted=0 if name in first and kind=='valid' else 1
    folder=out/str(len(rows));folder.mkdir(exist_ok=True)
    if owner=='top':source=''.join(fns)+f'native main{{return {name}({argument});}}'
    elif owner=='module':
     (folder/'bucket.fg').write_text(''.join(fns))
     other='string' if ty=='int' else 'int'
     source=f'import bucket;fn {name}(x:{other}):int{{return 99;}}native main{{return bucket.{name}({argument});}}'
    else:source='library bucket{'+''.join(fns).replace('fn ','export fn ')+'}'+f'native main{{return bucket.{name}({argument});}}'
    path=folder/'main.fg';path.write_text(source)
    results={}
    for label in ['baseline','candidate']:
     command=[str(base/('forge-'+label)),str(path),'--check','--diagnostics-json']
     r=subprocess.run(command,capture_output=True,text=True,timeout=20)
     results[label]={'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    assert results['baseline']==results['candidate'],(folder,results)
    assert results['candidate']['returncode']==wanted,(folder,wanted,results)
    rows.append({'source':str(path),'count':count,'owner':owner,'kind':kind,'expected_returncode':wanted,'results':results})
for count in [17,64,257]:
 for owner in ['top','module','library']:
  functions=''.join(f'fn warm_{i}():int{{return pick(1);}}\n' for i in range(count-2))
  functions+='fn pick(x:int):int{return x;}fn pick(x:string):int{return 0;}'
  for bad in [False,True]:
   folder=out/str(len(rows));folder.mkdir(exist_ok=True)
   argument='"bad"' if bad else '1'
   if owner=='top':source=functions+f'native main{{return pick({argument});}}'
   elif owner=='module':
    (folder/'bucket.fg').write_text(functions)
    source=f'import bucket;native main{{return bucket.pick({argument});}}'
   else:source='library bucket{'+functions.replace('fn ','export fn ')+'}'+f'native main{{return bucket.pick({argument});}}'
   path=folder/'main.fg';path.write_text(source);results={}
   for label in ['baseline','candidate']:
    r=subprocess.run([str(base/('forge-'+label)),str(path),'--check','--diagnostics-json'],capture_output=True,text=True,timeout=20)
    results[label]={'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
   assert results['baseline']==results['candidate'],(folder,results)
   assert results['candidate']['returncode']==int(bad),(folder,results)
   rows.append({'source':str(path),'count':count,'owner':owner,'kind':'post-promotion-bad' if bad else 'post-promotion-valid','expected_returncode':int(bad),'results':results})
(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Differential cases:',len(rows),'accepted:',sum(r['expected_returncode']==0 for r in rows),'exact diagnostics/status agreement')
