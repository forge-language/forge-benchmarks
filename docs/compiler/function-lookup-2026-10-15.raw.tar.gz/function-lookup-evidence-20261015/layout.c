#include "function_index.h"
int main(void){printf("entry=%zu descriptor=%zu\n",sizeof(ForgeFunctionEntry),sizeof(ForgeFunctionIndex));return 0;}
