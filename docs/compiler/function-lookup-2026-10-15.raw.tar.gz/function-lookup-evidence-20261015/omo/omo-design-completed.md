I detect investigation/design-review intent — read-only audit of known compiler symbols, no exploration sprawl, no edits. Routing: targeted reads of the named functions, then a concise design-risk review.

One gap remains: the exact call-site logic around `resolve()` in `expression()` (module-first/global fallback, stdlib priority). Targeted pull of those call sites only:

One targeted pull to close the last gap — `expression()`'s direct `resolve()` call site (7 total; 6 accounted for):

The on-disk `semantic.c` changed mid-audit (linear-scan `resolve` → indexed `forge_function_index_get` between reads) — an implementation is in progress. One final targeted pull on the index type itself and its build/free sites:

# Design Risk Review — Semantic Function-Name Index (READ-ONLY)

**Scope:** `resolve()`, `find_fn()`, `forge_check_program()` (compiler/semantic.c), call sites in `call()`/`expression()`/`callback_expression()`, `CgMap` (codegen.c:10–155, 267–305). No edits made.

**Note:** semantic.c changed on disk during this audit — `resolve()` went from linear `find_fn` scans to an in-flight `forge_function_index_get` design (`compiler/function_index.h`). This review therefore doubles as an assessment of that in-progress representation against the baseline precedence contract.

---

## 1. Precedence contract (baseline, must be preserved exactly)

1. **Qualified call `m.f`** (resolve, module.len≠0): scan `p->modules` in declaration order; **first module whose name matches wins entirely** — return its `find_fn` result *even if NULL*. A found-but-missing function blocks later modules **and** the library. Library qualifier consulted **only when no module name matched**; library-hit-but-missing also returns NULL. No cross-scope fallback anywhere in the qualified path.
2. **Unqualified** (module.len==0): top-level functions first, library second (library only on top-level miss).
3. **Call-site order in `call()`**: stdlib priority *first* — `forge_std_c_name` over program imports, then library imports; **only if no stdlib hit** does `resolve()` run: current-module-first (`module.len ? module : c->module`), then global fallback `resolve("", name)` — fallback only when unqualified. Then builtin/binary/`unknown function` fallthrough — **NULL from resolve is not itself an error**.
4. **`thread_spawn`/`thread_spawn_indexed` callbacks: reversed order** — global first, then `c->module`.
5. **`callback_expression`**: same as call() (current-module → global fallback).
6. **`expression()`** — two more sites: `EXPR_IDENT` function reference: `resolve(c->module) || resolve("")`; `EXPR_FIELD` `module.fn` JS-callback reference: single qualified `resolve(base_ident, field)`, no fallback.
7. **Quirk to keep:** `forge_check_program` checks library function bodies with `c.module=""`, so unqualified calls *inside library functions* prefer top-level over library.
8. Consts are checked **before** functions — any call-site resolve during const evaluation must see a built index.

## 2. Representation assessment

**CgMap (codegen) is not a drop-in for semantic.** Reasons: (a) a single `(module,name)` map conflates "module absent" with "module present, fn absent" — the exact distinction rule 1 turns on; (b) `cg_build_symbols` stores library functions only under key `""`, never under the library-name qualifier that rule 1's qualified-library path needs; (c) a hash-map build that de-duplicates module *names* would break the first-matching-module rule.

**The in-flight `ForgeFunctionIndex` is the right shape — keep it**, with conditions:

- Per-owner (`top`, `library`, one index per module) name index over a **borrowed** `FnDecl*` array + count; sorted auxiliary `entries` (name, ordinal), never mutating the AST (declaration order drives diagnostics/emission).
- **Duplicate first-match preserved:** qsort tiebreak on declaration ordinal + lower-bound binary search returns the first declaration; ≤16 owners stay linear — bit-identical to baseline scans.
- **Borrowed lifetimes correct:** keys are `FnDecl.name`/`FileModule.name` views into the AST; valid for the whole `forge_check_program` pass; `forge_function_index_free` releases only the auxiliary array. `error_at` `exit(1)` makes error-path leaks moot.
- **Immutable per-check ✓** — build once, `const` gets thereafter.
- **Reusable ✓** — header-only, already shared with codegen_js.c (coupling noted in §3).
- `resolve()` structure is byte-identical to baseline apart from lookup calls — rules 1–2 hold structurally, including the found-module-missing-fn short-circuit.

**Verdict:** this design satisfies every constraint you listed. It trades one remaining O(module_count) module-name scan (same as baseline) for log-time/linear name lookup within owners — an acceptable, semantics-safe trade; a CgMap-style `(module,name)` hash would buy little and risk rule 1.

## 3. Open risks / verification items

1. **Build-before-use ordering (crash risk).** `Check` fields zero-init; `resolve` with `module.len≠0` indexes `c->module_functions[i]` over `p->module_count`. If index build happens after the const loop (or `module_functions` is under-allocated), const-evaluation resolves segfault. Build must be the first statement of `forge_check_program`; free (top-level, library, per-module entries **and** the `module_functions` array) must follow the natives/processes loops.
2. **Parallel-array invariant.** `resolve` uses the loop index `i` into `module_functions[i]`. That array must be exactly `module_count` long, same order as `p->modules`, no dedup/filtering. Assert or comment this; it's the sharpest edge in the design.
3. **codegen_js coupling.** Same header builds its own indexes — a comparator/semantics change here changes both backends; keep the header's contract documented in one place.
4. **Comparator consistency.** `forge_function_name_compare` (length-then-`strncmp`) must agree with `forge_str_eq` equality — verify `forge_str_eq` is len+memcmp (it appears to be).
5. **`count>16` threshold boundary** — confirm both branches return identical pointers (R14 below).
6. **Out of scope, correctly untouched:** type rules, `arguments()`, `compatible()`, stdlib/binary/builtin fallthrough, diagnostics format.

## 4. High-value regression cases

1. **Duplicate module names:** modules `m₁` (no `f`), `m₂` (has `f`) → `m.f` must be "unknown function" (first module blocks).
2. **Module/library name collision:** module `m` without `f`; library also named `m` *with* `f` → `m.f` must fail, never reach library.
3. **Library qualifier alone:** no module `lib`, library `lib` present → `lib.f` resolves; `lib.missing` → NULL → same error path as baseline.
4. **Top-level vs library same name** (different arity/ret) → unqualified picks top-level.
5. **Unqualified from module context:** module hit; module miss → top-level hit; module+top miss → library hit (three-step order).
6. **Library-body quirk:** inside a library function, unqualified name existing both top-level and in library → top-level wins.
7. **stdlib priority:** top-level fn named like an imported stdlib fn → stdlib wins (standard checked before `resolve`); also via `library.imports`.
8. **thread_spawn reversed order:** callback in both top-level and current module → top-level; module-only → module; name is a local → unchanged error.
9. **EXPR_IDENT reference:** module-only fn name → FUNCTION_REFERENCE; neither → "unknown value".
10. **EXPR_FIELD `mod.fn` reference** → FUNCTION_REFERENCE; plain struct base still falls through to field checking/error.
11. **Qualified file-module missing fn** → "unknown function" with identical span/message; **binary-import module missing fn** → still accepted as `unknown()` via the binary path (index NULL must not short-circuit it).
12. **Duplicate names within one owner** (top-level or module) → first declaration's pointer returned (pointer identity feeds diagnostics).
13. **Threshold:** owner with 16 vs 17 functions containing duplicates → identical first-match across both branches.
14. **Const initializer referencing a function name** with modules present → resolves (and must not crash) — guards build ordering.
15. **Empty context:** consts/natives/processes (`c.module=""`) never touch `module_functions`; `module_count==0` safe with NULL array.
16. **Suite-level:** selfhost_bench, diagnostics_test, driver_test, modular_power_bench byte-identical; `function_index_test.c` covers the index; note `forge_check_program`/`find_fn` had **no** covering tests pre-change — cases 1–3 and 5 deserve a new focused fixture.

**Bottom line:** the in-flight per-owner `ForgeFunctionIndex` preserves every stated precedence rule structurally; the real risks are build/free ordering, the parallel-array invariant, and untested edge fixtures — not the index representation itself.
