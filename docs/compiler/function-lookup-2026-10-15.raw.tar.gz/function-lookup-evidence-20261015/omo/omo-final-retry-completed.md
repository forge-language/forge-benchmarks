## Verdict

No defects found in the attached implementation. The sorted per-owner index is behaviorally equivalent to the linear scan it replaces, on every path examined. Proofs and caveats below.

## 1. Comparator ↔ forge_str_eq agreement, non-NUL slices

- `forge_function_name_compare` (function_index.h:20-24): `n = min(a.len,b.len)`; `strncmp(a.data,b.data,n)` reads at most `n` bytes from each operand, and both slices own ≥ `n` valid bytes — bounded, never requires NUL termination, never reads past either slice. `length==0` short-circuits before any deref (empty/NULL data safe). `strncmp` compares as `unsigned char`, so byte order is well-defined.
- `order==0` ⟺ common-n=prefix equal ∧ lengths equal ⟺ `forge_str_eq` (length + strncmp) true, and conversely. The redundant `forge_str_eq` re-check at function_index.h:56 is therefore consistent with the search predicate, not a second opinion.
- Embedded-NUL slices: both comparator and `forge_str_eq` stop at the same strncmp position, so they remain mutually consistent (identically conservative); linear and binary paths cannot disagree.

## 2. Transitivity and first-winner

- Name order = byte-lexicographic with length tie-break: a total order. Ordinal order on `size_t` via `(>)-( <)`: a total order. Lexicographic composition of two total orders is a total order → transitive, qsort-valid.
- Ordinals are `0..count-1`, unique → no two distinct entries compare equal → sort result is **fully determined regardless of qsort implementation/platform** (deterministic diagnostics), and equal names form one contiguous run ordered by ascending ordinal.
- Lower bound (function_index.h:48-57) uses only the name key, which is the primary sort key, so the `< target` predicate is a true prefix → standard lower_bound is valid → lands on the run's minimum ordinal = first declaration. Linear path (line 44-45) returns first declaration index. **Both paths return the same first-declared FnDecl**, including for duplicates and for the `count<=16` fallback. `low + (high-low)/2` overflow-free; `low < count` guards the out-of-range probe.

## 3. Allocation bounds, AST lifetime, cleanup

- `count<=16` → `entries` stays NULL (designated initializer zeroes it), `get` takes the bounded linear path — matches the ≤16 requirement; 17+ allocates. Test covers 0/1/16/17/257 boundaries.
- Entries store `&functions[i]` into the owner array; `forge_function_index_build` never touches the AST (test asserts full 257-slot `memcmp` against a pre-build copy — no sort/reorder of owner arrays). Ordinals are therefore stable for the whole pass.
- Normal path: semantic.c builds `functions` unconditionally (497), `library_functions` only when `library.present` (498-499, otherwise zeroed by `Check c = {.program=p}`), `module_functions` only when `module_count` (500-501); all freed at 525-530, with `free(NULL)` for the absent cases. codegen_js.c builds at 386-389 only after the early `forge_die` guards (380-384), frees every module index then the array at 488-490; `module_count==0` → NULL array, `module_fn`'s outer loop runs 0 iterations (no NULL deref). Last index use (semantic:524, JS:487) strictly precedes the frees (525, 488). `forge_function_index_free` zeroes → idempotent.
- Repeated invocation: all index state is stack-local per call; no statics/globals in the header → a second `forge_check_program`/`codegen_emit_js` rebuilds identical indexes (deterministic comparator) with no residue.

## 4. Owner namespaces and precedence

- `module_functions[i]`/`g->module_functions[i]` are built in the same order and index range as `p->modules[i]` — namespaces cannot cross owners (test also proves two indexes over identical key slices return their own owner's FnDecl, including after one is freed).
- semantic `resolve` (semantic.c:61-75): qualified → loop returns on the **first module-name match even when the function is absent**, so an earlier matching (even empty) module blocks later same-named modules and a same-named library — as documented at 502-503; unmatched module name falls through to library then NULL. Unqualified → top-level, then library (71-74).
- Call site (`call`, 181-193): stdlib gate computed before resolution (unchanged, index-independent), then current-module, then global (top-level→library); qualified calls never fall back to global. `callback_expression` (110-111) and `EXPR_IDENT` (232) use the same module-then-global sequence. Index replacement is strictly inside `get`, so all tiers return exactly what linear scan returned.
- JS `module_fn` (codegen_js.c:23-31): the outer loop **keeps scanning after a name-matching module misses the function** (`if (function) return` — no early NULL return), i.e., the original nested-loop semantics, deliberately independent of semantic's first-match blocking. Both variants coincide when module names are unique; only duplicate module names distinguish them (unverifiable from the attached files). EXPR_CALL/IDENT/FIELD/QUAL_CALL all route through this one function, so the outer behavior is uniform.

## 5. Module-existence misses

- Qualified call to a nonexistent module: semantic resolve → NULL (loop no-match, library no-match) → `!standard && !builtin && !binary` → "unknown function" (203); JS → `module_fn` NULL → "requires a source module" (185-189). Matching module without the function: semantic returns NULL (blocking); JS continues the scan. Both preserve their respective original shapes.

## 6. Tests (function_index_test.c)

Sufficient for the C surface: threshold boundaries; duplicate keys with distinct payloads where assertions are **pointer equality against `linear()`** (26) — this actually proves first-winner, not mere key equivalence (duplicates arise for count=257 via `(i*71)%113`, and duplicate indices are 113 apart with opposite `ret_type` parity); missing keys incl. empty string, truncated prefix, out-of-range suffix; AST immutability via full-array `memcmp` (30); non-NUL slice keys with a 3-vs-4-length miss (`"abcx"`, 46) proving no over-read; per-owner isolation across frees (42-49).

## Caveats (not counterexamples)

1. **External contract**: overflow/failure handling of `forge_calloc_array` is not in the attached files. `build` dereferences `index.entries[i]` unconditionally after allocation (36), so correctness for `count>16` assumes it never returns NULL (dies instead) and rejects `count * sizeof(*entries)` overflow. Same assumption for the `module_functions` arrays (semantic.c:501, codegen_js.c:387). Single point of dependency; everything else is locally provable.
2. **Header hygiene**: `function_index.h` includes only `ast.h` yet uses `strncmp`, `free`, `forge_calloc_array`, `forge_str_eq` — relies on `ast.h`'s transitive includes (implied to compile by the test TU, which includes only `function_index.h`).
3. **Abnormal paths leak**: `error_at` → `exit(1)` (semantic.c:33) and JS `forge_die`/unsupported-native exits after build leak entries — process-termination only, outside the normal-path requirement.
4. **Pre-existing, index-neutral ordering note**: `thread_spawn*` callback lookup resolves **global first, then current module** (semantic.c:167-168) — inverted vs. `call()`'s module-then-global (187-188). This is a sequence of `resolve` calls, not a property of the index, so the index change cannot have altered it; flagged only because call-site module/global priority was in scope.
5. `compiler_test.py` / `js_test.py` indexed tests were not supplied and are not audited here.
