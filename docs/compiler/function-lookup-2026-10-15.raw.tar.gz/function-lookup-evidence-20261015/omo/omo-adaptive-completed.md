## Delta verdict

No counterexamples. The deferred-sort variant is lookup-equivalent to the proven eager version and every boundary case checks out. Prior comparator / lower_bound / first-winner / namespace / lifetime proofs carry over verbatim — those code regions (function_index.h:23-33, 61-76) are textually unchanged; only the *timing* of allocation changed.

## Boundary cases

- **Zero owner**: `count=0` → `probes_left=0`, `count<=16` → linear loop runs 0 times → NULL, no allocation. ✓
- **Small owner (1–16)**: linear path; `probes_left` never read or charged, never allocates. ✓
- **Last probe hit**: budget `4*count >= count` always, so the 17th element of a 17-owner is reachable in a fresh index; hit returns `&functions[i]` = first declaration. ✓
- **Full miss, exactly exhausted budget**: loop can exit with `i == count` when the final probe consumes the last unit — `if (i == index->count) return NULL` fires, no allocation, genuine miss. Next call starts with `probes_left==0` → `for` guard fails immediately, `i=0 != count` → build + binary. ✓
- **Mid-search exhaustion**: partial prefix scanned (all misses — a hit would have returned), `i < count` → build over the *full* owner, binary answers. Discarding the incomplete scan loses nothing: every hit in the scanned prefix would already have returned; everything else is covered by lower_bound. ✓
- **Repeated early hits**: each hit charges 1 comparison; entries stay NULL as long as budget remains — matching the stated motivation (an owner that is queried only at head positions, or never, pays no sort). Budget is per-index, spent across calls; first-winner is invariant because linear-first-match ≡ lower-bound-min-ordinal (already proven), so mixed linear/binary answers across calls cannot disagree for the same key. ✓
- **Free before ever querying**: `entries==NULL` → `free(NULL)`, descriptor zeroed; nothing was allocated. ✓
- **Overflow/saturation**: `count > SIZE_MAX/4 ? SIZE_MAX : count*4` — the multiply cannot overflow; saturation only defers build longer, and only for physically impossible owner sizes (which die at allocation anyway). The comment's "at most 4*count probes" holds for every feasible owner. Build's allocation now has a *visible* contract: `forge_calloc_array` (common.h:57-61) rejects `count > SIZE_MAX/item_size` and `forge_die`s on NULL — so `entries[i] = ...` at function_index.h:57-58 can never see NULL and the multiply is pre-checked. **This resolves the single external assumption flagged in the prior review.**
- **No stale FnDecl pointers**: probe path returns `&functions[i]` directly into the immutable owner array; lazy-built entries store the same borrowed pointers; neither path ever writes the AST. `probes_left`/`entries` mutation is confined to the private descriptor. ✓

## Contract confirmations from common.h

- `forge_str_eq` (common.h:24-26) is exactly `len equal && strncmp(...,a.len)==0` — the contract the comparator-agreement proof assumed; `compare==0 ⟺ forge_str_eq` still holds, non-NUL slices still safe (`strncmp` bounded by `min` length; `a.len==0` never derefs).
- `forge_calloc_array` overflow check + die-on-failure as above.

## Non-const `get`

Necessary for lazy build; safe as scoped: each `ForgeFunctionIndex` lives in a stack-local `Check`/`JS` for one single-threaded pass, is never shared, never escapes, and the only mutable state is the descriptor's own `probes_left`/`entries`. Callers, owner ordering, and per-owner namespace isolation (one budget and one entry array per owner, same `i`-correspondence to `p->modules[i]`) are unchanged, so semantic's first-module-match blocking and top-level→library / module→global precedence, and JS's independent continue-scanning outer loop, are unaffected.

## Cleanup / repeated invocation

`free` unchanged (frees entries, zeroes whole descriptor including the new field). Normal-path deallocation identical to the eager version: probe path allocates nothing; lazy build allocates exactly what eager build did, and only when a >16 owner is actually queried past budget. A second compiler pass gets fresh zeroed descriptors — no residue, deterministic rebuild.

One residual (pre-existing, unchanged): `error_at`/`forge_die` `exit(1)` paths after a lazy build leak the entries — process-termination only, outside the normal-path requirement.
