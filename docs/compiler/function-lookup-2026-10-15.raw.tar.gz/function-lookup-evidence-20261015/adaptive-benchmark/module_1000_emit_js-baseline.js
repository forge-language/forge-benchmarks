"use strict";
const __forge=(()=>{
const wrap=v=>BigInt.asIntN(64,v),numeric=v=>typeof v==='boolean'?BigInt(v):v;
const arithmetic=(a,b,op)=>{a=numeric(a);b=numeric(b);if(typeof a==='bigint'&&typeof b==='bigint'){if((op==='div'||op==='mod')&&(b===0n||(a===-9223372036854775808n&&b===-1n)))throw new RangeError('Forge integer division');return wrap(op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b);}a=Number(a);b=Number(b);return op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b;};
const bytes=s=>new TextEncoder().encode(s),decode=b=>new TextDecoder('utf-8',{fatal:true}).decode(b);
const eq=(a,b)=>{a=numeric(a);b=numeric(b);return typeof a==='number'&&typeof b==='bigint'||typeof a==='bigint'&&typeof b==='number'?Number(a)===Number(b):a===b;},index=(s,n)=>{if(typeof s!=='string')return s[Number(n)];const b=bytes(s),j=Number(n);return j<0||j>=b.length?-1n:BigInt(b[j]);},i=v=>BigInt(v);
const cbytes=s=>{s=s==null?'':s;const end=s.indexOf(String.fromCharCode(0));return bytes(end<0?s:s.slice(0,end));};
const handles=new Map();let next=1n;const store=v=>{const h=next++;handles.set(h,v);return h;};
const view=h=>handles.get(h),builder=h=>{const b=handles.get(h);return b&&b.kind==='builder'?b:null;};
const reserve=(b,n)=>{if(n<=b.data.length)return;let cap=Math.max(64,b.data.length);while(cap<n)cap*=2;const d=new Uint8Array(cap);d.set(b.data.subarray(0,b.len));b.data=d;};
const range=(v,a,n)=>{if(!v||v.kind!=='view'||a<0n||n<0n)return null;const size=BigInt(v.data.length),from=a<size?a:size,left=size-from;return [Number(from),Number(n<left?n:left)];};
const appendBytes=(h,d)=>{const b=builder(h);if(!b)return 0n;reserve(b,b.len+d.length);b.data.set(d,b.len);b.len+=d.length;return h;};
return {add:(a,b)=>typeof a==='string'&&typeof b==='string'?a+b:arithmetic(a,b,'add'),sub:(a,b)=>arithmetic(a,b,'sub'),mul:(a,b)=>arithmetic(a,b,'mul'),div:(a,b)=>arithmetic(a,b,'div'),mod:(a,b)=>arithmetic(a,b,'mod'),eq,ne:(a,b)=>!eq(a,b),lt:(a,b)=>a<b,le:(a,b)=>a<=b,gt:(a,b)=>a>b,ge:(a,b)=>a>=b,index,println:(...v)=>console.log(v.map(x=>typeof x==='boolean'?(x?'1':'0'):String(x)).join('')),
fr_str_len:s=>i(bytes(s).length),fr_str_concat:(a,b)=>a+b,fr_str_eq:(a,b)=>i(a===b),fr_str_sub:(s,a,n)=>{if(a<0n||n<0n)return null;return decode(bytes(s).slice(Number(a),Number(a+n)));},fr_str_contains:(s,x)=>i(s.includes(x)),fr_str_trim:s=>s.trim(),fr_str_char_at:index,fr_str_append:(s,c)=>{if(c<0n||c>127n)throw new RangeError('JavaScript strings require valid UTF-8');return s+String.fromCharCode(Number(c));},fr_str_append_str:(s,t)=>s+t,fr_str_from_int:String,fr_str_arena_reset:()=>{handles.clear();return 0n;},
fr_str_view:s=>store({kind:'view',data:cbytes(s)}),fr_str_view_len:h=>{const v=view(h);return i(v&&v.kind==='view'?v.data.length:0);},
fr_str_view_at:(h,n)=>{const v=view(h);return !v||v.kind!=='view'||n<0n||n>=BigInt(v.data.length)?-1n:BigInt(v.data[Number(n)]);},
fr_str_view_sub:(h,a,n)=>{const v=view(h),r=range(v,a,n);return r?decode(v.data.subarray(r[0],r[0]+r[1])):null;},
fr_str_view_matches:(h,a,s)=>{const v=view(h);if(!v||v.kind!=='view'||s==null||a<0n||a>BigInt(v.data.length))return 0n;const d=cbytes(s),from=Number(a);if(d.length>v.data.length-from)return 0n;for(let j=0;j<d.length;j++)if(v.data[from+j]!==d[j])return 0n;return 1n;},
fr_str_view_append_byte:(h,c)=>{const v=view(h);if(!v||v.kind!=='view')return 0n;return store({kind:'view',data:cbytes(decode(v.data)+String.fromCharCode(Number(c)))});},
fr_str_builder:()=>store({kind:'builder',data:new Uint8Array(0),len:0}),fr_str_builder_with_capacity:n=>{if(n<0n||n>BigInt(Number.MAX_SAFE_INTEGER))return 0n;try{return store({kind:'builder',data:new Uint8Array(Number(n)),len:0});}catch{return 0n;}},fr_str_builder_append:(h,s)=>appendBytes(h,cbytes(s)),
fr_str_builder_append_view:(h,vh,a,n)=>{const v=view(vh),r=range(v,a,n);return r?appendBytes(h,v.data.subarray(r[0],r[0]+r[1])):0n;},
fr_str_builder_char:(h,c)=>{const b=builder(h);if(!b||c<=0n||c>255n)return 0n;reserve(b,b.len+1);b.data[b.len++]=Number(c);return h;},
fr_str_builder_finish:h=>{const b=builder(h);return b?decode(b.data.subarray(0,b.len)):null;},fr_str_builder_finish_take:h=>{const b=builder(h);if(!b)return null;const s=decode(b.data.subarray(0,b.len));b.data=new Uint8Array(0);b.len=0;return s;},
fr_abs_i:x=>x<0n?-x:x,fr_abs_f:Math.abs,fr_min_i:(a,b)=>a<b?a:b,fr_max_i:(a,b)=>a>b?a:b,fr_clamp_i:(x,a,b)=>x<a?a:x>b?b:x,fr_pow_i:(a,b)=>{if(b<0n)return 0n;let r=1n;while(b>0n){if(b&1n)r=wrap(r*a);a=wrap(a*a);b>>=1n;}return r;},fr_time_now_ms:()=>i(Date.now()),
fr_json_get_string:(s,k)=>{const v=JSON.parse(s)[k];return typeof v==='string'?v:'';},fr_json_get_int:(s,k)=>{const v=JSON.parse(s)[k];if(!Number.isSafeInteger(v))throw new RangeError('Use the lossless browser JSON module');return i(v);},fr_json_stringify_str:(k,v)=>JSON.stringify({[k]:v}),fr_json_stringify_int:(k,v)=>'{'+JSON.stringify(k)+':'+String(v)+'}'};})();
function frmod_helpers_work_0(fr_x) {
  return frmod_helpers_work_1(fr_x);
}

function frmod_helpers_work_1(fr_x) {
  return frmod_helpers_work_2(fr_x);
}

function frmod_helpers_work_2(fr_x) {
  return frmod_helpers_work_3(fr_x);
}

function frmod_helpers_work_3(fr_x) {
  return frmod_helpers_work_4(fr_x);
}

function frmod_helpers_work_4(fr_x) {
  return frmod_helpers_work_5(fr_x);
}

function frmod_helpers_work_5(fr_x) {
  return frmod_helpers_work_6(fr_x);
}

function frmod_helpers_work_6(fr_x) {
  return frmod_helpers_work_7(fr_x);
}

function frmod_helpers_work_7(fr_x) {
  return frmod_helpers_work_8(fr_x);
}

function frmod_helpers_work_8(fr_x) {
  return frmod_helpers_work_9(fr_x);
}

function frmod_helpers_work_9(fr_x) {
  return frmod_helpers_work_10(fr_x);
}

function frmod_helpers_work_10(fr_x) {
  return frmod_helpers_work_11(fr_x);
}

function frmod_helpers_work_11(fr_x) {
  return frmod_helpers_work_12(fr_x);
}

function frmod_helpers_work_12(fr_x) {
  return frmod_helpers_work_13(fr_x);
}

function frmod_helpers_work_13(fr_x) {
  return frmod_helpers_work_14(fr_x);
}

function frmod_helpers_work_14(fr_x) {
  return frmod_helpers_work_15(fr_x);
}

function frmod_helpers_work_15(fr_x) {
  return frmod_helpers_work_16(fr_x);
}

function frmod_helpers_work_16(fr_x) {
  return frmod_helpers_work_17(fr_x);
}

function frmod_helpers_work_17(fr_x) {
  return frmod_helpers_work_18(fr_x);
}

function frmod_helpers_work_18(fr_x) {
  return frmod_helpers_work_19(fr_x);
}

function frmod_helpers_work_19(fr_x) {
  return frmod_helpers_work_20(fr_x);
}

function frmod_helpers_work_20(fr_x) {
  return frmod_helpers_work_21(fr_x);
}

function frmod_helpers_work_21(fr_x) {
  return frmod_helpers_work_22(fr_x);
}

function frmod_helpers_work_22(fr_x) {
  return frmod_helpers_work_23(fr_x);
}

function frmod_helpers_work_23(fr_x) {
  return frmod_helpers_work_24(fr_x);
}

function frmod_helpers_work_24(fr_x) {
  return frmod_helpers_work_25(fr_x);
}

function frmod_helpers_work_25(fr_x) {
  return frmod_helpers_work_26(fr_x);
}

function frmod_helpers_work_26(fr_x) {
  return frmod_helpers_work_27(fr_x);
}

function frmod_helpers_work_27(fr_x) {
  return frmod_helpers_work_28(fr_x);
}

function frmod_helpers_work_28(fr_x) {
  return frmod_helpers_work_29(fr_x);
}

function frmod_helpers_work_29(fr_x) {
  return frmod_helpers_work_30(fr_x);
}

function frmod_helpers_work_30(fr_x) {
  return frmod_helpers_work_31(fr_x);
}

function frmod_helpers_work_31(fr_x) {
  return frmod_helpers_work_32(fr_x);
}

function frmod_helpers_work_32(fr_x) {
  return frmod_helpers_work_33(fr_x);
}

function frmod_helpers_work_33(fr_x) {
  return frmod_helpers_work_34(fr_x);
}

function frmod_helpers_work_34(fr_x) {
  return frmod_helpers_work_35(fr_x);
}

function frmod_helpers_work_35(fr_x) {
  return frmod_helpers_work_36(fr_x);
}

function frmod_helpers_work_36(fr_x) {
  return frmod_helpers_work_37(fr_x);
}

function frmod_helpers_work_37(fr_x) {
  return frmod_helpers_work_38(fr_x);
}

function frmod_helpers_work_38(fr_x) {
  return frmod_helpers_work_39(fr_x);
}

function frmod_helpers_work_39(fr_x) {
  return frmod_helpers_work_40(fr_x);
}

function frmod_helpers_work_40(fr_x) {
  return frmod_helpers_work_41(fr_x);
}

function frmod_helpers_work_41(fr_x) {
  return frmod_helpers_work_42(fr_x);
}

function frmod_helpers_work_42(fr_x) {
  return frmod_helpers_work_43(fr_x);
}

function frmod_helpers_work_43(fr_x) {
  return frmod_helpers_work_44(fr_x);
}

function frmod_helpers_work_44(fr_x) {
  return frmod_helpers_work_45(fr_x);
}

function frmod_helpers_work_45(fr_x) {
  return frmod_helpers_work_46(fr_x);
}

function frmod_helpers_work_46(fr_x) {
  return frmod_helpers_work_47(fr_x);
}

function frmod_helpers_work_47(fr_x) {
  return frmod_helpers_work_48(fr_x);
}

function frmod_helpers_work_48(fr_x) {
  return frmod_helpers_work_49(fr_x);
}

function frmod_helpers_work_49(fr_x) {
  return frmod_helpers_work_50(fr_x);
}

function frmod_helpers_work_50(fr_x) {
  return frmod_helpers_work_51(fr_x);
}

function frmod_helpers_work_51(fr_x) {
  return frmod_helpers_work_52(fr_x);
}

function frmod_helpers_work_52(fr_x) {
  return frmod_helpers_work_53(fr_x);
}

function frmod_helpers_work_53(fr_x) {
  return frmod_helpers_work_54(fr_x);
}

function frmod_helpers_work_54(fr_x) {
  return frmod_helpers_work_55(fr_x);
}

function frmod_helpers_work_55(fr_x) {
  return frmod_helpers_work_56(fr_x);
}

function frmod_helpers_work_56(fr_x) {
  return frmod_helpers_work_57(fr_x);
}

function frmod_helpers_work_57(fr_x) {
  return frmod_helpers_work_58(fr_x);
}

function frmod_helpers_work_58(fr_x) {
  return frmod_helpers_work_59(fr_x);
}

function frmod_helpers_work_59(fr_x) {
  return frmod_helpers_work_60(fr_x);
}

function frmod_helpers_work_60(fr_x) {
  return frmod_helpers_work_61(fr_x);
}

function frmod_helpers_work_61(fr_x) {
  return frmod_helpers_work_62(fr_x);
}

function frmod_helpers_work_62(fr_x) {
  return frmod_helpers_work_63(fr_x);
}

function frmod_helpers_work_63(fr_x) {
  return frmod_helpers_work_64(fr_x);
}

function frmod_helpers_work_64(fr_x) {
  return frmod_helpers_work_65(fr_x);
}

function frmod_helpers_work_65(fr_x) {
  return frmod_helpers_work_66(fr_x);
}

function frmod_helpers_work_66(fr_x) {
  return frmod_helpers_work_67(fr_x);
}

function frmod_helpers_work_67(fr_x) {
  return frmod_helpers_work_68(fr_x);
}

function frmod_helpers_work_68(fr_x) {
  return frmod_helpers_work_69(fr_x);
}

function frmod_helpers_work_69(fr_x) {
  return frmod_helpers_work_70(fr_x);
}

function frmod_helpers_work_70(fr_x) {
  return frmod_helpers_work_71(fr_x);
}

function frmod_helpers_work_71(fr_x) {
  return frmod_helpers_work_72(fr_x);
}

function frmod_helpers_work_72(fr_x) {
  return frmod_helpers_work_73(fr_x);
}

function frmod_helpers_work_73(fr_x) {
  return frmod_helpers_work_74(fr_x);
}

function frmod_helpers_work_74(fr_x) {
  return frmod_helpers_work_75(fr_x);
}

function frmod_helpers_work_75(fr_x) {
  return frmod_helpers_work_76(fr_x);
}

function frmod_helpers_work_76(fr_x) {
  return frmod_helpers_work_77(fr_x);
}

function frmod_helpers_work_77(fr_x) {
  return frmod_helpers_work_78(fr_x);
}

function frmod_helpers_work_78(fr_x) {
  return frmod_helpers_work_79(fr_x);
}

function frmod_helpers_work_79(fr_x) {
  return frmod_helpers_work_80(fr_x);
}

function frmod_helpers_work_80(fr_x) {
  return frmod_helpers_work_81(fr_x);
}

function frmod_helpers_work_81(fr_x) {
  return frmod_helpers_work_82(fr_x);
}

function frmod_helpers_work_82(fr_x) {
  return frmod_helpers_work_83(fr_x);
}

function frmod_helpers_work_83(fr_x) {
  return frmod_helpers_work_84(fr_x);
}

function frmod_helpers_work_84(fr_x) {
  return frmod_helpers_work_85(fr_x);
}

function frmod_helpers_work_85(fr_x) {
  return frmod_helpers_work_86(fr_x);
}

function frmod_helpers_work_86(fr_x) {
  return frmod_helpers_work_87(fr_x);
}

function frmod_helpers_work_87(fr_x) {
  return frmod_helpers_work_88(fr_x);
}

function frmod_helpers_work_88(fr_x) {
  return frmod_helpers_work_89(fr_x);
}

function frmod_helpers_work_89(fr_x) {
  return frmod_helpers_work_90(fr_x);
}

function frmod_helpers_work_90(fr_x) {
  return frmod_helpers_work_91(fr_x);
}

function frmod_helpers_work_91(fr_x) {
  return frmod_helpers_work_92(fr_x);
}

function frmod_helpers_work_92(fr_x) {
  return frmod_helpers_work_93(fr_x);
}

function frmod_helpers_work_93(fr_x) {
  return frmod_helpers_work_94(fr_x);
}

function frmod_helpers_work_94(fr_x) {
  return frmod_helpers_work_95(fr_x);
}

function frmod_helpers_work_95(fr_x) {
  return frmod_helpers_work_96(fr_x);
}

function frmod_helpers_work_96(fr_x) {
  return frmod_helpers_work_97(fr_x);
}

function frmod_helpers_work_97(fr_x) {
  return frmod_helpers_work_98(fr_x);
}

function frmod_helpers_work_98(fr_x) {
  return frmod_helpers_work_99(fr_x);
}

function frmod_helpers_work_99(fr_x) {
  return frmod_helpers_work_100(fr_x);
}

function frmod_helpers_work_100(fr_x) {
  return frmod_helpers_work_101(fr_x);
}

function frmod_helpers_work_101(fr_x) {
  return frmod_helpers_work_102(fr_x);
}

function frmod_helpers_work_102(fr_x) {
  return frmod_helpers_work_103(fr_x);
}

function frmod_helpers_work_103(fr_x) {
  return frmod_helpers_work_104(fr_x);
}

function frmod_helpers_work_104(fr_x) {
  return frmod_helpers_work_105(fr_x);
}

function frmod_helpers_work_105(fr_x) {
  return frmod_helpers_work_106(fr_x);
}

function frmod_helpers_work_106(fr_x) {
  return frmod_helpers_work_107(fr_x);
}

function frmod_helpers_work_107(fr_x) {
  return frmod_helpers_work_108(fr_x);
}

function frmod_helpers_work_108(fr_x) {
  return frmod_helpers_work_109(fr_x);
}

function frmod_helpers_work_109(fr_x) {
  return frmod_helpers_work_110(fr_x);
}

function frmod_helpers_work_110(fr_x) {
  return frmod_helpers_work_111(fr_x);
}

function frmod_helpers_work_111(fr_x) {
  return frmod_helpers_work_112(fr_x);
}

function frmod_helpers_work_112(fr_x) {
  return frmod_helpers_work_113(fr_x);
}

function frmod_helpers_work_113(fr_x) {
  return frmod_helpers_work_114(fr_x);
}

function frmod_helpers_work_114(fr_x) {
  return frmod_helpers_work_115(fr_x);
}

function frmod_helpers_work_115(fr_x) {
  return frmod_helpers_work_116(fr_x);
}

function frmod_helpers_work_116(fr_x) {
  return frmod_helpers_work_117(fr_x);
}

function frmod_helpers_work_117(fr_x) {
  return frmod_helpers_work_118(fr_x);
}

function frmod_helpers_work_118(fr_x) {
  return frmod_helpers_work_119(fr_x);
}

function frmod_helpers_work_119(fr_x) {
  return frmod_helpers_work_120(fr_x);
}

function frmod_helpers_work_120(fr_x) {
  return frmod_helpers_work_121(fr_x);
}

function frmod_helpers_work_121(fr_x) {
  return frmod_helpers_work_122(fr_x);
}

function frmod_helpers_work_122(fr_x) {
  return frmod_helpers_work_123(fr_x);
}

function frmod_helpers_work_123(fr_x) {
  return frmod_helpers_work_124(fr_x);
}

function frmod_helpers_work_124(fr_x) {
  return frmod_helpers_work_125(fr_x);
}

function frmod_helpers_work_125(fr_x) {
  return frmod_helpers_work_126(fr_x);
}

function frmod_helpers_work_126(fr_x) {
  return frmod_helpers_work_127(fr_x);
}

function frmod_helpers_work_127(fr_x) {
  return frmod_helpers_work_128(fr_x);
}

function frmod_helpers_work_128(fr_x) {
  return frmod_helpers_work_129(fr_x);
}

function frmod_helpers_work_129(fr_x) {
  return frmod_helpers_work_130(fr_x);
}

function frmod_helpers_work_130(fr_x) {
  return frmod_helpers_work_131(fr_x);
}

function frmod_helpers_work_131(fr_x) {
  return frmod_helpers_work_132(fr_x);
}

function frmod_helpers_work_132(fr_x) {
  return frmod_helpers_work_133(fr_x);
}

function frmod_helpers_work_133(fr_x) {
  return frmod_helpers_work_134(fr_x);
}

function frmod_helpers_work_134(fr_x) {
  return frmod_helpers_work_135(fr_x);
}

function frmod_helpers_work_135(fr_x) {
  return frmod_helpers_work_136(fr_x);
}

function frmod_helpers_work_136(fr_x) {
  return frmod_helpers_work_137(fr_x);
}

function frmod_helpers_work_137(fr_x) {
  return frmod_helpers_work_138(fr_x);
}

function frmod_helpers_work_138(fr_x) {
  return frmod_helpers_work_139(fr_x);
}

function frmod_helpers_work_139(fr_x) {
  return frmod_helpers_work_140(fr_x);
}

function frmod_helpers_work_140(fr_x) {
  return frmod_helpers_work_141(fr_x);
}

function frmod_helpers_work_141(fr_x) {
  return frmod_helpers_work_142(fr_x);
}

function frmod_helpers_work_142(fr_x) {
  return frmod_helpers_work_143(fr_x);
}

function frmod_helpers_work_143(fr_x) {
  return frmod_helpers_work_144(fr_x);
}

function frmod_helpers_work_144(fr_x) {
  return frmod_helpers_work_145(fr_x);
}

function frmod_helpers_work_145(fr_x) {
  return frmod_helpers_work_146(fr_x);
}

function frmod_helpers_work_146(fr_x) {
  return frmod_helpers_work_147(fr_x);
}

function frmod_helpers_work_147(fr_x) {
  return frmod_helpers_work_148(fr_x);
}

function frmod_helpers_work_148(fr_x) {
  return frmod_helpers_work_149(fr_x);
}

function frmod_helpers_work_149(fr_x) {
  return frmod_helpers_work_150(fr_x);
}

function frmod_helpers_work_150(fr_x) {
  return frmod_helpers_work_151(fr_x);
}

function frmod_helpers_work_151(fr_x) {
  return frmod_helpers_work_152(fr_x);
}

function frmod_helpers_work_152(fr_x) {
  return frmod_helpers_work_153(fr_x);
}

function frmod_helpers_work_153(fr_x) {
  return frmod_helpers_work_154(fr_x);
}

function frmod_helpers_work_154(fr_x) {
  return frmod_helpers_work_155(fr_x);
}

function frmod_helpers_work_155(fr_x) {
  return frmod_helpers_work_156(fr_x);
}

function frmod_helpers_work_156(fr_x) {
  return frmod_helpers_work_157(fr_x);
}

function frmod_helpers_work_157(fr_x) {
  return frmod_helpers_work_158(fr_x);
}

function frmod_helpers_work_158(fr_x) {
  return frmod_helpers_work_159(fr_x);
}

function frmod_helpers_work_159(fr_x) {
  return frmod_helpers_work_160(fr_x);
}

function frmod_helpers_work_160(fr_x) {
  return frmod_helpers_work_161(fr_x);
}

function frmod_helpers_work_161(fr_x) {
  return frmod_helpers_work_162(fr_x);
}

function frmod_helpers_work_162(fr_x) {
  return frmod_helpers_work_163(fr_x);
}

function frmod_helpers_work_163(fr_x) {
  return frmod_helpers_work_164(fr_x);
}

function frmod_helpers_work_164(fr_x) {
  return frmod_helpers_work_165(fr_x);
}

function frmod_helpers_work_165(fr_x) {
  return frmod_helpers_work_166(fr_x);
}

function frmod_helpers_work_166(fr_x) {
  return frmod_helpers_work_167(fr_x);
}

function frmod_helpers_work_167(fr_x) {
  return frmod_helpers_work_168(fr_x);
}

function frmod_helpers_work_168(fr_x) {
  return frmod_helpers_work_169(fr_x);
}

function frmod_helpers_work_169(fr_x) {
  return frmod_helpers_work_170(fr_x);
}

function frmod_helpers_work_170(fr_x) {
  return frmod_helpers_work_171(fr_x);
}

function frmod_helpers_work_171(fr_x) {
  return frmod_helpers_work_172(fr_x);
}

function frmod_helpers_work_172(fr_x) {
  return frmod_helpers_work_173(fr_x);
}

function frmod_helpers_work_173(fr_x) {
  return frmod_helpers_work_174(fr_x);
}

function frmod_helpers_work_174(fr_x) {
  return frmod_helpers_work_175(fr_x);
}

function frmod_helpers_work_175(fr_x) {
  return frmod_helpers_work_176(fr_x);
}

function frmod_helpers_work_176(fr_x) {
  return frmod_helpers_work_177(fr_x);
}

function frmod_helpers_work_177(fr_x) {
  return frmod_helpers_work_178(fr_x);
}

function frmod_helpers_work_178(fr_x) {
  return frmod_helpers_work_179(fr_x);
}

function frmod_helpers_work_179(fr_x) {
  return frmod_helpers_work_180(fr_x);
}

function frmod_helpers_work_180(fr_x) {
  return frmod_helpers_work_181(fr_x);
}

function frmod_helpers_work_181(fr_x) {
  return frmod_helpers_work_182(fr_x);
}

function frmod_helpers_work_182(fr_x) {
  return frmod_helpers_work_183(fr_x);
}

function frmod_helpers_work_183(fr_x) {
  return frmod_helpers_work_184(fr_x);
}

function frmod_helpers_work_184(fr_x) {
  return frmod_helpers_work_185(fr_x);
}

function frmod_helpers_work_185(fr_x) {
  return frmod_helpers_work_186(fr_x);
}

function frmod_helpers_work_186(fr_x) {
  return frmod_helpers_work_187(fr_x);
}

function frmod_helpers_work_187(fr_x) {
  return frmod_helpers_work_188(fr_x);
}

function frmod_helpers_work_188(fr_x) {
  return frmod_helpers_work_189(fr_x);
}

function frmod_helpers_work_189(fr_x) {
  return frmod_helpers_work_190(fr_x);
}

function frmod_helpers_work_190(fr_x) {
  return frmod_helpers_work_191(fr_x);
}

function frmod_helpers_work_191(fr_x) {
  return frmod_helpers_work_192(fr_x);
}

function frmod_helpers_work_192(fr_x) {
  return frmod_helpers_work_193(fr_x);
}

function frmod_helpers_work_193(fr_x) {
  return frmod_helpers_work_194(fr_x);
}

function frmod_helpers_work_194(fr_x) {
  return frmod_helpers_work_195(fr_x);
}

function frmod_helpers_work_195(fr_x) {
  return frmod_helpers_work_196(fr_x);
}

function frmod_helpers_work_196(fr_x) {
  return frmod_helpers_work_197(fr_x);
}

function frmod_helpers_work_197(fr_x) {
  return frmod_helpers_work_198(fr_x);
}

function frmod_helpers_work_198(fr_x) {
  return frmod_helpers_work_199(fr_x);
}

function frmod_helpers_work_199(fr_x) {
  return frmod_helpers_work_200(fr_x);
}

function frmod_helpers_work_200(fr_x) {
  return frmod_helpers_work_201(fr_x);
}

function frmod_helpers_work_201(fr_x) {
  return frmod_helpers_work_202(fr_x);
}

function frmod_helpers_work_202(fr_x) {
  return frmod_helpers_work_203(fr_x);
}

function frmod_helpers_work_203(fr_x) {
  return frmod_helpers_work_204(fr_x);
}

function frmod_helpers_work_204(fr_x) {
  return frmod_helpers_work_205(fr_x);
}

function frmod_helpers_work_205(fr_x) {
  return frmod_helpers_work_206(fr_x);
}

function frmod_helpers_work_206(fr_x) {
  return frmod_helpers_work_207(fr_x);
}

function frmod_helpers_work_207(fr_x) {
  return frmod_helpers_work_208(fr_x);
}

function frmod_helpers_work_208(fr_x) {
  return frmod_helpers_work_209(fr_x);
}

function frmod_helpers_work_209(fr_x) {
  return frmod_helpers_work_210(fr_x);
}

function frmod_helpers_work_210(fr_x) {
  return frmod_helpers_work_211(fr_x);
}

function frmod_helpers_work_211(fr_x) {
  return frmod_helpers_work_212(fr_x);
}

function frmod_helpers_work_212(fr_x) {
  return frmod_helpers_work_213(fr_x);
}

function frmod_helpers_work_213(fr_x) {
  return frmod_helpers_work_214(fr_x);
}

function frmod_helpers_work_214(fr_x) {
  return frmod_helpers_work_215(fr_x);
}

function frmod_helpers_work_215(fr_x) {
  return frmod_helpers_work_216(fr_x);
}

function frmod_helpers_work_216(fr_x) {
  return frmod_helpers_work_217(fr_x);
}

function frmod_helpers_work_217(fr_x) {
  return frmod_helpers_work_218(fr_x);
}

function frmod_helpers_work_218(fr_x) {
  return frmod_helpers_work_219(fr_x);
}

function frmod_helpers_work_219(fr_x) {
  return frmod_helpers_work_220(fr_x);
}

function frmod_helpers_work_220(fr_x) {
  return frmod_helpers_work_221(fr_x);
}

function frmod_helpers_work_221(fr_x) {
  return frmod_helpers_work_222(fr_x);
}

function frmod_helpers_work_222(fr_x) {
  return frmod_helpers_work_223(fr_x);
}

function frmod_helpers_work_223(fr_x) {
  return frmod_helpers_work_224(fr_x);
}

function frmod_helpers_work_224(fr_x) {
  return frmod_helpers_work_225(fr_x);
}

function frmod_helpers_work_225(fr_x) {
  return frmod_helpers_work_226(fr_x);
}

function frmod_helpers_work_226(fr_x) {
  return frmod_helpers_work_227(fr_x);
}

function frmod_helpers_work_227(fr_x) {
  return frmod_helpers_work_228(fr_x);
}

function frmod_helpers_work_228(fr_x) {
  return frmod_helpers_work_229(fr_x);
}

function frmod_helpers_work_229(fr_x) {
  return frmod_helpers_work_230(fr_x);
}

function frmod_helpers_work_230(fr_x) {
  return frmod_helpers_work_231(fr_x);
}

function frmod_helpers_work_231(fr_x) {
  return frmod_helpers_work_232(fr_x);
}

function frmod_helpers_work_232(fr_x) {
  return frmod_helpers_work_233(fr_x);
}

function frmod_helpers_work_233(fr_x) {
  return frmod_helpers_work_234(fr_x);
}

function frmod_helpers_work_234(fr_x) {
  return frmod_helpers_work_235(fr_x);
}

function frmod_helpers_work_235(fr_x) {
  return frmod_helpers_work_236(fr_x);
}

function frmod_helpers_work_236(fr_x) {
  return frmod_helpers_work_237(fr_x);
}

function frmod_helpers_work_237(fr_x) {
  return frmod_helpers_work_238(fr_x);
}

function frmod_helpers_work_238(fr_x) {
  return frmod_helpers_work_239(fr_x);
}

function frmod_helpers_work_239(fr_x) {
  return frmod_helpers_work_240(fr_x);
}

function frmod_helpers_work_240(fr_x) {
  return frmod_helpers_work_241(fr_x);
}

function frmod_helpers_work_241(fr_x) {
  return frmod_helpers_work_242(fr_x);
}

function frmod_helpers_work_242(fr_x) {
  return frmod_helpers_work_243(fr_x);
}

function frmod_helpers_work_243(fr_x) {
  return frmod_helpers_work_244(fr_x);
}

function frmod_helpers_work_244(fr_x) {
  return frmod_helpers_work_245(fr_x);
}

function frmod_helpers_work_245(fr_x) {
  return frmod_helpers_work_246(fr_x);
}

function frmod_helpers_work_246(fr_x) {
  return frmod_helpers_work_247(fr_x);
}

function frmod_helpers_work_247(fr_x) {
  return frmod_helpers_work_248(fr_x);
}

function frmod_helpers_work_248(fr_x) {
  return frmod_helpers_work_249(fr_x);
}

function frmod_helpers_work_249(fr_x) {
  return frmod_helpers_work_250(fr_x);
}

function frmod_helpers_work_250(fr_x) {
  return frmod_helpers_work_251(fr_x);
}

function frmod_helpers_work_251(fr_x) {
  return frmod_helpers_work_252(fr_x);
}

function frmod_helpers_work_252(fr_x) {
  return frmod_helpers_work_253(fr_x);
}

function frmod_helpers_work_253(fr_x) {
  return frmod_helpers_work_254(fr_x);
}

function frmod_helpers_work_254(fr_x) {
  return frmod_helpers_work_255(fr_x);
}

function frmod_helpers_work_255(fr_x) {
  return frmod_helpers_work_256(fr_x);
}

function frmod_helpers_work_256(fr_x) {
  return frmod_helpers_work_257(fr_x);
}

function frmod_helpers_work_257(fr_x) {
  return frmod_helpers_work_258(fr_x);
}

function frmod_helpers_work_258(fr_x) {
  return frmod_helpers_work_259(fr_x);
}

function frmod_helpers_work_259(fr_x) {
  return frmod_helpers_work_260(fr_x);
}

function frmod_helpers_work_260(fr_x) {
  return frmod_helpers_work_261(fr_x);
}

function frmod_helpers_work_261(fr_x) {
  return frmod_helpers_work_262(fr_x);
}

function frmod_helpers_work_262(fr_x) {
  return frmod_helpers_work_263(fr_x);
}

function frmod_helpers_work_263(fr_x) {
  return frmod_helpers_work_264(fr_x);
}

function frmod_helpers_work_264(fr_x) {
  return frmod_helpers_work_265(fr_x);
}

function frmod_helpers_work_265(fr_x) {
  return frmod_helpers_work_266(fr_x);
}

function frmod_helpers_work_266(fr_x) {
  return frmod_helpers_work_267(fr_x);
}

function frmod_helpers_work_267(fr_x) {
  return frmod_helpers_work_268(fr_x);
}

function frmod_helpers_work_268(fr_x) {
  return frmod_helpers_work_269(fr_x);
}

function frmod_helpers_work_269(fr_x) {
  return frmod_helpers_work_270(fr_x);
}

function frmod_helpers_work_270(fr_x) {
  return frmod_helpers_work_271(fr_x);
}

function frmod_helpers_work_271(fr_x) {
  return frmod_helpers_work_272(fr_x);
}

function frmod_helpers_work_272(fr_x) {
  return frmod_helpers_work_273(fr_x);
}

function frmod_helpers_work_273(fr_x) {
  return frmod_helpers_work_274(fr_x);
}

function frmod_helpers_work_274(fr_x) {
  return frmod_helpers_work_275(fr_x);
}

function frmod_helpers_work_275(fr_x) {
  return frmod_helpers_work_276(fr_x);
}

function frmod_helpers_work_276(fr_x) {
  return frmod_helpers_work_277(fr_x);
}

function frmod_helpers_work_277(fr_x) {
  return frmod_helpers_work_278(fr_x);
}

function frmod_helpers_work_278(fr_x) {
  return frmod_helpers_work_279(fr_x);
}

function frmod_helpers_work_279(fr_x) {
  return frmod_helpers_work_280(fr_x);
}

function frmod_helpers_work_280(fr_x) {
  return frmod_helpers_work_281(fr_x);
}

function frmod_helpers_work_281(fr_x) {
  return frmod_helpers_work_282(fr_x);
}

function frmod_helpers_work_282(fr_x) {
  return frmod_helpers_work_283(fr_x);
}

function frmod_helpers_work_283(fr_x) {
  return frmod_helpers_work_284(fr_x);
}

function frmod_helpers_work_284(fr_x) {
  return frmod_helpers_work_285(fr_x);
}

function frmod_helpers_work_285(fr_x) {
  return frmod_helpers_work_286(fr_x);
}

function frmod_helpers_work_286(fr_x) {
  return frmod_helpers_work_287(fr_x);
}

function frmod_helpers_work_287(fr_x) {
  return frmod_helpers_work_288(fr_x);
}

function frmod_helpers_work_288(fr_x) {
  return frmod_helpers_work_289(fr_x);
}

function frmod_helpers_work_289(fr_x) {
  return frmod_helpers_work_290(fr_x);
}

function frmod_helpers_work_290(fr_x) {
  return frmod_helpers_work_291(fr_x);
}

function frmod_helpers_work_291(fr_x) {
  return frmod_helpers_work_292(fr_x);
}

function frmod_helpers_work_292(fr_x) {
  return frmod_helpers_work_293(fr_x);
}

function frmod_helpers_work_293(fr_x) {
  return frmod_helpers_work_294(fr_x);
}

function frmod_helpers_work_294(fr_x) {
  return frmod_helpers_work_295(fr_x);
}

function frmod_helpers_work_295(fr_x) {
  return frmod_helpers_work_296(fr_x);
}

function frmod_helpers_work_296(fr_x) {
  return frmod_helpers_work_297(fr_x);
}

function frmod_helpers_work_297(fr_x) {
  return frmod_helpers_work_298(fr_x);
}

function frmod_helpers_work_298(fr_x) {
  return frmod_helpers_work_299(fr_x);
}

function frmod_helpers_work_299(fr_x) {
  return frmod_helpers_work_300(fr_x);
}

function frmod_helpers_work_300(fr_x) {
  return frmod_helpers_work_301(fr_x);
}

function frmod_helpers_work_301(fr_x) {
  return frmod_helpers_work_302(fr_x);
}

function frmod_helpers_work_302(fr_x) {
  return frmod_helpers_work_303(fr_x);
}

function frmod_helpers_work_303(fr_x) {
  return frmod_helpers_work_304(fr_x);
}

function frmod_helpers_work_304(fr_x) {
  return frmod_helpers_work_305(fr_x);
}

function frmod_helpers_work_305(fr_x) {
  return frmod_helpers_work_306(fr_x);
}

function frmod_helpers_work_306(fr_x) {
  return frmod_helpers_work_307(fr_x);
}

function frmod_helpers_work_307(fr_x) {
  return frmod_helpers_work_308(fr_x);
}

function frmod_helpers_work_308(fr_x) {
  return frmod_helpers_work_309(fr_x);
}

function frmod_helpers_work_309(fr_x) {
  return frmod_helpers_work_310(fr_x);
}

function frmod_helpers_work_310(fr_x) {
  return frmod_helpers_work_311(fr_x);
}

function frmod_helpers_work_311(fr_x) {
  return frmod_helpers_work_312(fr_x);
}

function frmod_helpers_work_312(fr_x) {
  return frmod_helpers_work_313(fr_x);
}

function frmod_helpers_work_313(fr_x) {
  return frmod_helpers_work_314(fr_x);
}

function frmod_helpers_work_314(fr_x) {
  return frmod_helpers_work_315(fr_x);
}

function frmod_helpers_work_315(fr_x) {
  return frmod_helpers_work_316(fr_x);
}

function frmod_helpers_work_316(fr_x) {
  return frmod_helpers_work_317(fr_x);
}

function frmod_helpers_work_317(fr_x) {
  return frmod_helpers_work_318(fr_x);
}

function frmod_helpers_work_318(fr_x) {
  return frmod_helpers_work_319(fr_x);
}

function frmod_helpers_work_319(fr_x) {
  return frmod_helpers_work_320(fr_x);
}

function frmod_helpers_work_320(fr_x) {
  return frmod_helpers_work_321(fr_x);
}

function frmod_helpers_work_321(fr_x) {
  return frmod_helpers_work_322(fr_x);
}

function frmod_helpers_work_322(fr_x) {
  return frmod_helpers_work_323(fr_x);
}

function frmod_helpers_work_323(fr_x) {
  return frmod_helpers_work_324(fr_x);
}

function frmod_helpers_work_324(fr_x) {
  return frmod_helpers_work_325(fr_x);
}

function frmod_helpers_work_325(fr_x) {
  return frmod_helpers_work_326(fr_x);
}

function frmod_helpers_work_326(fr_x) {
  return frmod_helpers_work_327(fr_x);
}

function frmod_helpers_work_327(fr_x) {
  return frmod_helpers_work_328(fr_x);
}

function frmod_helpers_work_328(fr_x) {
  return frmod_helpers_work_329(fr_x);
}

function frmod_helpers_work_329(fr_x) {
  return frmod_helpers_work_330(fr_x);
}

function frmod_helpers_work_330(fr_x) {
  return frmod_helpers_work_331(fr_x);
}

function frmod_helpers_work_331(fr_x) {
  return frmod_helpers_work_332(fr_x);
}

function frmod_helpers_work_332(fr_x) {
  return frmod_helpers_work_333(fr_x);
}

function frmod_helpers_work_333(fr_x) {
  return frmod_helpers_work_334(fr_x);
}

function frmod_helpers_work_334(fr_x) {
  return frmod_helpers_work_335(fr_x);
}

function frmod_helpers_work_335(fr_x) {
  return frmod_helpers_work_336(fr_x);
}

function frmod_helpers_work_336(fr_x) {
  return frmod_helpers_work_337(fr_x);
}

function frmod_helpers_work_337(fr_x) {
  return frmod_helpers_work_338(fr_x);
}

function frmod_helpers_work_338(fr_x) {
  return frmod_helpers_work_339(fr_x);
}

function frmod_helpers_work_339(fr_x) {
  return frmod_helpers_work_340(fr_x);
}

function frmod_helpers_work_340(fr_x) {
  return frmod_helpers_work_341(fr_x);
}

function frmod_helpers_work_341(fr_x) {
  return frmod_helpers_work_342(fr_x);
}

function frmod_helpers_work_342(fr_x) {
  return frmod_helpers_work_343(fr_x);
}

function frmod_helpers_work_343(fr_x) {
  return frmod_helpers_work_344(fr_x);
}

function frmod_helpers_work_344(fr_x) {
  return frmod_helpers_work_345(fr_x);
}

function frmod_helpers_work_345(fr_x) {
  return frmod_helpers_work_346(fr_x);
}

function frmod_helpers_work_346(fr_x) {
  return frmod_helpers_work_347(fr_x);
}

function frmod_helpers_work_347(fr_x) {
  return frmod_helpers_work_348(fr_x);
}

function frmod_helpers_work_348(fr_x) {
  return frmod_helpers_work_349(fr_x);
}

function frmod_helpers_work_349(fr_x) {
  return frmod_helpers_work_350(fr_x);
}

function frmod_helpers_work_350(fr_x) {
  return frmod_helpers_work_351(fr_x);
}

function frmod_helpers_work_351(fr_x) {
  return frmod_helpers_work_352(fr_x);
}

function frmod_helpers_work_352(fr_x) {
  return frmod_helpers_work_353(fr_x);
}

function frmod_helpers_work_353(fr_x) {
  return frmod_helpers_work_354(fr_x);
}

function frmod_helpers_work_354(fr_x) {
  return frmod_helpers_work_355(fr_x);
}

function frmod_helpers_work_355(fr_x) {
  return frmod_helpers_work_356(fr_x);
}

function frmod_helpers_work_356(fr_x) {
  return frmod_helpers_work_357(fr_x);
}

function frmod_helpers_work_357(fr_x) {
  return frmod_helpers_work_358(fr_x);
}

function frmod_helpers_work_358(fr_x) {
  return frmod_helpers_work_359(fr_x);
}

function frmod_helpers_work_359(fr_x) {
  return frmod_helpers_work_360(fr_x);
}

function frmod_helpers_work_360(fr_x) {
  return frmod_helpers_work_361(fr_x);
}

function frmod_helpers_work_361(fr_x) {
  return frmod_helpers_work_362(fr_x);
}

function frmod_helpers_work_362(fr_x) {
  return frmod_helpers_work_363(fr_x);
}

function frmod_helpers_work_363(fr_x) {
  return frmod_helpers_work_364(fr_x);
}

function frmod_helpers_work_364(fr_x) {
  return frmod_helpers_work_365(fr_x);
}

function frmod_helpers_work_365(fr_x) {
  return frmod_helpers_work_366(fr_x);
}

function frmod_helpers_work_366(fr_x) {
  return frmod_helpers_work_367(fr_x);
}

function frmod_helpers_work_367(fr_x) {
  return frmod_helpers_work_368(fr_x);
}

function frmod_helpers_work_368(fr_x) {
  return frmod_helpers_work_369(fr_x);
}

function frmod_helpers_work_369(fr_x) {
  return frmod_helpers_work_370(fr_x);
}

function frmod_helpers_work_370(fr_x) {
  return frmod_helpers_work_371(fr_x);
}

function frmod_helpers_work_371(fr_x) {
  return frmod_helpers_work_372(fr_x);
}

function frmod_helpers_work_372(fr_x) {
  return frmod_helpers_work_373(fr_x);
}

function frmod_helpers_work_373(fr_x) {
  return frmod_helpers_work_374(fr_x);
}

function frmod_helpers_work_374(fr_x) {
  return frmod_helpers_work_375(fr_x);
}

function frmod_helpers_work_375(fr_x) {
  return frmod_helpers_work_376(fr_x);
}

function frmod_helpers_work_376(fr_x) {
  return frmod_helpers_work_377(fr_x);
}

function frmod_helpers_work_377(fr_x) {
  return frmod_helpers_work_378(fr_x);
}

function frmod_helpers_work_378(fr_x) {
  return frmod_helpers_work_379(fr_x);
}

function frmod_helpers_work_379(fr_x) {
  return frmod_helpers_work_380(fr_x);
}

function frmod_helpers_work_380(fr_x) {
  return frmod_helpers_work_381(fr_x);
}

function frmod_helpers_work_381(fr_x) {
  return frmod_helpers_work_382(fr_x);
}

function frmod_helpers_work_382(fr_x) {
  return frmod_helpers_work_383(fr_x);
}

function frmod_helpers_work_383(fr_x) {
  return frmod_helpers_work_384(fr_x);
}

function frmod_helpers_work_384(fr_x) {
  return frmod_helpers_work_385(fr_x);
}

function frmod_helpers_work_385(fr_x) {
  return frmod_helpers_work_386(fr_x);
}

function frmod_helpers_work_386(fr_x) {
  return frmod_helpers_work_387(fr_x);
}

function frmod_helpers_work_387(fr_x) {
  return frmod_helpers_work_388(fr_x);
}

function frmod_helpers_work_388(fr_x) {
  return frmod_helpers_work_389(fr_x);
}

function frmod_helpers_work_389(fr_x) {
  return frmod_helpers_work_390(fr_x);
}

function frmod_helpers_work_390(fr_x) {
  return frmod_helpers_work_391(fr_x);
}

function frmod_helpers_work_391(fr_x) {
  return frmod_helpers_work_392(fr_x);
}

function frmod_helpers_work_392(fr_x) {
  return frmod_helpers_work_393(fr_x);
}

function frmod_helpers_work_393(fr_x) {
  return frmod_helpers_work_394(fr_x);
}

function frmod_helpers_work_394(fr_x) {
  return frmod_helpers_work_395(fr_x);
}

function frmod_helpers_work_395(fr_x) {
  return frmod_helpers_work_396(fr_x);
}

function frmod_helpers_work_396(fr_x) {
  return frmod_helpers_work_397(fr_x);
}

function frmod_helpers_work_397(fr_x) {
  return frmod_helpers_work_398(fr_x);
}

function frmod_helpers_work_398(fr_x) {
  return frmod_helpers_work_399(fr_x);
}

function frmod_helpers_work_399(fr_x) {
  return frmod_helpers_work_400(fr_x);
}

function frmod_helpers_work_400(fr_x) {
  return frmod_helpers_work_401(fr_x);
}

function frmod_helpers_work_401(fr_x) {
  return frmod_helpers_work_402(fr_x);
}

function frmod_helpers_work_402(fr_x) {
  return frmod_helpers_work_403(fr_x);
}

function frmod_helpers_work_403(fr_x) {
  return frmod_helpers_work_404(fr_x);
}

function frmod_helpers_work_404(fr_x) {
  return frmod_helpers_work_405(fr_x);
}

function frmod_helpers_work_405(fr_x) {
  return frmod_helpers_work_406(fr_x);
}

function frmod_helpers_work_406(fr_x) {
  return frmod_helpers_work_407(fr_x);
}

function frmod_helpers_work_407(fr_x) {
  return frmod_helpers_work_408(fr_x);
}

function frmod_helpers_work_408(fr_x) {
  return frmod_helpers_work_409(fr_x);
}

function frmod_helpers_work_409(fr_x) {
  return frmod_helpers_work_410(fr_x);
}

function frmod_helpers_work_410(fr_x) {
  return frmod_helpers_work_411(fr_x);
}

function frmod_helpers_work_411(fr_x) {
  return frmod_helpers_work_412(fr_x);
}

function frmod_helpers_work_412(fr_x) {
  return frmod_helpers_work_413(fr_x);
}

function frmod_helpers_work_413(fr_x) {
  return frmod_helpers_work_414(fr_x);
}

function frmod_helpers_work_414(fr_x) {
  return frmod_helpers_work_415(fr_x);
}

function frmod_helpers_work_415(fr_x) {
  return frmod_helpers_work_416(fr_x);
}

function frmod_helpers_work_416(fr_x) {
  return frmod_helpers_work_417(fr_x);
}

function frmod_helpers_work_417(fr_x) {
  return frmod_helpers_work_418(fr_x);
}

function frmod_helpers_work_418(fr_x) {
  return frmod_helpers_work_419(fr_x);
}

function frmod_helpers_work_419(fr_x) {
  return frmod_helpers_work_420(fr_x);
}

function frmod_helpers_work_420(fr_x) {
  return frmod_helpers_work_421(fr_x);
}

function frmod_helpers_work_421(fr_x) {
  return frmod_helpers_work_422(fr_x);
}

function frmod_helpers_work_422(fr_x) {
  return frmod_helpers_work_423(fr_x);
}

function frmod_helpers_work_423(fr_x) {
  return frmod_helpers_work_424(fr_x);
}

function frmod_helpers_work_424(fr_x) {
  return frmod_helpers_work_425(fr_x);
}

function frmod_helpers_work_425(fr_x) {
  return frmod_helpers_work_426(fr_x);
}

function frmod_helpers_work_426(fr_x) {
  return frmod_helpers_work_427(fr_x);
}

function frmod_helpers_work_427(fr_x) {
  return frmod_helpers_work_428(fr_x);
}

function frmod_helpers_work_428(fr_x) {
  return frmod_helpers_work_429(fr_x);
}

function frmod_helpers_work_429(fr_x) {
  return frmod_helpers_work_430(fr_x);
}

function frmod_helpers_work_430(fr_x) {
  return frmod_helpers_work_431(fr_x);
}

function frmod_helpers_work_431(fr_x) {
  return frmod_helpers_work_432(fr_x);
}

function frmod_helpers_work_432(fr_x) {
  return frmod_helpers_work_433(fr_x);
}

function frmod_helpers_work_433(fr_x) {
  return frmod_helpers_work_434(fr_x);
}

function frmod_helpers_work_434(fr_x) {
  return frmod_helpers_work_435(fr_x);
}

function frmod_helpers_work_435(fr_x) {
  return frmod_helpers_work_436(fr_x);
}

function frmod_helpers_work_436(fr_x) {
  return frmod_helpers_work_437(fr_x);
}

function frmod_helpers_work_437(fr_x) {
  return frmod_helpers_work_438(fr_x);
}

function frmod_helpers_work_438(fr_x) {
  return frmod_helpers_work_439(fr_x);
}

function frmod_helpers_work_439(fr_x) {
  return frmod_helpers_work_440(fr_x);
}

function frmod_helpers_work_440(fr_x) {
  return frmod_helpers_work_441(fr_x);
}

function frmod_helpers_work_441(fr_x) {
  return frmod_helpers_work_442(fr_x);
}

function frmod_helpers_work_442(fr_x) {
  return frmod_helpers_work_443(fr_x);
}

function frmod_helpers_work_443(fr_x) {
  return frmod_helpers_work_444(fr_x);
}

function frmod_helpers_work_444(fr_x) {
  return frmod_helpers_work_445(fr_x);
}

function frmod_helpers_work_445(fr_x) {
  return frmod_helpers_work_446(fr_x);
}

function frmod_helpers_work_446(fr_x) {
  return frmod_helpers_work_447(fr_x);
}

function frmod_helpers_work_447(fr_x) {
  return frmod_helpers_work_448(fr_x);
}

function frmod_helpers_work_448(fr_x) {
  return frmod_helpers_work_449(fr_x);
}

function frmod_helpers_work_449(fr_x) {
  return frmod_helpers_work_450(fr_x);
}

function frmod_helpers_work_450(fr_x) {
  return frmod_helpers_work_451(fr_x);
}

function frmod_helpers_work_451(fr_x) {
  return frmod_helpers_work_452(fr_x);
}

function frmod_helpers_work_452(fr_x) {
  return frmod_helpers_work_453(fr_x);
}

function frmod_helpers_work_453(fr_x) {
  return frmod_helpers_work_454(fr_x);
}

function frmod_helpers_work_454(fr_x) {
  return frmod_helpers_work_455(fr_x);
}

function frmod_helpers_work_455(fr_x) {
  return frmod_helpers_work_456(fr_x);
}

function frmod_helpers_work_456(fr_x) {
  return frmod_helpers_work_457(fr_x);
}

function frmod_helpers_work_457(fr_x) {
  return frmod_helpers_work_458(fr_x);
}

function frmod_helpers_work_458(fr_x) {
  return frmod_helpers_work_459(fr_x);
}

function frmod_helpers_work_459(fr_x) {
  return frmod_helpers_work_460(fr_x);
}

function frmod_helpers_work_460(fr_x) {
  return frmod_helpers_work_461(fr_x);
}

function frmod_helpers_work_461(fr_x) {
  return frmod_helpers_work_462(fr_x);
}

function frmod_helpers_work_462(fr_x) {
  return frmod_helpers_work_463(fr_x);
}

function frmod_helpers_work_463(fr_x) {
  return frmod_helpers_work_464(fr_x);
}

function frmod_helpers_work_464(fr_x) {
  return frmod_helpers_work_465(fr_x);
}

function frmod_helpers_work_465(fr_x) {
  return frmod_helpers_work_466(fr_x);
}

function frmod_helpers_work_466(fr_x) {
  return frmod_helpers_work_467(fr_x);
}

function frmod_helpers_work_467(fr_x) {
  return frmod_helpers_work_468(fr_x);
}

function frmod_helpers_work_468(fr_x) {
  return frmod_helpers_work_469(fr_x);
}

function frmod_helpers_work_469(fr_x) {
  return frmod_helpers_work_470(fr_x);
}

function frmod_helpers_work_470(fr_x) {
  return frmod_helpers_work_471(fr_x);
}

function frmod_helpers_work_471(fr_x) {
  return frmod_helpers_work_472(fr_x);
}

function frmod_helpers_work_472(fr_x) {
  return frmod_helpers_work_473(fr_x);
}

function frmod_helpers_work_473(fr_x) {
  return frmod_helpers_work_474(fr_x);
}

function frmod_helpers_work_474(fr_x) {
  return frmod_helpers_work_475(fr_x);
}

function frmod_helpers_work_475(fr_x) {
  return frmod_helpers_work_476(fr_x);
}

function frmod_helpers_work_476(fr_x) {
  return frmod_helpers_work_477(fr_x);
}

function frmod_helpers_work_477(fr_x) {
  return frmod_helpers_work_478(fr_x);
}

function frmod_helpers_work_478(fr_x) {
  return frmod_helpers_work_479(fr_x);
}

function frmod_helpers_work_479(fr_x) {
  return frmod_helpers_work_480(fr_x);
}

function frmod_helpers_work_480(fr_x) {
  return frmod_helpers_work_481(fr_x);
}

function frmod_helpers_work_481(fr_x) {
  return frmod_helpers_work_482(fr_x);
}

function frmod_helpers_work_482(fr_x) {
  return frmod_helpers_work_483(fr_x);
}

function frmod_helpers_work_483(fr_x) {
  return frmod_helpers_work_484(fr_x);
}

function frmod_helpers_work_484(fr_x) {
  return frmod_helpers_work_485(fr_x);
}

function frmod_helpers_work_485(fr_x) {
  return frmod_helpers_work_486(fr_x);
}

function frmod_helpers_work_486(fr_x) {
  return frmod_helpers_work_487(fr_x);
}

function frmod_helpers_work_487(fr_x) {
  return frmod_helpers_work_488(fr_x);
}

function frmod_helpers_work_488(fr_x) {
  return frmod_helpers_work_489(fr_x);
}

function frmod_helpers_work_489(fr_x) {
  return frmod_helpers_work_490(fr_x);
}

function frmod_helpers_work_490(fr_x) {
  return frmod_helpers_work_491(fr_x);
}

function frmod_helpers_work_491(fr_x) {
  return frmod_helpers_work_492(fr_x);
}

function frmod_helpers_work_492(fr_x) {
  return frmod_helpers_work_493(fr_x);
}

function frmod_helpers_work_493(fr_x) {
  return frmod_helpers_work_494(fr_x);
}

function frmod_helpers_work_494(fr_x) {
  return frmod_helpers_work_495(fr_x);
}

function frmod_helpers_work_495(fr_x) {
  return frmod_helpers_work_496(fr_x);
}

function frmod_helpers_work_496(fr_x) {
  return frmod_helpers_work_497(fr_x);
}

function frmod_helpers_work_497(fr_x) {
  return frmod_helpers_work_498(fr_x);
}

function frmod_helpers_work_498(fr_x) {
  return frmod_helpers_work_499(fr_x);
}

function frmod_helpers_work_499(fr_x) {
  return frmod_helpers_work_500(fr_x);
}

function frmod_helpers_work_500(fr_x) {
  return frmod_helpers_work_501(fr_x);
}

function frmod_helpers_work_501(fr_x) {
  return frmod_helpers_work_502(fr_x);
}

function frmod_helpers_work_502(fr_x) {
  return frmod_helpers_work_503(fr_x);
}

function frmod_helpers_work_503(fr_x) {
  return frmod_helpers_work_504(fr_x);
}

function frmod_helpers_work_504(fr_x) {
  return frmod_helpers_work_505(fr_x);
}

function frmod_helpers_work_505(fr_x) {
  return frmod_helpers_work_506(fr_x);
}

function frmod_helpers_work_506(fr_x) {
  return frmod_helpers_work_507(fr_x);
}

function frmod_helpers_work_507(fr_x) {
  return frmod_helpers_work_508(fr_x);
}

function frmod_helpers_work_508(fr_x) {
  return frmod_helpers_work_509(fr_x);
}

function frmod_helpers_work_509(fr_x) {
  return frmod_helpers_work_510(fr_x);
}

function frmod_helpers_work_510(fr_x) {
  return frmod_helpers_work_511(fr_x);
}

function frmod_helpers_work_511(fr_x) {
  return frmod_helpers_work_512(fr_x);
}

function frmod_helpers_work_512(fr_x) {
  return frmod_helpers_work_513(fr_x);
}

function frmod_helpers_work_513(fr_x) {
  return frmod_helpers_work_514(fr_x);
}

function frmod_helpers_work_514(fr_x) {
  return frmod_helpers_work_515(fr_x);
}

function frmod_helpers_work_515(fr_x) {
  return frmod_helpers_work_516(fr_x);
}

function frmod_helpers_work_516(fr_x) {
  return frmod_helpers_work_517(fr_x);
}

function frmod_helpers_work_517(fr_x) {
  return frmod_helpers_work_518(fr_x);
}

function frmod_helpers_work_518(fr_x) {
  return frmod_helpers_work_519(fr_x);
}

function frmod_helpers_work_519(fr_x) {
  return frmod_helpers_work_520(fr_x);
}

function frmod_helpers_work_520(fr_x) {
  return frmod_helpers_work_521(fr_x);
}

function frmod_helpers_work_521(fr_x) {
  return frmod_helpers_work_522(fr_x);
}

function frmod_helpers_work_522(fr_x) {
  return frmod_helpers_work_523(fr_x);
}

function frmod_helpers_work_523(fr_x) {
  return frmod_helpers_work_524(fr_x);
}

function frmod_helpers_work_524(fr_x) {
  return frmod_helpers_work_525(fr_x);
}

function frmod_helpers_work_525(fr_x) {
  return frmod_helpers_work_526(fr_x);
}

function frmod_helpers_work_526(fr_x) {
  return frmod_helpers_work_527(fr_x);
}

function frmod_helpers_work_527(fr_x) {
  return frmod_helpers_work_528(fr_x);
}

function frmod_helpers_work_528(fr_x) {
  return frmod_helpers_work_529(fr_x);
}

function frmod_helpers_work_529(fr_x) {
  return frmod_helpers_work_530(fr_x);
}

function frmod_helpers_work_530(fr_x) {
  return frmod_helpers_work_531(fr_x);
}

function frmod_helpers_work_531(fr_x) {
  return frmod_helpers_work_532(fr_x);
}

function frmod_helpers_work_532(fr_x) {
  return frmod_helpers_work_533(fr_x);
}

function frmod_helpers_work_533(fr_x) {
  return frmod_helpers_work_534(fr_x);
}

function frmod_helpers_work_534(fr_x) {
  return frmod_helpers_work_535(fr_x);
}

function frmod_helpers_work_535(fr_x) {
  return frmod_helpers_work_536(fr_x);
}

function frmod_helpers_work_536(fr_x) {
  return frmod_helpers_work_537(fr_x);
}

function frmod_helpers_work_537(fr_x) {
  return frmod_helpers_work_538(fr_x);
}

function frmod_helpers_work_538(fr_x) {
  return frmod_helpers_work_539(fr_x);
}

function frmod_helpers_work_539(fr_x) {
  return frmod_helpers_work_540(fr_x);
}

function frmod_helpers_work_540(fr_x) {
  return frmod_helpers_work_541(fr_x);
}

function frmod_helpers_work_541(fr_x) {
  return frmod_helpers_work_542(fr_x);
}

function frmod_helpers_work_542(fr_x) {
  return frmod_helpers_work_543(fr_x);
}

function frmod_helpers_work_543(fr_x) {
  return frmod_helpers_work_544(fr_x);
}

function frmod_helpers_work_544(fr_x) {
  return frmod_helpers_work_545(fr_x);
}

function frmod_helpers_work_545(fr_x) {
  return frmod_helpers_work_546(fr_x);
}

function frmod_helpers_work_546(fr_x) {
  return frmod_helpers_work_547(fr_x);
}

function frmod_helpers_work_547(fr_x) {
  return frmod_helpers_work_548(fr_x);
}

function frmod_helpers_work_548(fr_x) {
  return frmod_helpers_work_549(fr_x);
}

function frmod_helpers_work_549(fr_x) {
  return frmod_helpers_work_550(fr_x);
}

function frmod_helpers_work_550(fr_x) {
  return frmod_helpers_work_551(fr_x);
}

function frmod_helpers_work_551(fr_x) {
  return frmod_helpers_work_552(fr_x);
}

function frmod_helpers_work_552(fr_x) {
  return frmod_helpers_work_553(fr_x);
}

function frmod_helpers_work_553(fr_x) {
  return frmod_helpers_work_554(fr_x);
}

function frmod_helpers_work_554(fr_x) {
  return frmod_helpers_work_555(fr_x);
}

function frmod_helpers_work_555(fr_x) {
  return frmod_helpers_work_556(fr_x);
}

function frmod_helpers_work_556(fr_x) {
  return frmod_helpers_work_557(fr_x);
}

function frmod_helpers_work_557(fr_x) {
  return frmod_helpers_work_558(fr_x);
}

function frmod_helpers_work_558(fr_x) {
  return frmod_helpers_work_559(fr_x);
}

function frmod_helpers_work_559(fr_x) {
  return frmod_helpers_work_560(fr_x);
}

function frmod_helpers_work_560(fr_x) {
  return frmod_helpers_work_561(fr_x);
}

function frmod_helpers_work_561(fr_x) {
  return frmod_helpers_work_562(fr_x);
}

function frmod_helpers_work_562(fr_x) {
  return frmod_helpers_work_563(fr_x);
}

function frmod_helpers_work_563(fr_x) {
  return frmod_helpers_work_564(fr_x);
}

function frmod_helpers_work_564(fr_x) {
  return frmod_helpers_work_565(fr_x);
}

function frmod_helpers_work_565(fr_x) {
  return frmod_helpers_work_566(fr_x);
}

function frmod_helpers_work_566(fr_x) {
  return frmod_helpers_work_567(fr_x);
}

function frmod_helpers_work_567(fr_x) {
  return frmod_helpers_work_568(fr_x);
}

function frmod_helpers_work_568(fr_x) {
  return frmod_helpers_work_569(fr_x);
}

function frmod_helpers_work_569(fr_x) {
  return frmod_helpers_work_570(fr_x);
}

function frmod_helpers_work_570(fr_x) {
  return frmod_helpers_work_571(fr_x);
}

function frmod_helpers_work_571(fr_x) {
  return frmod_helpers_work_572(fr_x);
}

function frmod_helpers_work_572(fr_x) {
  return frmod_helpers_work_573(fr_x);
}

function frmod_helpers_work_573(fr_x) {
  return frmod_helpers_work_574(fr_x);
}

function frmod_helpers_work_574(fr_x) {
  return frmod_helpers_work_575(fr_x);
}

function frmod_helpers_work_575(fr_x) {
  return frmod_helpers_work_576(fr_x);
}

function frmod_helpers_work_576(fr_x) {
  return frmod_helpers_work_577(fr_x);
}

function frmod_helpers_work_577(fr_x) {
  return frmod_helpers_work_578(fr_x);
}

function frmod_helpers_work_578(fr_x) {
  return frmod_helpers_work_579(fr_x);
}

function frmod_helpers_work_579(fr_x) {
  return frmod_helpers_work_580(fr_x);
}

function frmod_helpers_work_580(fr_x) {
  return frmod_helpers_work_581(fr_x);
}

function frmod_helpers_work_581(fr_x) {
  return frmod_helpers_work_582(fr_x);
}

function frmod_helpers_work_582(fr_x) {
  return frmod_helpers_work_583(fr_x);
}

function frmod_helpers_work_583(fr_x) {
  return frmod_helpers_work_584(fr_x);
}

function frmod_helpers_work_584(fr_x) {
  return frmod_helpers_work_585(fr_x);
}

function frmod_helpers_work_585(fr_x) {
  return frmod_helpers_work_586(fr_x);
}

function frmod_helpers_work_586(fr_x) {
  return frmod_helpers_work_587(fr_x);
}

function frmod_helpers_work_587(fr_x) {
  return frmod_helpers_work_588(fr_x);
}

function frmod_helpers_work_588(fr_x) {
  return frmod_helpers_work_589(fr_x);
}

function frmod_helpers_work_589(fr_x) {
  return frmod_helpers_work_590(fr_x);
}

function frmod_helpers_work_590(fr_x) {
  return frmod_helpers_work_591(fr_x);
}

function frmod_helpers_work_591(fr_x) {
  return frmod_helpers_work_592(fr_x);
}

function frmod_helpers_work_592(fr_x) {
  return frmod_helpers_work_593(fr_x);
}

function frmod_helpers_work_593(fr_x) {
  return frmod_helpers_work_594(fr_x);
}

function frmod_helpers_work_594(fr_x) {
  return frmod_helpers_work_595(fr_x);
}

function frmod_helpers_work_595(fr_x) {
  return frmod_helpers_work_596(fr_x);
}

function frmod_helpers_work_596(fr_x) {
  return frmod_helpers_work_597(fr_x);
}

function frmod_helpers_work_597(fr_x) {
  return frmod_helpers_work_598(fr_x);
}

function frmod_helpers_work_598(fr_x) {
  return frmod_helpers_work_599(fr_x);
}

function frmod_helpers_work_599(fr_x) {
  return frmod_helpers_work_600(fr_x);
}

function frmod_helpers_work_600(fr_x) {
  return frmod_helpers_work_601(fr_x);
}

function frmod_helpers_work_601(fr_x) {
  return frmod_helpers_work_602(fr_x);
}

function frmod_helpers_work_602(fr_x) {
  return frmod_helpers_work_603(fr_x);
}

function frmod_helpers_work_603(fr_x) {
  return frmod_helpers_work_604(fr_x);
}

function frmod_helpers_work_604(fr_x) {
  return frmod_helpers_work_605(fr_x);
}

function frmod_helpers_work_605(fr_x) {
  return frmod_helpers_work_606(fr_x);
}

function frmod_helpers_work_606(fr_x) {
  return frmod_helpers_work_607(fr_x);
}

function frmod_helpers_work_607(fr_x) {
  return frmod_helpers_work_608(fr_x);
}

function frmod_helpers_work_608(fr_x) {
  return frmod_helpers_work_609(fr_x);
}

function frmod_helpers_work_609(fr_x) {
  return frmod_helpers_work_610(fr_x);
}

function frmod_helpers_work_610(fr_x) {
  return frmod_helpers_work_611(fr_x);
}

function frmod_helpers_work_611(fr_x) {
  return frmod_helpers_work_612(fr_x);
}

function frmod_helpers_work_612(fr_x) {
  return frmod_helpers_work_613(fr_x);
}

function frmod_helpers_work_613(fr_x) {
  return frmod_helpers_work_614(fr_x);
}

function frmod_helpers_work_614(fr_x) {
  return frmod_helpers_work_615(fr_x);
}

function frmod_helpers_work_615(fr_x) {
  return frmod_helpers_work_616(fr_x);
}

function frmod_helpers_work_616(fr_x) {
  return frmod_helpers_work_617(fr_x);
}

function frmod_helpers_work_617(fr_x) {
  return frmod_helpers_work_618(fr_x);
}

function frmod_helpers_work_618(fr_x) {
  return frmod_helpers_work_619(fr_x);
}

function frmod_helpers_work_619(fr_x) {
  return frmod_helpers_work_620(fr_x);
}

function frmod_helpers_work_620(fr_x) {
  return frmod_helpers_work_621(fr_x);
}

function frmod_helpers_work_621(fr_x) {
  return frmod_helpers_work_622(fr_x);
}

function frmod_helpers_work_622(fr_x) {
  return frmod_helpers_work_623(fr_x);
}

function frmod_helpers_work_623(fr_x) {
  return frmod_helpers_work_624(fr_x);
}

function frmod_helpers_work_624(fr_x) {
  return frmod_helpers_work_625(fr_x);
}

function frmod_helpers_work_625(fr_x) {
  return frmod_helpers_work_626(fr_x);
}

function frmod_helpers_work_626(fr_x) {
  return frmod_helpers_work_627(fr_x);
}

function frmod_helpers_work_627(fr_x) {
  return frmod_helpers_work_628(fr_x);
}

function frmod_helpers_work_628(fr_x) {
  return frmod_helpers_work_629(fr_x);
}

function frmod_helpers_work_629(fr_x) {
  return frmod_helpers_work_630(fr_x);
}

function frmod_helpers_work_630(fr_x) {
  return frmod_helpers_work_631(fr_x);
}

function frmod_helpers_work_631(fr_x) {
  return frmod_helpers_work_632(fr_x);
}

function frmod_helpers_work_632(fr_x) {
  return frmod_helpers_work_633(fr_x);
}

function frmod_helpers_work_633(fr_x) {
  return frmod_helpers_work_634(fr_x);
}

function frmod_helpers_work_634(fr_x) {
  return frmod_helpers_work_635(fr_x);
}

function frmod_helpers_work_635(fr_x) {
  return frmod_helpers_work_636(fr_x);
}

function frmod_helpers_work_636(fr_x) {
  return frmod_helpers_work_637(fr_x);
}

function frmod_helpers_work_637(fr_x) {
  return frmod_helpers_work_638(fr_x);
}

function frmod_helpers_work_638(fr_x) {
  return frmod_helpers_work_639(fr_x);
}

function frmod_helpers_work_639(fr_x) {
  return frmod_helpers_work_640(fr_x);
}

function frmod_helpers_work_640(fr_x) {
  return frmod_helpers_work_641(fr_x);
}

function frmod_helpers_work_641(fr_x) {
  return frmod_helpers_work_642(fr_x);
}

function frmod_helpers_work_642(fr_x) {
  return frmod_helpers_work_643(fr_x);
}

function frmod_helpers_work_643(fr_x) {
  return frmod_helpers_work_644(fr_x);
}

function frmod_helpers_work_644(fr_x) {
  return frmod_helpers_work_645(fr_x);
}

function frmod_helpers_work_645(fr_x) {
  return frmod_helpers_work_646(fr_x);
}

function frmod_helpers_work_646(fr_x) {
  return frmod_helpers_work_647(fr_x);
}

function frmod_helpers_work_647(fr_x) {
  return frmod_helpers_work_648(fr_x);
}

function frmod_helpers_work_648(fr_x) {
  return frmod_helpers_work_649(fr_x);
}

function frmod_helpers_work_649(fr_x) {
  return frmod_helpers_work_650(fr_x);
}

function frmod_helpers_work_650(fr_x) {
  return frmod_helpers_work_651(fr_x);
}

function frmod_helpers_work_651(fr_x) {
  return frmod_helpers_work_652(fr_x);
}

function frmod_helpers_work_652(fr_x) {
  return frmod_helpers_work_653(fr_x);
}

function frmod_helpers_work_653(fr_x) {
  return frmod_helpers_work_654(fr_x);
}

function frmod_helpers_work_654(fr_x) {
  return frmod_helpers_work_655(fr_x);
}

function frmod_helpers_work_655(fr_x) {
  return frmod_helpers_work_656(fr_x);
}

function frmod_helpers_work_656(fr_x) {
  return frmod_helpers_work_657(fr_x);
}

function frmod_helpers_work_657(fr_x) {
  return frmod_helpers_work_658(fr_x);
}

function frmod_helpers_work_658(fr_x) {
  return frmod_helpers_work_659(fr_x);
}

function frmod_helpers_work_659(fr_x) {
  return frmod_helpers_work_660(fr_x);
}

function frmod_helpers_work_660(fr_x) {
  return frmod_helpers_work_661(fr_x);
}

function frmod_helpers_work_661(fr_x) {
  return frmod_helpers_work_662(fr_x);
}

function frmod_helpers_work_662(fr_x) {
  return frmod_helpers_work_663(fr_x);
}

function frmod_helpers_work_663(fr_x) {
  return frmod_helpers_work_664(fr_x);
}

function frmod_helpers_work_664(fr_x) {
  return frmod_helpers_work_665(fr_x);
}

function frmod_helpers_work_665(fr_x) {
  return frmod_helpers_work_666(fr_x);
}

function frmod_helpers_work_666(fr_x) {
  return frmod_helpers_work_667(fr_x);
}

function frmod_helpers_work_667(fr_x) {
  return frmod_helpers_work_668(fr_x);
}

function frmod_helpers_work_668(fr_x) {
  return frmod_helpers_work_669(fr_x);
}

function frmod_helpers_work_669(fr_x) {
  return frmod_helpers_work_670(fr_x);
}

function frmod_helpers_work_670(fr_x) {
  return frmod_helpers_work_671(fr_x);
}

function frmod_helpers_work_671(fr_x) {
  return frmod_helpers_work_672(fr_x);
}

function frmod_helpers_work_672(fr_x) {
  return frmod_helpers_work_673(fr_x);
}

function frmod_helpers_work_673(fr_x) {
  return frmod_helpers_work_674(fr_x);
}

function frmod_helpers_work_674(fr_x) {
  return frmod_helpers_work_675(fr_x);
}

function frmod_helpers_work_675(fr_x) {
  return frmod_helpers_work_676(fr_x);
}

function frmod_helpers_work_676(fr_x) {
  return frmod_helpers_work_677(fr_x);
}

function frmod_helpers_work_677(fr_x) {
  return frmod_helpers_work_678(fr_x);
}

function frmod_helpers_work_678(fr_x) {
  return frmod_helpers_work_679(fr_x);
}

function frmod_helpers_work_679(fr_x) {
  return frmod_helpers_work_680(fr_x);
}

function frmod_helpers_work_680(fr_x) {
  return frmod_helpers_work_681(fr_x);
}

function frmod_helpers_work_681(fr_x) {
  return frmod_helpers_work_682(fr_x);
}

function frmod_helpers_work_682(fr_x) {
  return frmod_helpers_work_683(fr_x);
}

function frmod_helpers_work_683(fr_x) {
  return frmod_helpers_work_684(fr_x);
}

function frmod_helpers_work_684(fr_x) {
  return frmod_helpers_work_685(fr_x);
}

function frmod_helpers_work_685(fr_x) {
  return frmod_helpers_work_686(fr_x);
}

function frmod_helpers_work_686(fr_x) {
  return frmod_helpers_work_687(fr_x);
}

function frmod_helpers_work_687(fr_x) {
  return frmod_helpers_work_688(fr_x);
}

function frmod_helpers_work_688(fr_x) {
  return frmod_helpers_work_689(fr_x);
}

function frmod_helpers_work_689(fr_x) {
  return frmod_helpers_work_690(fr_x);
}

function frmod_helpers_work_690(fr_x) {
  return frmod_helpers_work_691(fr_x);
}

function frmod_helpers_work_691(fr_x) {
  return frmod_helpers_work_692(fr_x);
}

function frmod_helpers_work_692(fr_x) {
  return frmod_helpers_work_693(fr_x);
}

function frmod_helpers_work_693(fr_x) {
  return frmod_helpers_work_694(fr_x);
}

function frmod_helpers_work_694(fr_x) {
  return frmod_helpers_work_695(fr_x);
}

function frmod_helpers_work_695(fr_x) {
  return frmod_helpers_work_696(fr_x);
}

function frmod_helpers_work_696(fr_x) {
  return frmod_helpers_work_697(fr_x);
}

function frmod_helpers_work_697(fr_x) {
  return frmod_helpers_work_698(fr_x);
}

function frmod_helpers_work_698(fr_x) {
  return frmod_helpers_work_699(fr_x);
}

function frmod_helpers_work_699(fr_x) {
  return frmod_helpers_work_700(fr_x);
}

function frmod_helpers_work_700(fr_x) {
  return frmod_helpers_work_701(fr_x);
}

function frmod_helpers_work_701(fr_x) {
  return frmod_helpers_work_702(fr_x);
}

function frmod_helpers_work_702(fr_x) {
  return frmod_helpers_work_703(fr_x);
}

function frmod_helpers_work_703(fr_x) {
  return frmod_helpers_work_704(fr_x);
}

function frmod_helpers_work_704(fr_x) {
  return frmod_helpers_work_705(fr_x);
}

function frmod_helpers_work_705(fr_x) {
  return frmod_helpers_work_706(fr_x);
}

function frmod_helpers_work_706(fr_x) {
  return frmod_helpers_work_707(fr_x);
}

function frmod_helpers_work_707(fr_x) {
  return frmod_helpers_work_708(fr_x);
}

function frmod_helpers_work_708(fr_x) {
  return frmod_helpers_work_709(fr_x);
}

function frmod_helpers_work_709(fr_x) {
  return frmod_helpers_work_710(fr_x);
}

function frmod_helpers_work_710(fr_x) {
  return frmod_helpers_work_711(fr_x);
}

function frmod_helpers_work_711(fr_x) {
  return frmod_helpers_work_712(fr_x);
}

function frmod_helpers_work_712(fr_x) {
  return frmod_helpers_work_713(fr_x);
}

function frmod_helpers_work_713(fr_x) {
  return frmod_helpers_work_714(fr_x);
}

function frmod_helpers_work_714(fr_x) {
  return frmod_helpers_work_715(fr_x);
}

function frmod_helpers_work_715(fr_x) {
  return frmod_helpers_work_716(fr_x);
}

function frmod_helpers_work_716(fr_x) {
  return frmod_helpers_work_717(fr_x);
}

function frmod_helpers_work_717(fr_x) {
  return frmod_helpers_work_718(fr_x);
}

function frmod_helpers_work_718(fr_x) {
  return frmod_helpers_work_719(fr_x);
}

function frmod_helpers_work_719(fr_x) {
  return frmod_helpers_work_720(fr_x);
}

function frmod_helpers_work_720(fr_x) {
  return frmod_helpers_work_721(fr_x);
}

function frmod_helpers_work_721(fr_x) {
  return frmod_helpers_work_722(fr_x);
}

function frmod_helpers_work_722(fr_x) {
  return frmod_helpers_work_723(fr_x);
}

function frmod_helpers_work_723(fr_x) {
  return frmod_helpers_work_724(fr_x);
}

function frmod_helpers_work_724(fr_x) {
  return frmod_helpers_work_725(fr_x);
}

function frmod_helpers_work_725(fr_x) {
  return frmod_helpers_work_726(fr_x);
}

function frmod_helpers_work_726(fr_x) {
  return frmod_helpers_work_727(fr_x);
}

function frmod_helpers_work_727(fr_x) {
  return frmod_helpers_work_728(fr_x);
}

function frmod_helpers_work_728(fr_x) {
  return frmod_helpers_work_729(fr_x);
}

function frmod_helpers_work_729(fr_x) {
  return frmod_helpers_work_730(fr_x);
}

function frmod_helpers_work_730(fr_x) {
  return frmod_helpers_work_731(fr_x);
}

function frmod_helpers_work_731(fr_x) {
  return frmod_helpers_work_732(fr_x);
}

function frmod_helpers_work_732(fr_x) {
  return frmod_helpers_work_733(fr_x);
}

function frmod_helpers_work_733(fr_x) {
  return frmod_helpers_work_734(fr_x);
}

function frmod_helpers_work_734(fr_x) {
  return frmod_helpers_work_735(fr_x);
}

function frmod_helpers_work_735(fr_x) {
  return frmod_helpers_work_736(fr_x);
}

function frmod_helpers_work_736(fr_x) {
  return frmod_helpers_work_737(fr_x);
}

function frmod_helpers_work_737(fr_x) {
  return frmod_helpers_work_738(fr_x);
}

function frmod_helpers_work_738(fr_x) {
  return frmod_helpers_work_739(fr_x);
}

function frmod_helpers_work_739(fr_x) {
  return frmod_helpers_work_740(fr_x);
}

function frmod_helpers_work_740(fr_x) {
  return frmod_helpers_work_741(fr_x);
}

function frmod_helpers_work_741(fr_x) {
  return frmod_helpers_work_742(fr_x);
}

function frmod_helpers_work_742(fr_x) {
  return frmod_helpers_work_743(fr_x);
}

function frmod_helpers_work_743(fr_x) {
  return frmod_helpers_work_744(fr_x);
}

function frmod_helpers_work_744(fr_x) {
  return frmod_helpers_work_745(fr_x);
}

function frmod_helpers_work_745(fr_x) {
  return frmod_helpers_work_746(fr_x);
}

function frmod_helpers_work_746(fr_x) {
  return frmod_helpers_work_747(fr_x);
}

function frmod_helpers_work_747(fr_x) {
  return frmod_helpers_work_748(fr_x);
}

function frmod_helpers_work_748(fr_x) {
  return frmod_helpers_work_749(fr_x);
}

function frmod_helpers_work_749(fr_x) {
  return frmod_helpers_work_750(fr_x);
}

function frmod_helpers_work_750(fr_x) {
  return frmod_helpers_work_751(fr_x);
}

function frmod_helpers_work_751(fr_x) {
  return frmod_helpers_work_752(fr_x);
}

function frmod_helpers_work_752(fr_x) {
  return frmod_helpers_work_753(fr_x);
}

function frmod_helpers_work_753(fr_x) {
  return frmod_helpers_work_754(fr_x);
}

function frmod_helpers_work_754(fr_x) {
  return frmod_helpers_work_755(fr_x);
}

function frmod_helpers_work_755(fr_x) {
  return frmod_helpers_work_756(fr_x);
}

function frmod_helpers_work_756(fr_x) {
  return frmod_helpers_work_757(fr_x);
}

function frmod_helpers_work_757(fr_x) {
  return frmod_helpers_work_758(fr_x);
}

function frmod_helpers_work_758(fr_x) {
  return frmod_helpers_work_759(fr_x);
}

function frmod_helpers_work_759(fr_x) {
  return frmod_helpers_work_760(fr_x);
}

function frmod_helpers_work_760(fr_x) {
  return frmod_helpers_work_761(fr_x);
}

function frmod_helpers_work_761(fr_x) {
  return frmod_helpers_work_762(fr_x);
}

function frmod_helpers_work_762(fr_x) {
  return frmod_helpers_work_763(fr_x);
}

function frmod_helpers_work_763(fr_x) {
  return frmod_helpers_work_764(fr_x);
}

function frmod_helpers_work_764(fr_x) {
  return frmod_helpers_work_765(fr_x);
}

function frmod_helpers_work_765(fr_x) {
  return frmod_helpers_work_766(fr_x);
}

function frmod_helpers_work_766(fr_x) {
  return frmod_helpers_work_767(fr_x);
}

function frmod_helpers_work_767(fr_x) {
  return frmod_helpers_work_768(fr_x);
}

function frmod_helpers_work_768(fr_x) {
  return frmod_helpers_work_769(fr_x);
}

function frmod_helpers_work_769(fr_x) {
  return frmod_helpers_work_770(fr_x);
}

function frmod_helpers_work_770(fr_x) {
  return frmod_helpers_work_771(fr_x);
}

function frmod_helpers_work_771(fr_x) {
  return frmod_helpers_work_772(fr_x);
}

function frmod_helpers_work_772(fr_x) {
  return frmod_helpers_work_773(fr_x);
}

function frmod_helpers_work_773(fr_x) {
  return frmod_helpers_work_774(fr_x);
}

function frmod_helpers_work_774(fr_x) {
  return frmod_helpers_work_775(fr_x);
}

function frmod_helpers_work_775(fr_x) {
  return frmod_helpers_work_776(fr_x);
}

function frmod_helpers_work_776(fr_x) {
  return frmod_helpers_work_777(fr_x);
}

function frmod_helpers_work_777(fr_x) {
  return frmod_helpers_work_778(fr_x);
}

function frmod_helpers_work_778(fr_x) {
  return frmod_helpers_work_779(fr_x);
}

function frmod_helpers_work_779(fr_x) {
  return frmod_helpers_work_780(fr_x);
}

function frmod_helpers_work_780(fr_x) {
  return frmod_helpers_work_781(fr_x);
}

function frmod_helpers_work_781(fr_x) {
  return frmod_helpers_work_782(fr_x);
}

function frmod_helpers_work_782(fr_x) {
  return frmod_helpers_work_783(fr_x);
}

function frmod_helpers_work_783(fr_x) {
  return frmod_helpers_work_784(fr_x);
}

function frmod_helpers_work_784(fr_x) {
  return frmod_helpers_work_785(fr_x);
}

function frmod_helpers_work_785(fr_x) {
  return frmod_helpers_work_786(fr_x);
}

function frmod_helpers_work_786(fr_x) {
  return frmod_helpers_work_787(fr_x);
}

function frmod_helpers_work_787(fr_x) {
  return frmod_helpers_work_788(fr_x);
}

function frmod_helpers_work_788(fr_x) {
  return frmod_helpers_work_789(fr_x);
}

function frmod_helpers_work_789(fr_x) {
  return frmod_helpers_work_790(fr_x);
}

function frmod_helpers_work_790(fr_x) {
  return frmod_helpers_work_791(fr_x);
}

function frmod_helpers_work_791(fr_x) {
  return frmod_helpers_work_792(fr_x);
}

function frmod_helpers_work_792(fr_x) {
  return frmod_helpers_work_793(fr_x);
}

function frmod_helpers_work_793(fr_x) {
  return frmod_helpers_work_794(fr_x);
}

function frmod_helpers_work_794(fr_x) {
  return frmod_helpers_work_795(fr_x);
}

function frmod_helpers_work_795(fr_x) {
  return frmod_helpers_work_796(fr_x);
}

function frmod_helpers_work_796(fr_x) {
  return frmod_helpers_work_797(fr_x);
}

function frmod_helpers_work_797(fr_x) {
  return frmod_helpers_work_798(fr_x);
}

function frmod_helpers_work_798(fr_x) {
  return frmod_helpers_work_799(fr_x);
}

function frmod_helpers_work_799(fr_x) {
  return frmod_helpers_work_800(fr_x);
}

function frmod_helpers_work_800(fr_x) {
  return frmod_helpers_work_801(fr_x);
}

function frmod_helpers_work_801(fr_x) {
  return frmod_helpers_work_802(fr_x);
}

function frmod_helpers_work_802(fr_x) {
  return frmod_helpers_work_803(fr_x);
}

function frmod_helpers_work_803(fr_x) {
  return frmod_helpers_work_804(fr_x);
}

function frmod_helpers_work_804(fr_x) {
  return frmod_helpers_work_805(fr_x);
}

function frmod_helpers_work_805(fr_x) {
  return frmod_helpers_work_806(fr_x);
}

function frmod_helpers_work_806(fr_x) {
  return frmod_helpers_work_807(fr_x);
}

function frmod_helpers_work_807(fr_x) {
  return frmod_helpers_work_808(fr_x);
}

function frmod_helpers_work_808(fr_x) {
  return frmod_helpers_work_809(fr_x);
}

function frmod_helpers_work_809(fr_x) {
  return frmod_helpers_work_810(fr_x);
}

function frmod_helpers_work_810(fr_x) {
  return frmod_helpers_work_811(fr_x);
}

function frmod_helpers_work_811(fr_x) {
  return frmod_helpers_work_812(fr_x);
}

function frmod_helpers_work_812(fr_x) {
  return frmod_helpers_work_813(fr_x);
}

function frmod_helpers_work_813(fr_x) {
  return frmod_helpers_work_814(fr_x);
}

function frmod_helpers_work_814(fr_x) {
  return frmod_helpers_work_815(fr_x);
}

function frmod_helpers_work_815(fr_x) {
  return frmod_helpers_work_816(fr_x);
}

function frmod_helpers_work_816(fr_x) {
  return frmod_helpers_work_817(fr_x);
}

function frmod_helpers_work_817(fr_x) {
  return frmod_helpers_work_818(fr_x);
}

function frmod_helpers_work_818(fr_x) {
  return frmod_helpers_work_819(fr_x);
}

function frmod_helpers_work_819(fr_x) {
  return frmod_helpers_work_820(fr_x);
}

function frmod_helpers_work_820(fr_x) {
  return frmod_helpers_work_821(fr_x);
}

function frmod_helpers_work_821(fr_x) {
  return frmod_helpers_work_822(fr_x);
}

function frmod_helpers_work_822(fr_x) {
  return frmod_helpers_work_823(fr_x);
}

function frmod_helpers_work_823(fr_x) {
  return frmod_helpers_work_824(fr_x);
}

function frmod_helpers_work_824(fr_x) {
  return frmod_helpers_work_825(fr_x);
}

function frmod_helpers_work_825(fr_x) {
  return frmod_helpers_work_826(fr_x);
}

function frmod_helpers_work_826(fr_x) {
  return frmod_helpers_work_827(fr_x);
}

function frmod_helpers_work_827(fr_x) {
  return frmod_helpers_work_828(fr_x);
}

function frmod_helpers_work_828(fr_x) {
  return frmod_helpers_work_829(fr_x);
}

function frmod_helpers_work_829(fr_x) {
  return frmod_helpers_work_830(fr_x);
}

function frmod_helpers_work_830(fr_x) {
  return frmod_helpers_work_831(fr_x);
}

function frmod_helpers_work_831(fr_x) {
  return frmod_helpers_work_832(fr_x);
}

function frmod_helpers_work_832(fr_x) {
  return frmod_helpers_work_833(fr_x);
}

function frmod_helpers_work_833(fr_x) {
  return frmod_helpers_work_834(fr_x);
}

function frmod_helpers_work_834(fr_x) {
  return frmod_helpers_work_835(fr_x);
}

function frmod_helpers_work_835(fr_x) {
  return frmod_helpers_work_836(fr_x);
}

function frmod_helpers_work_836(fr_x) {
  return frmod_helpers_work_837(fr_x);
}

function frmod_helpers_work_837(fr_x) {
  return frmod_helpers_work_838(fr_x);
}

function frmod_helpers_work_838(fr_x) {
  return frmod_helpers_work_839(fr_x);
}

function frmod_helpers_work_839(fr_x) {
  return frmod_helpers_work_840(fr_x);
}

function frmod_helpers_work_840(fr_x) {
  return frmod_helpers_work_841(fr_x);
}

function frmod_helpers_work_841(fr_x) {
  return frmod_helpers_work_842(fr_x);
}

function frmod_helpers_work_842(fr_x) {
  return frmod_helpers_work_843(fr_x);
}

function frmod_helpers_work_843(fr_x) {
  return frmod_helpers_work_844(fr_x);
}

function frmod_helpers_work_844(fr_x) {
  return frmod_helpers_work_845(fr_x);
}

function frmod_helpers_work_845(fr_x) {
  return frmod_helpers_work_846(fr_x);
}

function frmod_helpers_work_846(fr_x) {
  return frmod_helpers_work_847(fr_x);
}

function frmod_helpers_work_847(fr_x) {
  return frmod_helpers_work_848(fr_x);
}

function frmod_helpers_work_848(fr_x) {
  return frmod_helpers_work_849(fr_x);
}

function frmod_helpers_work_849(fr_x) {
  return frmod_helpers_work_850(fr_x);
}

function frmod_helpers_work_850(fr_x) {
  return frmod_helpers_work_851(fr_x);
}

function frmod_helpers_work_851(fr_x) {
  return frmod_helpers_work_852(fr_x);
}

function frmod_helpers_work_852(fr_x) {
  return frmod_helpers_work_853(fr_x);
}

function frmod_helpers_work_853(fr_x) {
  return frmod_helpers_work_854(fr_x);
}

function frmod_helpers_work_854(fr_x) {
  return frmod_helpers_work_855(fr_x);
}

function frmod_helpers_work_855(fr_x) {
  return frmod_helpers_work_856(fr_x);
}

function frmod_helpers_work_856(fr_x) {
  return frmod_helpers_work_857(fr_x);
}

function frmod_helpers_work_857(fr_x) {
  return frmod_helpers_work_858(fr_x);
}

function frmod_helpers_work_858(fr_x) {
  return frmod_helpers_work_859(fr_x);
}

function frmod_helpers_work_859(fr_x) {
  return frmod_helpers_work_860(fr_x);
}

function frmod_helpers_work_860(fr_x) {
  return frmod_helpers_work_861(fr_x);
}

function frmod_helpers_work_861(fr_x) {
  return frmod_helpers_work_862(fr_x);
}

function frmod_helpers_work_862(fr_x) {
  return frmod_helpers_work_863(fr_x);
}

function frmod_helpers_work_863(fr_x) {
  return frmod_helpers_work_864(fr_x);
}

function frmod_helpers_work_864(fr_x) {
  return frmod_helpers_work_865(fr_x);
}

function frmod_helpers_work_865(fr_x) {
  return frmod_helpers_work_866(fr_x);
}

function frmod_helpers_work_866(fr_x) {
  return frmod_helpers_work_867(fr_x);
}

function frmod_helpers_work_867(fr_x) {
  return frmod_helpers_work_868(fr_x);
}

function frmod_helpers_work_868(fr_x) {
  return frmod_helpers_work_869(fr_x);
}

function frmod_helpers_work_869(fr_x) {
  return frmod_helpers_work_870(fr_x);
}

function frmod_helpers_work_870(fr_x) {
  return frmod_helpers_work_871(fr_x);
}

function frmod_helpers_work_871(fr_x) {
  return frmod_helpers_work_872(fr_x);
}

function frmod_helpers_work_872(fr_x) {
  return frmod_helpers_work_873(fr_x);
}

function frmod_helpers_work_873(fr_x) {
  return frmod_helpers_work_874(fr_x);
}

function frmod_helpers_work_874(fr_x) {
  return frmod_helpers_work_875(fr_x);
}

function frmod_helpers_work_875(fr_x) {
  return frmod_helpers_work_876(fr_x);
}

function frmod_helpers_work_876(fr_x) {
  return frmod_helpers_work_877(fr_x);
}

function frmod_helpers_work_877(fr_x) {
  return frmod_helpers_work_878(fr_x);
}

function frmod_helpers_work_878(fr_x) {
  return frmod_helpers_work_879(fr_x);
}

function frmod_helpers_work_879(fr_x) {
  return frmod_helpers_work_880(fr_x);
}

function frmod_helpers_work_880(fr_x) {
  return frmod_helpers_work_881(fr_x);
}

function frmod_helpers_work_881(fr_x) {
  return frmod_helpers_work_882(fr_x);
}

function frmod_helpers_work_882(fr_x) {
  return frmod_helpers_work_883(fr_x);
}

function frmod_helpers_work_883(fr_x) {
  return frmod_helpers_work_884(fr_x);
}

function frmod_helpers_work_884(fr_x) {
  return frmod_helpers_work_885(fr_x);
}

function frmod_helpers_work_885(fr_x) {
  return frmod_helpers_work_886(fr_x);
}

function frmod_helpers_work_886(fr_x) {
  return frmod_helpers_work_887(fr_x);
}

function frmod_helpers_work_887(fr_x) {
  return frmod_helpers_work_888(fr_x);
}

function frmod_helpers_work_888(fr_x) {
  return frmod_helpers_work_889(fr_x);
}

function frmod_helpers_work_889(fr_x) {
  return frmod_helpers_work_890(fr_x);
}

function frmod_helpers_work_890(fr_x) {
  return frmod_helpers_work_891(fr_x);
}

function frmod_helpers_work_891(fr_x) {
  return frmod_helpers_work_892(fr_x);
}

function frmod_helpers_work_892(fr_x) {
  return frmod_helpers_work_893(fr_x);
}

function frmod_helpers_work_893(fr_x) {
  return frmod_helpers_work_894(fr_x);
}

function frmod_helpers_work_894(fr_x) {
  return frmod_helpers_work_895(fr_x);
}

function frmod_helpers_work_895(fr_x) {
  return frmod_helpers_work_896(fr_x);
}

function frmod_helpers_work_896(fr_x) {
  return frmod_helpers_work_897(fr_x);
}

function frmod_helpers_work_897(fr_x) {
  return frmod_helpers_work_898(fr_x);
}

function frmod_helpers_work_898(fr_x) {
  return frmod_helpers_work_899(fr_x);
}

function frmod_helpers_work_899(fr_x) {
  return frmod_helpers_work_900(fr_x);
}

function frmod_helpers_work_900(fr_x) {
  return frmod_helpers_work_901(fr_x);
}

function frmod_helpers_work_901(fr_x) {
  return frmod_helpers_work_902(fr_x);
}

function frmod_helpers_work_902(fr_x) {
  return frmod_helpers_work_903(fr_x);
}

function frmod_helpers_work_903(fr_x) {
  return frmod_helpers_work_904(fr_x);
}

function frmod_helpers_work_904(fr_x) {
  return frmod_helpers_work_905(fr_x);
}

function frmod_helpers_work_905(fr_x) {
  return frmod_helpers_work_906(fr_x);
}

function frmod_helpers_work_906(fr_x) {
  return frmod_helpers_work_907(fr_x);
}

function frmod_helpers_work_907(fr_x) {
  return frmod_helpers_work_908(fr_x);
}

function frmod_helpers_work_908(fr_x) {
  return frmod_helpers_work_909(fr_x);
}

function frmod_helpers_work_909(fr_x) {
  return frmod_helpers_work_910(fr_x);
}

function frmod_helpers_work_910(fr_x) {
  return frmod_helpers_work_911(fr_x);
}

function frmod_helpers_work_911(fr_x) {
  return frmod_helpers_work_912(fr_x);
}

function frmod_helpers_work_912(fr_x) {
  return frmod_helpers_work_913(fr_x);
}

function frmod_helpers_work_913(fr_x) {
  return frmod_helpers_work_914(fr_x);
}

function frmod_helpers_work_914(fr_x) {
  return frmod_helpers_work_915(fr_x);
}

function frmod_helpers_work_915(fr_x) {
  return frmod_helpers_work_916(fr_x);
}

function frmod_helpers_work_916(fr_x) {
  return frmod_helpers_work_917(fr_x);
}

function frmod_helpers_work_917(fr_x) {
  return frmod_helpers_work_918(fr_x);
}

function frmod_helpers_work_918(fr_x) {
  return frmod_helpers_work_919(fr_x);
}

function frmod_helpers_work_919(fr_x) {
  return frmod_helpers_work_920(fr_x);
}

function frmod_helpers_work_920(fr_x) {
  return frmod_helpers_work_921(fr_x);
}

function frmod_helpers_work_921(fr_x) {
  return frmod_helpers_work_922(fr_x);
}

function frmod_helpers_work_922(fr_x) {
  return frmod_helpers_work_923(fr_x);
}

function frmod_helpers_work_923(fr_x) {
  return frmod_helpers_work_924(fr_x);
}

function frmod_helpers_work_924(fr_x) {
  return frmod_helpers_work_925(fr_x);
}

function frmod_helpers_work_925(fr_x) {
  return frmod_helpers_work_926(fr_x);
}

function frmod_helpers_work_926(fr_x) {
  return frmod_helpers_work_927(fr_x);
}

function frmod_helpers_work_927(fr_x) {
  return frmod_helpers_work_928(fr_x);
}

function frmod_helpers_work_928(fr_x) {
  return frmod_helpers_work_929(fr_x);
}

function frmod_helpers_work_929(fr_x) {
  return frmod_helpers_work_930(fr_x);
}

function frmod_helpers_work_930(fr_x) {
  return frmod_helpers_work_931(fr_x);
}

function frmod_helpers_work_931(fr_x) {
  return frmod_helpers_work_932(fr_x);
}

function frmod_helpers_work_932(fr_x) {
  return frmod_helpers_work_933(fr_x);
}

function frmod_helpers_work_933(fr_x) {
  return frmod_helpers_work_934(fr_x);
}

function frmod_helpers_work_934(fr_x) {
  return frmod_helpers_work_935(fr_x);
}

function frmod_helpers_work_935(fr_x) {
  return frmod_helpers_work_936(fr_x);
}

function frmod_helpers_work_936(fr_x) {
  return frmod_helpers_work_937(fr_x);
}

function frmod_helpers_work_937(fr_x) {
  return frmod_helpers_work_938(fr_x);
}

function frmod_helpers_work_938(fr_x) {
  return frmod_helpers_work_939(fr_x);
}

function frmod_helpers_work_939(fr_x) {
  return frmod_helpers_work_940(fr_x);
}

function frmod_helpers_work_940(fr_x) {
  return frmod_helpers_work_941(fr_x);
}

function frmod_helpers_work_941(fr_x) {
  return frmod_helpers_work_942(fr_x);
}

function frmod_helpers_work_942(fr_x) {
  return frmod_helpers_work_943(fr_x);
}

function frmod_helpers_work_943(fr_x) {
  return frmod_helpers_work_944(fr_x);
}

function frmod_helpers_work_944(fr_x) {
  return frmod_helpers_work_945(fr_x);
}

function frmod_helpers_work_945(fr_x) {
  return frmod_helpers_work_946(fr_x);
}

function frmod_helpers_work_946(fr_x) {
  return frmod_helpers_work_947(fr_x);
}

function frmod_helpers_work_947(fr_x) {
  return frmod_helpers_work_948(fr_x);
}

function frmod_helpers_work_948(fr_x) {
  return frmod_helpers_work_949(fr_x);
}

function frmod_helpers_work_949(fr_x) {
  return frmod_helpers_work_950(fr_x);
}

function frmod_helpers_work_950(fr_x) {
  return frmod_helpers_work_951(fr_x);
}

function frmod_helpers_work_951(fr_x) {
  return frmod_helpers_work_952(fr_x);
}

function frmod_helpers_work_952(fr_x) {
  return frmod_helpers_work_953(fr_x);
}

function frmod_helpers_work_953(fr_x) {
  return frmod_helpers_work_954(fr_x);
}

function frmod_helpers_work_954(fr_x) {
  return frmod_helpers_work_955(fr_x);
}

function frmod_helpers_work_955(fr_x) {
  return frmod_helpers_work_956(fr_x);
}

function frmod_helpers_work_956(fr_x) {
  return frmod_helpers_work_957(fr_x);
}

function frmod_helpers_work_957(fr_x) {
  return frmod_helpers_work_958(fr_x);
}

function frmod_helpers_work_958(fr_x) {
  return frmod_helpers_work_959(fr_x);
}

function frmod_helpers_work_959(fr_x) {
  return frmod_helpers_work_960(fr_x);
}

function frmod_helpers_work_960(fr_x) {
  return frmod_helpers_work_961(fr_x);
}

function frmod_helpers_work_961(fr_x) {
  return frmod_helpers_work_962(fr_x);
}

function frmod_helpers_work_962(fr_x) {
  return frmod_helpers_work_963(fr_x);
}

function frmod_helpers_work_963(fr_x) {
  return frmod_helpers_work_964(fr_x);
}

function frmod_helpers_work_964(fr_x) {
  return frmod_helpers_work_965(fr_x);
}

function frmod_helpers_work_965(fr_x) {
  return frmod_helpers_work_966(fr_x);
}

function frmod_helpers_work_966(fr_x) {
  return frmod_helpers_work_967(fr_x);
}

function frmod_helpers_work_967(fr_x) {
  return frmod_helpers_work_968(fr_x);
}

function frmod_helpers_work_968(fr_x) {
  return frmod_helpers_work_969(fr_x);
}

function frmod_helpers_work_969(fr_x) {
  return frmod_helpers_work_970(fr_x);
}

function frmod_helpers_work_970(fr_x) {
  return frmod_helpers_work_971(fr_x);
}

function frmod_helpers_work_971(fr_x) {
  return frmod_helpers_work_972(fr_x);
}

function frmod_helpers_work_972(fr_x) {
  return frmod_helpers_work_973(fr_x);
}

function frmod_helpers_work_973(fr_x) {
  return frmod_helpers_work_974(fr_x);
}

function frmod_helpers_work_974(fr_x) {
  return frmod_helpers_work_975(fr_x);
}

function frmod_helpers_work_975(fr_x) {
  return frmod_helpers_work_976(fr_x);
}

function frmod_helpers_work_976(fr_x) {
  return frmod_helpers_work_977(fr_x);
}

function frmod_helpers_work_977(fr_x) {
  return frmod_helpers_work_978(fr_x);
}

function frmod_helpers_work_978(fr_x) {
  return frmod_helpers_work_979(fr_x);
}

function frmod_helpers_work_979(fr_x) {
  return frmod_helpers_work_980(fr_x);
}

function frmod_helpers_work_980(fr_x) {
  return frmod_helpers_work_981(fr_x);
}

function frmod_helpers_work_981(fr_x) {
  return frmod_helpers_work_982(fr_x);
}

function frmod_helpers_work_982(fr_x) {
  return frmod_helpers_work_983(fr_x);
}

function frmod_helpers_work_983(fr_x) {
  return frmod_helpers_work_984(fr_x);
}

function frmod_helpers_work_984(fr_x) {
  return frmod_helpers_work_985(fr_x);
}

function frmod_helpers_work_985(fr_x) {
  return frmod_helpers_work_986(fr_x);
}

function frmod_helpers_work_986(fr_x) {
  return frmod_helpers_work_987(fr_x);
}

function frmod_helpers_work_987(fr_x) {
  return frmod_helpers_work_988(fr_x);
}

function frmod_helpers_work_988(fr_x) {
  return frmod_helpers_work_989(fr_x);
}

function frmod_helpers_work_989(fr_x) {
  return frmod_helpers_work_990(fr_x);
}

function frmod_helpers_work_990(fr_x) {
  return frmod_helpers_work_991(fr_x);
}

function frmod_helpers_work_991(fr_x) {
  return frmod_helpers_work_992(fr_x);
}

function frmod_helpers_work_992(fr_x) {
  return frmod_helpers_work_993(fr_x);
}

function frmod_helpers_work_993(fr_x) {
  return frmod_helpers_work_994(fr_x);
}

function frmod_helpers_work_994(fr_x) {
  return frmod_helpers_work_995(fr_x);
}

function frmod_helpers_work_995(fr_x) {
  return frmod_helpers_work_996(fr_x);
}

function frmod_helpers_work_996(fr_x) {
  return frmod_helpers_work_997(fr_x);
}

function frmod_helpers_work_997(fr_x) {
  return frmod_helpers_work_998(fr_x);
}

function frmod_helpers_work_998(fr_x) {
  return frmod_helpers_work_999(fr_x);
}

function frmod_helpers_work_999(fr_x) {
  return frmod_helpers_work_0(fr_x);
}

function __forge_main() {
  return (0n);
}
__forge_main();
