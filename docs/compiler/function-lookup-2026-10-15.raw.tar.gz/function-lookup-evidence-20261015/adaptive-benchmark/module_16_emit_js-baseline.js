"use strict";
const __forge=(()=>{
const wrap=v=>BigInt.asIntN(64,v),numeric=v=>typeof v==='boolean'?BigInt(v):v;
const arithmetic=(a,b,op)=>{a=numeric(a);b=numeric(b);if(typeof a==='bigint'&&typeof b==='bigint'){if((op==='div'||op==='mod')&&(b===0n||(a===-9223372036854775808n&&b===-1n)))throw new RangeError('Forge integer division');return wrap(op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b);}a=Number(a);b=Number(b);return op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b;};
const bytes=s=>new TextEncoder().encode(s),decode=b=>new TextDecoder('utf-8',{fatal:true}).decode(b);
const eq=(a,b)=>{a=numeric(a);b=numeric(b);return typeof a==='number'&&typeof b==='bigint'||typeof a==='bigint'&&typeof b==='number'?Number(a)===Number(b):a===b;},index=(s,n)=>{if(typeof s!=='string')return s[Number(n)];const b=bytes(s),j=Number(n);return j<0||j>=b.length?-1n:BigInt(b[j]);},i=v=>BigInt(v);
const cbytes=s=>{s=s==null?'':s;const end=s.indexOf(String.fromCharCode(0));return bytes(end<0?s:s.slice(0,end));};
const handles=new Map();let next=1n;const store=v=>{const h=next++;handles.set(h,v);return h;};
const view=h=>handles.get(h),builder=h=>{const b=handles.get(h);return b&&b.kind==='builder'?b:null;};
const reserve=(b,n)=>{if(n<=b.data.length)return;let cap=Math.max(64,b.data.length);while(cap<n)cap*=2;const d=new Uint8Array(cap);d.set(b.data.subarray(0,b.len));b.data=d;};
const range=(v,a,n)=>{if(!v||v.kind!=='view'||a<0n||n<0n)return null;const size=BigInt(v.data.length),from=a<size?a:size,left=size-from;return [Number(from),Number(n<left?n:left)];};
const appendBytes=(h,d)=>{const b=builder(h);if(!b)return 0n;reserve(b,b.len+d.length);b.data.set(d,b.len);b.len+=d.length;return h;};
return {add:(a,b)=>typeof a==='string'&&typeof b==='string'?a+b:arithmetic(a,b,'add'),sub:(a,b)=>arithmetic(a,b,'sub'),mul:(a,b)=>arithmetic(a,b,'mul'),div:(a,b)=>arithmetic(a,b,'div'),mod:(a,b)=>arithmetic(a,b,'mod'),eq,ne:(a,b)=>!eq(a,b),lt:(a,b)=>a<b,le:(a,b)=>a<=b,gt:(a,b)=>a>b,ge:(a,b)=>a>=b,index,println:(...v)=>console.log(v.map(x=>typeof x==='boolean'?(x?'1':'0'):String(x)).join('')),
fr_str_len:s=>i(bytes(s).length),fr_str_concat:(a,b)=>a+b,fr_str_eq:(a,b)=>i(a===b),fr_str_sub:(s,a,n)=>{if(a<0n||n<0n)return null;return decode(bytes(s).slice(Number(a),Number(a+n)));},fr_str_contains:(s,x)=>i(s.includes(x)),fr_str_trim:s=>s.trim(),fr_str_char_at:index,fr_str_append:(s,c)=>{if(c<0n||c>127n)throw new RangeError('JavaScript strings require valid UTF-8');return s+String.fromCharCode(Number(c));},fr_str_append_str:(s,t)=>s+t,fr_str_from_int:String,fr_str_arena_reset:()=>{handles.clear();return 0n;},
fr_str_view:s=>store({kind:'view',data:cbytes(s)}),fr_str_view_len:h=>{const v=view(h);return i(v&&v.kind==='view'?v.data.length:0);},
fr_str_view_at:(h,n)=>{const v=view(h);return !v||v.kind!=='view'||n<0n||n>=BigInt(v.data.length)?-1n:BigInt(v.data[Number(n)]);},
fr_str_view_sub:(h,a,n)=>{const v=view(h),r=range(v,a,n);return r?decode(v.data.subarray(r[0],r[0]+r[1])):null;},
fr_str_view_matches:(h,a,s)=>{const v=view(h);if(!v||v.kind!=='view'||s==null||a<0n||a>BigInt(v.data.length))return 0n;const d=cbytes(s),from=Number(a);if(d.length>v.data.length-from)return 0n;for(let j=0;j<d.length;j++)if(v.data[from+j]!==d[j])return 0n;return 1n;},
fr_str_view_append_byte:(h,c)=>{const v=view(h);if(!v||v.kind!=='view')return 0n;return store({kind:'view',data:cbytes(decode(v.data)+String.fromCharCode(Number(c)))});},
fr_str_builder:()=>store({kind:'builder',data:new Uint8Array(0),len:0}),fr_str_builder_with_capacity:n=>{if(n<0n||n>BigInt(Number.MAX_SAFE_INTEGER))return 0n;try{return store({kind:'builder',data:new Uint8Array(Number(n)),len:0});}catch{return 0n;}},fr_str_builder_append:(h,s)=>appendBytes(h,cbytes(s)),
fr_str_builder_append_view:(h,vh,a,n)=>{const v=view(vh),r=range(v,a,n);return r?appendBytes(h,v.data.subarray(r[0],r[0]+r[1])):0n;},
fr_str_builder_char:(h,c)=>{const b=builder(h);if(!b||c<=0n||c>255n)return 0n;reserve(b,b.len+1);b.data[b.len++]=Number(c);return h;},
fr_str_builder_finish:h=>{const b=builder(h);return b?decode(b.data.subarray(0,b.len)):null;},fr_str_builder_finish_take:h=>{const b=builder(h);if(!b)return null;const s=decode(b.data.subarray(0,b.len));b.data=new Uint8Array(0);b.len=0;return s;},
fr_abs_i:x=>x<0n?-x:x,fr_abs_f:Math.abs,fr_min_i:(a,b)=>a<b?a:b,fr_max_i:(a,b)=>a>b?a:b,fr_clamp_i:(x,a,b)=>x<a?a:x>b?b:x,fr_pow_i:(a,b)=>{if(b<0n)return 0n;let r=1n;while(b>0n){if(b&1n)r=wrap(r*a);a=wrap(a*a);b>>=1n;}return r;},fr_time_now_ms:()=>i(Date.now()),
fr_json_get_string:(s,k)=>{const v=JSON.parse(s)[k];return typeof v==='string'?v:'';},fr_json_get_int:(s,k)=>{const v=JSON.parse(s)[k];if(!Number.isSafeInteger(v))throw new RangeError('Use the lossless browser JSON module');return i(v);},fr_json_stringify_str:(k,v)=>JSON.stringify({[k]:v}),fr_json_stringify_int:(k,v)=>'{'+JSON.stringify(k)+':'+String(v)+'}'};})();
function frmod_helpers_work_0(fr_x) {
  return frmod_helpers_work_1(fr_x);
}

function frmod_helpers_work_1(fr_x) {
  return frmod_helpers_work_2(fr_x);
}

function frmod_helpers_work_2(fr_x) {
  return frmod_helpers_work_3(fr_x);
}

function frmod_helpers_work_3(fr_x) {
  return frmod_helpers_work_4(fr_x);
}

function frmod_helpers_work_4(fr_x) {
  return frmod_helpers_work_5(fr_x);
}

function frmod_helpers_work_5(fr_x) {
  return frmod_helpers_work_6(fr_x);
}

function frmod_helpers_work_6(fr_x) {
  return frmod_helpers_work_7(fr_x);
}

function frmod_helpers_work_7(fr_x) {
  return frmod_helpers_work_8(fr_x);
}

function frmod_helpers_work_8(fr_x) {
  return frmod_helpers_work_9(fr_x);
}

function frmod_helpers_work_9(fr_x) {
  return frmod_helpers_work_10(fr_x);
}

function frmod_helpers_work_10(fr_x) {
  return frmod_helpers_work_11(fr_x);
}

function frmod_helpers_work_11(fr_x) {
  return frmod_helpers_work_12(fr_x);
}

function frmod_helpers_work_12(fr_x) {
  return frmod_helpers_work_13(fr_x);
}

function frmod_helpers_work_13(fr_x) {
  return frmod_helpers_work_14(fr_x);
}

function frmod_helpers_work_14(fr_x) {
  return frmod_helpers_work_15(fr_x);
}

function frmod_helpers_work_15(fr_x) {
  return frmod_helpers_work_0(fr_x);
}

function __forge_main() {
  return (0n);
}
__forge_main();
