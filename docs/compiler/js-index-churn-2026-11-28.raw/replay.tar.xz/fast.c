#include "codegen.h"
#include "mod_registry.h"
#include "function_index.h"
#include "local_index.h"
#include <inttypes.h>
#include <string.h>

typedef struct {
  FILE *out;
  Program *prog;
  ForgeStr module;
  unsigned indent;
  unsigned match_id;
  enum { OUTSIDE_LOOP, LOOP_NO_INDEX, LOOP_HAS_INDEX } loop_index;
  ForgeStr *locals;
  size_t local_capacity;
  ForgeLocalIndex local_index;
  ForgeFunctionIndex *module_functions;
} JS;
static void expression(JS *g, Expr *e);
static void statements(JS *g, Stmt *s);
static void pad(JS *g) {
  for (unsigned i = 0; i < g->indent; i++)
    fputs("  ", g->out);
}
static FnDecl *module_fn(JS *g, ForgeStr module, ForgeStr name) {
  Program *p = g->prog;
  for (size_t i = 0; i < p->module_count; i++)
    if (forge_str_eq(p->modules[i].name, module)) {
      FnDecl *function = forge_function_index_get(&g->module_functions[i], name);
      if (function) return function;
    }
  return NULL;
}
static bool local(JS *g, ForgeStr name_) {
  return forge_local_find(&g->local_index, g->locals, g->local_index.count,
                          sizeof(*g->locals), name_) != SIZE_MAX;
}
static void add_local(JS *g, ForgeStr name_) {
  /* Only source module functions can require a different emitted name. */
  if (!g->prog->module_count) return;
  size_t count = g->local_index.count;
  g->locals = forge_array_reserve(g->locals, count, &g->local_capacity,
                                  sizeof(*g->locals), 16);
  g->locals[count] = name_;
  forge_local_push(&g->local_index, name_);
}
static void name(FILE *out, ForgeStr value) {
  fprintf(out, "fr_%.*s", (int)value.len, value.data);
}
static void module_name(FILE *out, ForgeStr module, ForgeStr value) {
  char symbol[256];
  forge_mod_mangle(symbol, sizeof(symbol), module, value);
  fputs(symbol, out);
}
static void quote(FILE *out, ForgeStr value) {
  fputc('"', out);
  for (size_t i = 0; i < value.len; i++) {
    unsigned char c = (unsigned char)value.data[i];
    if (c == '"' || c == '\\') {
      fputc('\\', out);
      fputc(c, out);
    } else if (c < 32)
      fprintf(out, "\\u%04x", c);
    else
      fputc(c, out);
  }
  fputc('"', out);
}
static void arguments(JS *g, Expr **args, size_t count, bool with_cache) {
  fputc('(', g->out);
  if (with_cache) fputs("__byteCache||(__byteCache={text:null,data:null})", g->out);
  for (size_t i = 0; i < count; i++) {
    if (i || with_cache)
      fputc(',', g->out);
    expression(g, args[i]);
  }
  fputc(')', g->out);
}
static void index_call(JS *g, Expr **args, size_t count) {
  bool in_loop = g->loop_index != OUTSIDE_LOOP;
  if (in_loop) g->loop_index = LOOP_HAS_INDEX;
  fputs(in_loop ? "__forge.loopIndex" : "__forge.index", g->out);
  arguments(g, args, count, in_loop);
}
static int supported_standard(const char *name_) {
  static const char *supported[] = {"fr_str_len",
                                    "fr_str_concat",
                                    "fr_str_eq",
                                    "fr_str_sub",
                                    "fr_str_contains",
                                    "fr_str_trim",
                                    "fr_str_char_at",
                                    "fr_str_append",
                                    "fr_str_append_str",
                                    "fr_str_from_int",
                                    "fr_str_arena_reset",
                                    "fr_str_view",
                                    "fr_str_view_len",
                                    "fr_str_view_at",
                                    "fr_str_view_sub",
                                    "fr_str_view_matches",
                                    "fr_str_view_append_byte",
                                    "fr_str_builder",
                                    "fr_str_builder_with_capacity",
                                    "fr_str_builder_append",
                                    "fr_str_builder_append_view",
                                    "fr_str_builder_char",
                                    "fr_str_builder_finish",
                                    "fr_str_builder_finish_take",

                                    "fr_abs_i",
                                    "fr_abs_f",
                                    "fr_min_i",
                                    "fr_max_i",
                                    "fr_clamp_i",
                                    "fr_pow_i",
                                    "fr_time_now_ms",
                                    "fr_json_get_string",
                                    "fr_json_get_int",
                                    "fr_json_stringify_str",
                                    "fr_json_stringify_int",
                                    NULL};
  for (size_t i = 0; supported[i]; i++)
    if (!strcmp(supported[i], name_))
      return 1;
  return 0;
}
static void expression(JS *g, Expr *e) {
  if (!e) {
    fputs("undefined", g->out);
    return;
  }
  switch (e->kind) {
  case EXPR_INT:
    fprintf(g->out, "(%" PRId64 "n)", e->as.int_val);
    break;
  case EXPR_FLOAT:
    fprintf(g->out, "(%.17g)", e->as.float_val);
    break;
  case EXPR_BOOL:
    fputs(e->as.bool_val ? "true" : "false", g->out);
    break;
  case EXPR_STRING:
    quote(g->out, e->as.string_val);
    break;
  case EXPR_IDENT:
    if (g->module.len && !local(g, e->as.ident) &&
        module_fn(g, g->module, e->as.ident))
      module_name(g->out, g->module, e->as.ident);
    else
      name(g->out, e->as.ident);
    break;
  case EXPR_BINARY: {
    BinOp op = e->as.binary.op;
    if (op == BIN_AND || op == BIN_OR) {
      fputs("(Boolean(", g->out);
      expression(g, e->as.binary.left);
      fputs(op == BIN_AND ? ") && Boolean(" : ") || Boolean(", g->out);
      expression(g, e->as.binary.right);
      fputs("))", g->out);
    } else {
      static const char *ops[] = {"add", "sub", "mul", "div", "mod", "eq",
                                  "ne",  "lt",  "le",  "gt",  "ge"};
      fprintf(g->out, "__forge.%s(", ops[op]);
      expression(g, e->as.binary.left);
      fputc(',', g->out);
      expression(g, e->as.binary.right);
      fputc(')', g->out);
    }
    break;
  }
  case EXPR_CALL: {
    ForgeStr fn = e->as.call.name;
    const char *standard =
        forge_std_c_name(fn, g->prog->imports, g->prog->import_count);
    if (forge_str_eq(fn, forge_str("println")))
      fputs("__forge.println", g->out);
    else if (standard) {
      if (!strcmp(standard, "fr_str_char_at")) {
        index_call(g, e->as.call.args, e->as.call.arg_count);
        break;
      }
      if (!supported_standard(standard)) {
        fprintf(
            stderr,
            "forge: JavaScript backend does not support native function '%s'\n",
            standard);
        exit(1);
      }
      fprintf(g->out, "__forge.%s", standard);
    } else if (g->module.len && !local(g, fn) &&
               module_fn(g, g->module, fn))
      module_name(g->out, g->module, fn);
    else
      name(g->out, fn);
    arguments(g, e->as.call.args, e->as.call.arg_count, false);
    break;
  }
  case EXPR_QUAL_CALL:
    if (!module_fn(g, e->as.qual_call.module, e->as.qual_call.name)) {
      fprintf(stderr, "forge: JavaScript backend requires a source module for "
                      "qualified calls\n");
      exit(1);
    }
    module_name(g->out, e->as.qual_call.module, e->as.qual_call.name);
    arguments(g, e->as.qual_call.args, e->as.qual_call.arg_count, false);
    break;
  case EXPR_INDEX: {
    Expr *args[] = {e->as.index.base, e->as.index.index};
    index_call(g, args, 2);
    break;
  }
  case EXPR_FIELD:
    if (e->as.field.base->kind == EXPR_IDENT &&
        !local(g, e->as.field.base->as.ident) &&
        module_fn(g, e->as.field.base->as.ident, e->as.field.field))
      module_name(g->out, e->as.field.base->as.ident, e->as.field.field);
    else {
      expression(g, e->as.field.base);
      fputc('[', g->out);
      quote(g->out, e->as.field.field);
      fputc(']', g->out);
    }
    break;
  case EXPR_MOVE:
  case EXPR_RECV:
    forge_die("ownership moves and coroutine receive are unavailable in "
              "JavaScript backend");
  }
}
static void block(JS *g, Block *b) {
  size_t saved_locals = g->local_index.count;
  fputs("{\n", g->out);
  g->indent++;
  statements(g, b ? b->first : NULL);
  forge_local_truncate(&g->local_index, saved_locals);
  g->indent--;
  pad(g);
  fputc('}', g->out);
}
static void inline_stmt(JS *g, Stmt *s) {
  if (!s)
    return;
  if (s->kind == STMT_LET) {
    if (s->as.let.owned_)
      forge_die("owned native resources are unavailable in JavaScript backend");
    fputs("let ", g->out);
    name(g->out, s->as.let.name);
    fputc('=', g->out);
    if (s->as.let.init)
      expression(g, s->as.let.init);
    else
      fputs(s->as.let.type.kind == TY_STRING  ? "\"\""
            : s->as.let.type.kind == TY_BOOL  ? "false"
            : s->as.let.type.kind == TY_FLOAT ? "0"
                                              : "0n",
            g->out);
    add_local(g, s->as.let.name);
  } else if (s->kind == STMT_ASSIGN) {
    name(g->out, s->as.assign.name);
    fputc('=', g->out);
    expression(g, s->as.assign.value);
  } else
    forge_die("unsupported for-loop statement in JavaScript backend");
}
static void statements(JS *g, Stmt *s) {
  for (; s; s = s->next) {
    bool outer_loop = g->loop_index == OUTSIDE_LOOP &&
                      (s->kind == STMT_WHILE || s->kind == STMT_FOR);
    if (outer_loop) g->loop_index = LOOP_NO_INDEX;
    pad(g);
    switch (s->kind) {
    case STMT_LET:
    case STMT_ASSIGN:
      inline_stmt(g, s);
      fputs(";\n", g->out);
      break;
    case STMT_EXPR:
      expression(g, s->as.expr);
      fputs(";\n", g->out);
      break;
    case STMT_RETURN:
      fputs("return ", g->out);
      expression(g, s->as.ret);
      fputs(";\n", g->out);
      break;
    case STMT_IF:
      fputs("if (", g->out);
      expression(g, s->as.if_stmt.cond);
      fputs(") ", g->out);
      block(g, s->as.if_stmt.then_br);
      if (s->as.if_stmt.else_br) {
        fputs(" else ", g->out);
        block(g, s->as.if_stmt.else_br);
      }
      fputc('\n', g->out);
      break;
    case STMT_WHILE:
      fputs("while (", g->out);
      expression(g, s->as.while_stmt.cond);
      fputs(") ", g->out);
      block(g, s->as.while_stmt.body);
      fputc('\n', g->out);
      break;
    case STMT_FOR: {
      size_t saved_locals = g->local_index.count;
      fputs("for (", g->out);
      inline_stmt(g, s->as.for_stmt.init);
      fputc(';', g->out);
      expression(g, s->as.for_stmt.cond);
      fputc(';', g->out);
      inline_stmt(g, s->as.for_stmt.step);
      fputs(") ", g->out);
      block(g, s->as.for_stmt.body);
      forge_local_truncate(&g->local_index, saved_locals);
      fputc('\n', g->out);
      break;
    }
    case STMT_BREAK:
      fputs("break;\n", g->out);
      break;
    case STMT_CONTINUE:
      fputs("continue;\n", g->out);
      break;
    case STMT_BLOCK:
      block(g, s->as.block);
      fputc('\n', g->out);
      break;
    case STMT_MATCH: {
      unsigned id = g->match_id++;
      fprintf(g->out, "{ const __match%u=", id);
      expression(g, s->as.match_stmt.scrutinee);
      fputs(";\n", g->out);
      g->indent++;
      int first = 1;
      for (MatchArm *a = s->as.match_stmt.arms; a; a = a->next) {
        pad(g);
        if (!first)
          fputs("else ", g->out);
        if (!a->wildcard)
          fprintf(g->out, "if (__forge.eq(__match%u,(%" PRId64 "n))) ", id,
                  a->int_pat);
        else if (first)
          fputs("if (true) ", g->out);
        block(g, a->body);
        fputc('\n', g->out);
        first = 0;
        if (a->wildcard)
          break;
      }
      g->indent--;
      pad(g);
      fputs("}\n", g->out);
      break;
    }
    default:
      forge_die("process, coroutine and await statements are unavailable in "
                "JavaScript backend");
    }
    if (outer_loop) {
      if (g->loop_index == LOOP_HAS_INDEX) {
        // JS hoists the declaration. Clear the borrowed key and its bytes on
        // loop exit; a return discards the whole activation instead.
        pad(g);
        fputs("var __byteCache = null;\n", g->out);
      }
      g->loop_index = OUTSIDE_LOOP;
    }
  }
}
static void function(JS *g, FnDecl *fn) {
  forge_local_truncate(&g->local_index, 0);
  for (Param *p = fn->params; p; p = p->next)
    add_local(g, p->name);
  fputs("function ", g->out);
  if (g->module.len)
    module_name(g->out, g->module, fn->name);
  else
    name(g->out, fn->name);
  fputc('(', g->out);
  for (Param *p = fn->params; p; p = p->next) {
    if (p != fn->params)
      fputc(',', g->out);
    name(g->out, p->name);
  }
  fputs(") ", g->out);
  if (fn->is_extern) {
    fputs("{ const f=globalThis.ForgeNative?.[", g->out);
    quote(g->out, fn->name);
    fputs("]; if(typeof f!=='function') throw new Error('Missing Forge "
          "JavaScript FFI'); return f(",
          g->out);
    for (Param *p = fn->params; p; p = p->next) {
      if (p != fn->params)
        fputc(',', g->out);
      name(g->out, p->name);
    }
    fputs("); }\n", g->out);
  } else {
    block(g, &fn->body);
    fputs("\n\n", g->out);
  }
}
void codegen_emit_js(Program *prog, FILE *out) {
  if (prog->process_count || prog->supervisor_count || prog->library.present ||
      prog->struct_count)
    forge_die(
        "JavaScript backend supports functions, enums, source modules and "
        "native main; native process/struct declarations are unavailable");
  JS g = {.out = out, .prog = prog};
  if (prog->module_count)
    g.module_functions = forge_calloc_array(prog->module_count, sizeof(*g.module_functions));
  for (size_t i = 0; i < prog->module_count; i++)
    g.module_functions[i] = forge_function_index_build(prog->modules[i].functions, prog->modules[i].fn_count);
  fputs(
      "\"use strict\";\nconst __forge=(()=>{\n"
      "const wrap=v=>BigInt.asIntN(64,v),numeric=v=>typeof "
      "v==='boolean'?BigInt(v):v;\n"
      "const arithmetic=(a,b,op)=>{a=numeric(a);b=numeric(b);if(typeof "
      "a==='bigint'&&typeof "
      "b==='bigint'){if((op==='div'||op==='mod')&&(b===0n||(a===-"
      "9223372036854775808n&&b===-1n)))throw new RangeError('Forge integer "
      "division');return "
      "wrap(op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/"
      "b:a%b);}a=Number(a);b=Number(b);return "
      "op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b;};\n"
      "const bytes=s=>new TextEncoder().encode(s),decode=b=>new "
      "TextDecoder('utf-8',{fatal:true}).decode(b);\n"
      "const eq=(a,b)=>{a=numeric(a);b=numeric(b);return typeof "
      "a==='number'&&typeof b==='bigint'||typeof a==='bigint'&&typeof "
      "b==='number'?Number(a)===Number(b):a===b;},i=v=>BigInt(v);\n"
      "const cbytes=s=>{s=s==null?'':s;const end=s.indexOf(String.fromCharCode(0));return bytes(end<0?s:s.slice(0,end));};\n"
      "const shortString=s=>typeof s==='string'&&s.length<=64;\n"
      "const beforeNul=s=>{const end=s.indexOf('\\0');return end<0?s:s.slice(0,end);};\n"
      "let shortEncoder,shortBuffer;\n"
      "const encodePrefix=s=>{\n"
      "  if(!shortEncoder)shortEncoder=new TextEncoder();\n"
      "  if(!shortEncoder.encodeInto)return -1;\n"
      // UTF-8 needs at most three bytes per UTF-16 code unit (four per pair).
      "  if(!shortBuffer)shortBuffer=new Uint8Array(3*64);\n"
      "  return shortEncoder.encodeInto(s,shortBuffer).written;};\n"
      "let substringDecoder;\n"
      "const decodeSubstring=part=>{\n"
      "  if(!substringDecoder)substringDecoder=new TextDecoder('utf-8',{fatal:true});\n"
      "  return substringDecoder.decode(part);};\n"
      "let stringBuffer;\n"
      "const encodedLength=s=>{\n"
      // Reserve the complete worst-case encoding before reading .written.
      "  if(typeof s==='string'&&3*s.length<=8192){\n"
      "    if(!shortEncoder)shortEncoder=new TextEncoder();\n"
      "    if(shortEncoder.encodeInto){\n"
      "      if(!stringBuffer||stringBuffer.length<8192)stringBuffer=new Uint8Array(8192);\n"
      "      return shortEncoder.encodeInto(s,stringBuffer).written;\n"
      "    }\n"
      "  }\n"
      "  return bytes(s).length;};\n"
      "const longSubstring=(s,a,end)=>{\n"
      // Three spare bytes cover a scalar that won't fit. The full encoding,
      // when smaller, needs at most three bytes per UTF-16 code unit.
      "  const capacity=Math.min(3*s.length,end+3);\n"
      "  if(capacity<=196608){\n"
      "    if(!shortEncoder)shortEncoder=new TextEncoder();\n"
      "    if(shortEncoder.encodeInto){\n"
      "      if(!stringBuffer||stringBuffer.length<capacity)\n"
      "        stringBuffer=new Uint8Array(Math.min(196608,Math.max(capacity,stringBuffer?2*stringBuffer.length:0)));\n"
      "      const dest=stringBuffer.length>capacity&&capacity<3*s.length?stringBuffer.subarray(0,capacity):stringBuffer;\n"
      "      const size=shortEncoder.encodeInto(s,dest).written;\n"
      "      return decodeSubstring(stringBuffer.subarray(a,Math.min(end,size)));\n"
      "    }\n"
      "  }\n"
      "  return decodeSubstring(bytes(s).subarray(a,end));};\n"
      "const substring=(s,a,n)=>{\n"
      "  if(a<0n||n<0n)return null;\n"
      "  if(typeof s==='string'&&typeof a==='bigint'&&typeof n==='bigint'){\n"
      "    if(n===0n)return '';\n"
      "    const end=a+n;\n"
      // On bounded ASCII strings each UTF-16 unit is exactly one UTF-8 byte.
      "    if(s.length<=64&&!/[^\\x00-\\x7f]/.test(s))return s.slice(Number(a),Number(end));\n"
      // An incomplete encodeInto fills at least 189 of the 192 bytes.
      "    if(s.length<=64||end<=189n){\n"
      "      const size=encodePrefix(s);\n"
      "      if(size>=0)return decodeSubstring(shortBuffer.subarray(Number(a),Math.min(Number(end),size)));\n"
      "    }\n"
      // Even three-byte scalars cannot extend beyond this starting offset.
      "    if(a>=3n*BigInt(s.length))return '';\n"
      "    return longSubstring(s,Number(a),Number(end));\n"
      "  }\n"
      "  return decodeSubstring(bytes(s).subarray(Number(a),Number(a+n)));};\n"
      "const index=(s,n)=>{\n"
      "  if(typeof s!=='string')return s[Number(n)];\n"
      "  if(typeof n==='bigint'){\n"
      "    const j=Number(n);\n"
      "    if(j<0||j>=3*s.length)return -1n;\n"
      // A 192-byte destination may leave up to three bytes unused when
      // the next scalar does not fit. Its first 189 bytes are then complete.
      "    if(s.length<=64||j<189){\n"
      "      const size=encodePrefix(s);\n"
      "      if(size>=0)return j<size?BigInt(shortBuffer[j]):-1n;\n"
      "    }\n"
      "  }\n"
      "  const b=bytes(s),j=Number(n);\n"
      "  return j<0||j>=b.length?-1n:BigInt(b[j]);};\n"
      // Keep one encoding per active outer loop. Only retain a key after a
      // read beyond the scratch prefix, with at most 192 KiB of encoded data.
      "const refillIndex=(cache,s)=>{\n"
      "  if(!cache.data)return bytes(s);\n"
      "  if(!shortEncoder)shortEncoder=new TextEncoder();\n"
      "  if(!shortEncoder.encodeInto)return bytes(s);\n"
      "  const capacity=3*s.length,backing=cache.data.buffer;\n"
      "  const dest=backing.byteLength>=capacity?new Uint8Array(backing):new Uint8Array(capacity);\n"
      "  return dest.subarray(0,shortEncoder.encodeInto(s,dest).written);};\n"
      "const cachedByte=(data,j)=>j<0||j>=data.length?-1n:BigInt(data[j]);\n"
      "const loopIndex=(cache,s,n)=>{\n"
      "  if(typeof n!=='bigint')return index(s,n);\n"
      "  const j=Number(n);\n"
      "  if(s===cache.text&&s!==null)return cachedByte(cache.data,j);\n"
      "  if(typeof s!=='string'||s.length<=64||s.length>65536||j<189||j>=3*s.length)return index(s,n);\n"
      "  cache.data=refillIndex(cache,s);cache.text=s;\n"
      "  return cachedByte(cache.data,j);};\n"
      "const handles=new Map();let next=1n;const store=v=>{const h=next++;handles.set(h,v);return h;};\n"
      "const view=h=>handles.get(h),builder=h=>{const b=handles.get(h);return b&&b.kind==='builder'?b:null;};\n"
      "const reserve=(b,n)=>{if(n<=b.data.length)return;let cap=Math.max(64,b.data.length);while(cap<n)cap*=2;const d=new Uint8Array(cap);d.set(b.data.subarray(0,b.len));b.data=d;};\n"
      "const range=(v,a,n)=>{if(!v||v.kind!=='view'||a<0n||n<0n)return null;const size=BigInt(v.data.length),from=a<size?a:size,left=size-from;return [Number(from),Number(n<left?n:left)];};\n"
      "const appendBytes=(h,d)=>{const b=builder(h);if(!b)return 0n;reserve(b,b.len+d.length);b.data.set(d,b.len);b.len+=d.length;return h;};\n"
      "return {add:(a,b)=>typeof a==='string'&&typeof "
      "b==='string'?a+b:arithmetic(a,b,'add'),sub:(a,b)=>arithmetic(a,b,'sub'),"
      "mul:(a,b)=>arithmetic(a,b,'mul'),div:(a,b)=>arithmetic(a,b,'div'),mod:("
      "a,b)=>arithmetic(a,b,'mod'),eq,ne:(a,b)=>!eq(a,b),lt:(a,b)=>a<b,le:(a,b)"
      "=>a<=b,gt:(a,b)=>a>b,ge:(a,b)=>a>=b,index,loopIndex,println:(...v)=>console.log(v."
      "map(x=>typeof x==='boolean'?(x?'1':'0'):String(x)).join('')),\n"
      "fr_str_len:s=>{const n=shortString(s)?encodePrefix(s):-1;return i(n<0?encodedLength(s):n);},\n"
      "fr_str_concat:(a,b)=>a+b,fr_str_eq:(a,"
      "b)=>i(a===b),fr_str_sub:substring,fr_str_contains:(s,x)=>"
      "i(s.includes(x)),fr_str_trim:s=>s.trim(),fr_str_char_at:index,fr_str_"
      "append:(s,c)=>{if(c<0n||c>127n)throw new RangeError('JavaScript strings "
      "require valid UTF-8');return "
      "s+String.fromCharCode(Number(c));},fr_str_append_str:(s,t)=>s+t,fr_str_"
      "from_int:String,fr_str_arena_reset:()=>{handles.clear();return 0n;},\n"
      "fr_str_view:s=>store({kind:'view',data:cbytes(s)}),fr_str_view_len:h=>{const v=view(h);return i(v&&v.kind==='view'?v.data.length:0);},\n"
      "fr_str_view_at:(h,n)=>{\n"
      "  const v=view(h);if(!v||v.kind!=='view')return -1n;\n"
      "  if(typeof n==='bigint'){\n"
      // A typed array's length is a safe JS integer. Rounding a larger index
      // when converting from BigInt cannot bring it into the valid range.
      "    const pos=Number(n);\n"
      "    return pos<0||pos>=v.data.length?-1n:BigInt(v.data[pos]);\n"
      "  }\n"
      "  return n<0n||n>=BigInt(v.data.length)?-1n:BigInt(v.data[Number(n)]);},\n"
      "fr_str_view_sub:(h,a,n)=>{const v=view(h),r=range(v,a,n);return r?decode(v.data.subarray(r[0],r[0]+r[1])):null;},\n"
      "fr_str_view_matches:(h,a,s)=>{\n"
      "  const v=view(h);\n"
      "  if(!v||v.kind!=='view'||s==null||a<0n||a>BigInt(v.data.length))return 0n;\n"
      "  let from=Number(a),needle,length;\n"
      "  if(typeof s==='string'){\n"
      "    let j=0;\n"
      "    for(;j<s.length;j++){\n"
      "      const c=s.charCodeAt(j);\n"
      "      if(c===0)return 1n;\n"
      "      if(c>127)break;\n"
      "      if(v.data[from++]!==c)return 0n;\n"
      "    }\n"
      "    if(j===s.length)return 1n;\n"
      "    s=s.slice(j);\n"
      "    if(s.length<=64){\n"
      "      s=beforeNul(s);\n"
      "      length=encodePrefix(s);\n"
      "      if(length>=0)needle=shortBuffer;\n"
      "    }\n"
      "  }\n"
      "  if(!needle){needle=cbytes(s);length=needle.length;}\n"
      "  if(length>v.data.length-from)return 0n;\n"
      "  for(let j=0;j<length;j++)if(v.data[from+j]!==needle[j])return 0n;\n"
      "  return 1n;},\n"
      "fr_str_view_append_byte:(h,c)=>{const v=view(h);if(!v||v.kind!=='view')return 0n;return store({kind:'view',data:cbytes(decode(v.data)+String.fromCharCode(Number(c)))});},\n"
      "fr_str_builder:()=>store({kind:'builder',data:new Uint8Array(0),len:0}),"
      "fr_str_builder_with_capacity:n=>{if(n<0n||n>BigInt(Number.MAX_SAFE_INTEGER))return 0n;"
      "try{return store({kind:'builder',data:new Uint8Array(Number(n)),len:0});}catch{return 0n;}},"
      "fr_str_builder_append:(h,s)=>{\n"
      "  if(shortString(s)){\n"
      "    s=beforeNul(s);\n"
      "    const n=encodePrefix(s);\n"
      "    if(n>=0)return appendBytes(h,shortBuffer.subarray(0,n));\n"
      "    return appendBytes(h,bytes(s));\n"
      "  }\n"
      "  return appendBytes(h,cbytes(s));},\n"
      "fr_str_builder_append_view:(h,vh,a,n)=>{const v=view(vh),r=range(v,a,n);return r?appendBytes(h,v.data.subarray(r[0],r[0]+r[1])):0n;},\n"
      "fr_str_builder_char:(h,c)=>{const b=builder(h);if(!b||c<=0n||c>255n)return 0n;reserve(b,b.len+1);b.data[b.len++]=Number(c);return h;},\n"
      "fr_str_builder_finish:h=>{const b=builder(h);return b?decode(b.data.subarray(0,b.len)):null;},"
      "fr_str_builder_finish_take:h=>{const b=builder(h);if(!b)return null;const s=decode(b.data.subarray(0,b.len));b.data=new Uint8Array(0);b.len=0;return s;},\n"
      "fr_abs_i:x=>x<0n?-x:x,fr_abs_f:Math.abs,fr_min_i:(a,b)=>a<b?a:b,fr_max_"
      "i:(a,b)=>a>b?a:b,fr_clamp_i:(x,a,b)=>x<a?a:x>b?b:x,fr_pow_i:(a,b)=>{if("
      "b<0n)return 0n;let "
      "r=1n;while(b>0n){if(b&1n)r=wrap(r*a);a=wrap(a*a);b>>=1n;}return "
      "r;},fr_time_now_ms:()=>i(Date.now()),\n"
      "fr_json_get_string:(s,k)=>{const v=JSON.parse(s)[k];return typeof "
      "v==='string'?v:'';},fr_json_get_int:(s,k)=>{const "
      "v=JSON.parse(s)[k];if(!Number.isSafeInteger(v))throw new "
      "RangeError('Use the lossless browser JSON module');return "
      "i(v);},fr_json_stringify_str:(k,v)=>JSON.stringify({[k]:v}),fr_json_"
      "stringify_int:(k,v)=>'{'+JSON.stringify(k)+':'+String(v)+'}'};})();\n",
      out);
  for (size_t i = 0; i < prog->const_count; i++) {
    fputs("const ", out);
    name(out, prog->consts[i].name);
    fputc('=', out);
    expression(&g, prog->consts[i].value);
    fputs(";\n", out);
  }
  for (size_t i = 0; i < prog->enum_count; i++) {
    fputs("const ", out);
    name(out, prog->enums[i].name);
    fputs("=Object.freeze({", out);
    for (EnumVariant *v = prog->enums[i].variants; v; v = v->next) {
      if (v != prog->enums[i].variants)
        fputc(',', out);
      quote(out, v->name);
      fprintf(out, ":(%" PRId64 "n)", v->value);
    }
    fputs("});\n", out);
  }
  for (size_t i = 0; i < prog->fn_count; i++)
    function(&g, &prog->functions[i]);
  for (size_t i = 0; i < prog->module_count; i++) {
    g.module = prog->modules[i].name;
    for (size_t j = 0; j < prog->modules[i].fn_count; j++)
      function(&g, &prog->modules[i].functions[j]);
  }
  g.module = forge_str("");
  forge_local_truncate(&g.local_index, 0);
  for (size_t i = 0; i < prog->native_count; i++)
    if (forge_str_eq(prog->natives[i].name, forge_str("main"))) {
      fputs("function __forge_main() ", out);
      block(&g, &prog->natives[i].body);
      fputs("\n__forge_main();\n", out);
    }
  for (size_t i = 0; i < prog->module_count; i++)
    forge_function_index_free(&g.module_functions[i]);
  free(g.module_functions);
  forge_local_free(&g.local_index);
  free(g.locals);
}
