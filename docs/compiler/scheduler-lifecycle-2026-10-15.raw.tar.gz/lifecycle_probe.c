#define _POSIX_C_SOURCE 200809L
#include "forge_runtime.h"
#include "forge/thread.h"
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static atomic_int entered,released;
static void gate(void *p){(void)p;atomic_store(&entered,1);while(!atomic_load(&released))fr_thread_yield();}
static int64_t child(int64_t x){return x;}
static void *stop(void *p){fr_scheduler_stop(p);return NULL;}
__attribute__((noinline)) static int probe(int restart){
 fr_scheduler_t *s=fr_scheduler_create(1);if(!s)return 2;
 fr_scheduler_start(s);if(fr_sched_pool_submit(s,gate,NULL))return 3;
 while(!atomic_load(&entered))fr_thread_yield();
 if(fr_sched_pool_spawn(child,7))return 4;
 fr_thread_t *t=NULL;if(fr_thread_start(&t,stop,s))return 5;
 while(fr_sched_pool_available())fr_thread_yield();
 if(restart)fr_scheduler_start(s);
 atomic_store(&released,1);fr_thread_join(t);
 if(fr_sched_pool_queued(s)!=1)return 6;
 fr_scheduler_destroy(s);return 0;
}
int main(int argc,char **argv){if(argc!=2)return 1;return probe(!strcmp(argv[1],"restart"));}
