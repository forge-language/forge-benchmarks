# Reproduce the local scheduler lifecycle candidate

Run from the extracted archive directory on Linux with GCC 13.3.0, CMake,
Python 3 and POSIX threads. Use an output directory with sufficient space.
`metadata.json` records exact source bases, binary hashes and check outcomes.
The runtime is a **local candidate**, not a changed immutable dependency pin.
The baseline already includes the preceding native-depth change; it is not
pristine runtime `dcbb1929b17c2f1d11fd367ecf80c7c87c58a274`.

## Verify retained bytes

```sh
python3 - <<'VERIFY'
from pathlib import Path
import hashlib, json
m = json.loads(Path('manifest.json').read_text())
for name, entry in m['files'].items():
    p = Path(name)
    assert p.stat().st_size == entry['bytes'], name
    assert hashlib.sha256(p.read_bytes()).hexdigest() == entry['sha256'], name
print(len(m['files']), 'files verified')
VERIFY
```

## Release runtime and deterministic regressions

```sh
export TMPDIR=/dev/shm
cmake -S source-runtime -B /dev/shm/forge-lifecycle-repro-release -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build /dev/shm/forge-lifecycle-repro-release -j2
ctest --test-dir /dev/shm/forge-lifecycle-repro-release --output-on-failure
```

All six runtime suites passed. Lifecycle gates use GNU linker wrappers, with
assertions enabled even in Release. They force both restart windows, cross-object
registration, one-time owned cleanup, borrowed-argument preservation and full,
partial, zero and mixed-execution indexed batches. See the complete source and
`baseline-mutant-checks.json` for actual counterfactual commands and failures.

Rebuild the old baseline and deliberately incomplete start-only mutant:

```sh
cmake -S baseline-source -B /dev/shm/forge-lifecycle-repro-baseline -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF
cmake --build /dev/shm/forge-lifecycle-repro-baseline -j2
cmake -S start-only-source -B /dev/shm/forge-lifecycle-repro-mutant -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF
cmake --build /dev/shm/forge-lifecycle-repro-mutant -j2
cc -O3 -std=c11 -UNDEBUG -I source-runtime/include -I source-runtime/src source-runtime/tests/lifecycle_test.c /dev/shm/forge-lifecycle-repro-baseline/lib/libforge_runtime.a -pthread -Wl,--wrap=malloc -Wl,--wrap=free -Wl,--wrap=fr_cond_wait -Wl,--wrap=fr_mutex_unlock -Wl,--wrap=fr_native_queue_try_push -o /dev/shm/lifecycle-repro-baseline
cc -O3 -std=c11 -UNDEBUG -I source-runtime/include -I source-runtime/src source-runtime/tests/lifecycle_test.c /dev/shm/forge-lifecycle-repro-mutant/lib/libforge_runtime.a -pthread -Wl,--wrap=malloc -Wl,--wrap=free -Wl,--wrap=fr_cond_wait -Wl,--wrap=fr_mutex_unlock -Wl,--wrap=fr_native_queue_try_push -o /dev/shm/lifecycle-repro-mutant
/dev/shm/lifecycle-repro-baseline
/dev/shm/lifecycle-repro-mutant
/dev/shm/lifecycle-repro-baseline owned
/dev/shm/lifecycle-repro-mutant owned
```

Those four final commands intentionally exit 1 with distinct assertions (each
command should be invoked separately if the shell stops on failure). The fixed
runtime passes. The source snapshots plus `reconstruction.json` retain byte-exact
rebuilds of both frozen runtime libraries. `patch-check.json` records that each
incremental/cumulative patch applied and matched every changed file byte for byte.
For the cumulative patch use the pristine immutable runtime base; for the
incremental patch use `baseline-source`. Both new test files are in the archive.

## Sanitizers and the original isolated leak

```sh
cmake -S source-runtime -B /dev/shm/forge-lifecycle-repro-asan -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer'
cmake --build /dev/shm/forge-lifecycle-repro-asan -j2
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --test-dir /dev/shm/forge-lifecycle-repro-asan --output-on-failure
cc -g -O1 -std=c11 -fsanitize=address,undefined -fno-omit-frame-pointer -I source-runtime/include lifecycle_probe.c /dev/shm/forge-lifecycle-repro-asan/lib/libforge_runtime.a -pthread -o /dev/shm/lifecycle-repro-leak
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 /dev/shm/lifecycle-repro-leak leak
```

The historical `preexisting-lifecycle.json` retains the old 16-byte leak. The fixed
leak binary exits zero with empty sanitizer output. Do **not** use this old
fixture's `restart` mode as a passing oracle: its gate owner synchronously calls
the now-blocking start before releasing the gate. The three-actor new lifecycle
regression is the valid fixed-order oracle.

```sh
cmake -S source-runtime -B /dev/shm/forge-lifecycle-repro-tsan -DCMAKE_BUILD_TYPE=Debug -DBUILD_TESTING=ON '-DCMAKE_C_FLAGS=-fsanitize=thread -fno-omit-frame-pointer'
cmake --build /dev/shm/forge-lifecycle-repro-tsan --target lifecycle_test -j2
/dev/shm/forge-lifecycle-repro-tsan/bin/lifecycle_test
```

TSan builds here but fails before test execution with unexpected memory mapping
(exit 66). It is unavailable, not passed. No arbitrary concurrent destroy or
callback-owned blocking lifecycle safety is claimed.

## Full local project and self-host

The archive freezes compiler build inputs and the existing local stdlib HTTP
candidate so the local override boundary is explicit. Default dependency pins
remain unchanged and do not contain these dependency edits.

```sh
cmake -S source-project -B /dev/shm/forge-lifecycle-repro-project -G Ninja -DCMAKE_BUILD_TYPE=Release -DFORGE_ENABLE_LTO=OFF -DFORGE_RUNTIME_SOURCE_DIR="$PWD/source-runtime" -DFORGE_STDLIB_SOURCE_DIR="$PWD/source-stdlib"
cmake --build /dev/shm/forge-lifecycle-repro-project -j2
ctest --test-dir /dev/shm/forge-lifecycle-repro-project --output-on-failure
cmake --build /dev/shm/forge-lifecycle-repro-project --target forge-selfhost-verify -j2
```

The recorded full local run passes 28/28 suites. The final isolated-owned test
CLI extension was rebuilt and the relevant two project targets plus all six
sanitized runtime suites rerun. The stage3/stage4 C outputs are byte-identical;
their hashes and unchanged stage0 compiler hash are in `metadata.json`. Build
paths may affect generated SDK paths or compiler bytes on reconstruction; only
the separate runtime Release libraries were tested for byte-exact reconstruction.

## Performance comparison

The benchmark requires Linux `/proc`, CPU IDs 0 through 10, and independent
producer/worker masks. It aborts rather than silently substituting a different
CPU map. GCC 13.3.0, `-O3 -std=c11 -Wall -Wextra`, no LTO:

```sh
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-benchmarks/benchmark/native_depth_bench.c libforge_runtime-baseline.a -pthread -o /dev/shm/lifecycle-repro-bench-baseline
cc -O3 -std=c11 -Wall -Wextra -I source-runtime/include source-benchmarks/benchmark/native_depth_bench.c libforge_runtime-candidate.a -pthread -o /dev/shm/lifecycle-repro-bench-candidate
python3 source-benchmarks/benchmark/native_depth_compare.py --baseline /dev/shm/lifecycle-repro-bench-baseline --candidate /dev/shm/lifecycle-repro-bench-candidate --pairs 24 --output /dev/shm/lifecycle-repro-measurements
```

The output path must not exist. `benchmark/results.json` retains 20 rows, 24
AB/BA pairs each, all raw samples, independent checksum checks, thread masks,
worker counts and bootstrap intervals. This finite shared-host run claims no new
throughput gain or non-inferiority proof. Terminal destruction is outside timing;
new linear backlog reclamation has different semantics from the old leak.

## OMO review records

`omo-*-session.json` exports contain actual requests/responses and source excerpts.
The model is `opencode/mimo-v2.6-flash-free`, requested agent
`Sisyphus - ultraworker`; do not infer delegated child-agent review. Three reviews
completed: design, ownership and start/stop. The broad final review exhausted its
response limit with no answer and is not counted as completed. Its live export,
terminal export and JSONL are preserved. Exact code excerpts are retained.

The reviewed POSIX lifetime argument and its primary specification links are in
`report.md` and `metadata.json`. Model suggestions rejected after source/testing
checks are documented, including keeping the cross-scheduler CAS and preserving
stopped-pool enqueue semantics.
