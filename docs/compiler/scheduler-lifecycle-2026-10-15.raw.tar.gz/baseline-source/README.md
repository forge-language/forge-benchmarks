# Forge runtime

Independent native C library extracted from [Forge](https://github.com/forge-language/forge)
commit `725aefb`. Apache-2.0; bundled third-party files keep their original notices.

```sh
cmake -S . -B build
cmake --build build -j2
ctest --test-dir build --output-on-failure
cmake --install build --prefix "$PWD/build/install"
```

Consume an installed package with `find_package(ForgeRuntime CONFIG REQUIRED)` and
link `ForgeRuntime::runtime`. Headers install under `include/` and archives under `lib/`.

The runtime owns arenas, ownership, scheduler, work queues, event loops and platform
primitives. It has no dependency on the standard library. `src/work_queue.h` is
an internal header and is deliberately excluded from the public SDK.

Native pool depth is an exact queued-only observation under the scheduler lock;
claimed callbacks remain in the separate pending-work completion count. A first
multi-worker depth query initializes an execution ledger from the protected queue
inventory, including already claimed work. Later queries use that ledger. Pools
that never query depth keep tracking disabled, and single-worker pools count
their one queue directly. Stop/restart retains queued work and the ledger.
A depth check followed by submission does not reserve capacity across callers.

Lifecycle limitations remain: destroying a stopped pool can leave internal spawn
wrappers queued without cleanup, and concurrent start/stop is not serialized.
The depth optimization does not add cancellation or graceful shutdown semantics.
