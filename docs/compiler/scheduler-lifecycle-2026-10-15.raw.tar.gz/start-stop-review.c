void fr_scheduler_start(fr_scheduler_t *sched) {
    if (!sched) return;
    fr_mutex_lock(sched->lock);
    while (sched->stopping) fr_cond_wait(sched->idle_cond, sched->lock);
    sched->running = 1;
    fr_scheduler_set_global(sched);
    scan_enqueue_runnable(sched);
    scheduler_start_workers(sched);
    fr_mutex_unlock(sched->lock);
}

void fr_scheduler_stop(fr_scheduler_t *sched) {
    if (!sched) return;
    fr_mutex_lock(sched->lock);
    while (sched->stopping) fr_cond_wait(sched->idle_cond, sched->lock);
    sched->stopping = 1;
    sched->running = 0;
    fr_cond_broadcast(sched->idle_cond);
    fr_cond_broadcast(sched->state_cond);
    fr_mutex_unlock(sched->lock);
    for (int i = 0; sched->workers && i < sched->worker_count; i++) {
        if (sched->workers[i]) fr_thread_join(sched->workers[i]);
        sched->workers[i] = NULL;
    }
    fr_mutex_lock(sched->lock);
    sched->workers_started = 0;
    /* Clear the old generation before a waiting start can publish this same
     * scheduler again. An unlocked CAS could erase the new generation. */
    fr_scheduler_t *expected = sched;
    atomic_compare_exchange_strong(&g_global_sched, &expected, NULL);
    sched->stopping = 0;
    fr_cond_broadcast(sched->idle_cond);
    fr_mutex_unlock(sched->lock);
}


/* Focused test excerpt */
static void test_start_during_stop(void) {
    atomic_store(&start_waiting,0);atomic_store(&start_returned,0);
    atomic_store(&stop_released,0);atomic_store(&allow_stop_return,0);
    gate_t g=make_gate();fr_scheduler_t *s=fr_scheduler_create(1);CHECK(s);
    fr_scheduler_start(s);CHECK(fr_sched_pool_submit(s,gated,&g)==0);wait_gate(&g,1);
    fr_thread_t *stopping=NULL,*starting=NULL;
    CHECK(fr_thread_start(&stopping,held_stop,s)==0);
    while(fr_sched_pool_available())fr_thread_yield();
    CHECK(fr_thread_start(&starting,start,s)==0);
    while(!atomic_load(&start_waiting)) {CHECK(!atomic_load(&start_returned));fr_thread_yield();}
    CHECK(!fr_sched_pool_available());
    release_gate(&g);
    while(!atomic_load(&start_returned)||!atomic_load(&stop_released))fr_thread_yield();
    CHECK(fr_scheduler_global()==s && fr_sched_pool_available());
    atomic_store(&allow_stop_return,1);
    CHECK(fr_thread_join(stopping)==0);CHECK(fr_thread_join(starting)==0);
    CHECK(fr_scheduler_global()==s && fr_sched_pool_available());
    atomic_store(&callbacks,0);CHECK(fr_sched_pool_submit(s,counted,NULL)==0);
    fr_scheduler_run(s);CHECK(atomic_load(&callbacks)==1);
    fr_scheduler_destroy(s);free_gate(&g);
}

static void test_other_global_scheduler(void) {
    gate_t g=make_gate();fr_scheduler_t *a=fr_scheduler_create(1),*b=fr_scheduler_create(1);CHECK(a&&b);
    fr_scheduler_start(a);CHECK(fr_sched_pool_submit(a,gated,&g)==0);wait_gate(&g,1);
    fr_thread_t *t=NULL;CHECK(fr_thread_start(&t,ordinary_stop,a)==0);
    while(fr_sched_pool_available())fr_thread_yield();
    fr_scheduler_start(b);release_gate(&g);CHECK(fr_thread_join(t)==0);
    CHECK(fr_scheduler_global()==b && fr_sched_pool_available());
    fr_scheduler_destroy(a);CHECK(fr_scheduler_global()==b && fr_sched_pool_available());
    fr_scheduler_destroy(b);free_gate(&g);
}

