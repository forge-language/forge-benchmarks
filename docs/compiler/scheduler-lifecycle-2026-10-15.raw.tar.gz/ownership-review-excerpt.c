typedef struct {
    fr_sched_native_fn1_t fn;
    int64_t arg;
} sched_native_arg1_t;

typedef struct {
    fr_sched_native_fn2_t fn;
    int64_t id;
    int64_t total;
    fr_mutex_t *lock;
    int *remaining;
    fr_cond_t *done;
} sched_indexed_ctx_t;

static void sched_native_trampoline1(void *p) {
    sched_native_arg1_t *ctx = (sched_native_arg1_t *)p;
    fr_sched_native_fn1_t fn = ctx->fn;
    int64_t arg = ctx->arg;
    free(ctx);
    fn(arg);
}

static void finish_indexed(sched_indexed_ctx_t *ctx) {
    fr_mutex_lock(ctx->lock);
    (*ctx->remaining)--;
    if (*ctx->remaining == 0) fr_cond_broadcast(ctx->done);
    fr_mutex_unlock(ctx->lock);
    free(ctx);
}

static void sched_native_trampoline2(void *p) {
    sched_indexed_ctx_t *ctx = (sched_indexed_ctx_t *)p;
    ctx->fn(ctx->id, ctx->total);
    finish_indexed(ctx);
}

/* Only the runtime's private wrappers own their arguments. Public submit's
 * opaque arguments remain borrowed and user callbacks are never run here. */
static void discard_native(fr_native_fn fn, void *arg) {
    if (fn == sched_native_trampoline1) free(arg);
    else if (fn == sched_native_trampoline2) finish_indexed(arg);
}

int64_t fr_sched_pool_spawn(fr_sched_native_fn1_t fn, int64_t arg) {
    fr_scheduler_t *sched = g_global_sched;
    if (!sched || !sched->running || !fn) return -1;
    sched_native_arg1_t *ctx = (sched_native_arg1_t *)malloc(sizeof(sched_native_arg1_t));
    if (!ctx) return -1;
    ctx->fn = fn;
    ctx->arg = arg;
    if (!sched_pool_submit(sched, sched_native_trampoline1, ctx)) { free(ctx); return -1; }
    return 0;
}

void fr_sched_pool_spawn_indexed(fr_sched_native_fn2_t fn, int64_t count) {
    fr_scheduler_t *sched = g_global_sched;
    if (!sched || !sched->running || !fn || count <= 0) return;
    if (count > sched->worker_count * 64) count = sched->worker_count * 64;

    /* This API waits for the batch to finish. A worker must not enqueue a
     * nested batch and block on its own pool: one worker (or all busy parents)
     * leaves no worker available to run the children. Keep nested same-pool
     * batches synchronous and inline; callers outside the pool retain the
     * parallel path below. No extra threads or ownership changes are needed. */
    if (tls_worker_scheduler == sched) {
        for (int64_t i = 0; i < count; i++) fn(i, count);
        return;
    }

    fr_mutex_t *lock = fr_mutex_create();
    fr_cond_t *done = fr_cond_create();
    int remaining = 0;
    if (!lock || !done) {
        fr_mutex_destroy(lock);
        fr_cond_destroy(done);
        return;
    }

    for (int64_t i = 0; i < count; i++) {
        sched_indexed_ctx_t *ctx = (sched_indexed_ctx_t *)calloc(1, sizeof(sched_indexed_ctx_t));
        if (!ctx) break;
        ctx->fn = fn;
        ctx->id = i;
        ctx->total = count;
        ctx->lock = lock;
        ctx->remaining = &remaining;
        ctx->done = done;
        fr_mutex_lock(lock);
        remaining++;
        if (!sched_pool_submit(sched, sched_native_trampoline2, ctx)) {
            remaining--;
            free(ctx);
            fr_mutex_unlock(lock);
            break;
        }
        fr_mutex_unlock(lock);
    }

    fr_mutex_lock(lock);
    while (remaining > 0) fr_cond_wait(done, lock);
    fr_mutex_unlock(lock);
    fr_mutex_destroy(lock);
    fr_cond_destroy(done);
}


void fr_native_queue_destroy_with_cleanup(fr_native_queue_t *q,
                                         void (*discard)(fr_native_fn, void *)) {
    if (!q) return;
    fr_native_node_t *n = q->head;
    while (n) {
        fr_native_node_t *next = n->next;
        if (discard) discard(n->fn, n->arg);
        free(n);
        n = next;
    }
    n = q->free_nodes;
    while (n) { fr_native_node_t *next = n->next; free(n); n = next; }
    q->head = q->tail = q->free_nodes = NULL;
    q->count = q->free_count = 0;
    fr_mutex_destroy(q->lock);
    q->lock = NULL;
}

void fr_native_queue_destroy(fr_native_queue_t *q) {
    fr_native_queue_destroy_with_cleanup(q, NULL);
}

