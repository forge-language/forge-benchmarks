"use strict";
const __forge=(()=>{
const wrap=v=>BigInt.asIntN(64,v),numeric=v=>typeof v==='boolean'?BigInt(v):v;
const arithmetic=(a,b,op)=>{a=numeric(a);b=numeric(b);if(typeof a==='bigint'&&typeof b==='bigint'){if((op==='div'||op==='mod')&&(b===0n||(a===-9223372036854775808n&&b===-1n)))throw new RangeError('Forge integer division');return wrap(op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b);}a=Number(a);b=Number(b);return op==='add'?a+b:op==='sub'?a-b:op==='mul'?a*b:op==='div'?a/b:a%b;};
const bytes=s=>new TextEncoder().encode(s),decode=b=>new TextDecoder('utf-8',{fatal:true}).decode(b);
const eq=(a,b)=>{a=numeric(a);b=numeric(b);return typeof a==='number'&&typeof b==='bigint'||typeof a==='bigint'&&typeof b==='number'?Number(a)===Number(b):a===b;},i=v=>BigInt(v);
const cbytes=s=>{s=s==null?'':s;const end=s.indexOf(String.fromCharCode(0));return bytes(end<0?s:s.slice(0,end));};
const shortString=s=>typeof s==='string'&&s.length<=64;
const beforeNul=s=>{const end=s.indexOf('\0');return end<0?s:s.slice(0,end);};
let shortEncoder,shortBuffer;
const encodePrefix=s=>{
  if(!shortEncoder)shortEncoder=new TextEncoder();
  if(!shortEncoder.encodeInto)return -1;
  if(!shortBuffer)shortBuffer=new Uint8Array(3*64);
  return shortEncoder.encodeInto(s,shortBuffer).written;};
const index=(s,n)=>{
  if(typeof s!=='string')return s[Number(n)];
  if(typeof n==='bigint'){
    const j=Number(n);
    if(j<0||j>=3*s.length)return -1n;
    if(s.length<=64||j<189){
      const size=encodePrefix(s);
      if(size>=0)return j<size?BigInt(shortBuffer[j]):-1n;
    }
  }
  const b=bytes(s),j=Number(n);
  return j<0||j>=b.length?-1n:BigInt(b[j]);};
const loopIndex=(cache,s,n)=>{
  if(typeof s!=='string'||typeof n!=='bigint'||s.length<=64||s.length>65536)return index(s,n);
  const j=Number(n);
  if(cache.text!==s){
    if(j<189||j>=3*s.length)return index(s,n);
    cache.data=bytes(s);cache.text=s;
  }
  return j<0||j>=cache.data.length?-1n:BigInt(cache.data[j]);};
const handles=new Map();let next=1n;const store=v=>{const h=next++;handles.set(h,v);return h;};
const view=h=>handles.get(h),builder=h=>{const b=handles.get(h);return b&&b.kind==='builder'?b:null;};
const reserve=(b,n)=>{if(n<=b.data.length)return;let cap=Math.max(64,b.data.length);while(cap<n)cap*=2;const d=new Uint8Array(cap);d.set(b.data.subarray(0,b.len));b.data=d;};
const range=(v,a,n)=>{if(!v||v.kind!=='view'||a<0n||n<0n)return null;const size=BigInt(v.data.length),from=a<size?a:size,left=size-from;return [Number(from),Number(n<left?n:left)];};
const appendBytes=(h,d)=>{const b=builder(h);if(!b)return 0n;reserve(b,b.len+d.length);b.data.set(d,b.len);b.len+=d.length;return h;};
return {add:(a,b)=>typeof a==='string'&&typeof b==='string'?a+b:arithmetic(a,b,'add'),sub:(a,b)=>arithmetic(a,b,'sub'),mul:(a,b)=>arithmetic(a,b,'mul'),div:(a,b)=>arithmetic(a,b,'div'),mod:(a,b)=>arithmetic(a,b,'mod'),eq,ne:(a,b)=>!eq(a,b),lt:(a,b)=>a<b,le:(a,b)=>a<=b,gt:(a,b)=>a>b,ge:(a,b)=>a>=b,index,loopIndex,println:(...v)=>console.log(v.map(x=>typeof x==='boolean'?(x?'1':'0'):String(x)).join('')),
fr_str_len:s=>{const n=shortString(s)?encodePrefix(s):-1;return i(n<0?bytes(s).length:n);},
fr_str_concat:(a,b)=>a+b,fr_str_eq:(a,b)=>i(a===b),fr_str_sub:(s,a,n)=>{if(a<0n||n<0n)return null;return decode(bytes(s).slice(Number(a),Number(a+n)));},fr_str_contains:(s,x)=>i(s.includes(x)),fr_str_trim:s=>s.trim(),fr_str_char_at:index,fr_str_append:(s,c)=>{if(c<0n||c>127n)throw new RangeError('JavaScript strings require valid UTF-8');return s+String.fromCharCode(Number(c));},fr_str_append_str:(s,t)=>s+t,fr_str_from_int:String,fr_str_arena_reset:()=>{handles.clear();return 0n;},
fr_str_view:s=>store({kind:'view',data:cbytes(s)}),fr_str_view_len:h=>{const v=view(h);return i(v&&v.kind==='view'?v.data.length:0);},
fr_str_view_at:(h,n)=>{
  const v=view(h);if(!v||v.kind!=='view')return -1n;
  if(typeof n==='bigint'){
    const pos=Number(n);
    return pos<0||pos>=v.data.length?-1n:BigInt(v.data[pos]);
  }
  return n<0n||n>=BigInt(v.data.length)?-1n:BigInt(v.data[Number(n)]);},
fr_str_view_sub:(h,a,n)=>{const v=view(h),r=range(v,a,n);return r?decode(v.data.subarray(r[0],r[0]+r[1])):null;},
fr_str_view_matches:(h,a,s)=>{
  const v=view(h);
  if(!v||v.kind!=='view'||s==null||a<0n||a>BigInt(v.data.length))return 0n;
  let from=Number(a),needle,length;
  if(typeof s==='string'){
    let j=0;
    for(;j<s.length;j++){
      const c=s.charCodeAt(j);
      if(c===0)return 1n;
      if(c>127)break;
      if(v.data[from++]!==c)return 0n;
    }
    if(j===s.length)return 1n;
    s=s.slice(j);
    if(s.length<=64){
      s=beforeNul(s);
      length=encodePrefix(s);
      if(length>=0)needle=shortBuffer;
    }
  }
  if(!needle){needle=cbytes(s);length=needle.length;}
  if(length>v.data.length-from)return 0n;
  for(let j=0;j<length;j++)if(v.data[from+j]!==needle[j])return 0n;
  return 1n;},
fr_str_view_append_byte:(h,c)=>{const v=view(h);if(!v||v.kind!=='view')return 0n;return store({kind:'view',data:cbytes(decode(v.data)+String.fromCharCode(Number(c)))});},
fr_str_builder:()=>store({kind:'builder',data:new Uint8Array(0),len:0}),fr_str_builder_with_capacity:n=>{if(n<0n||n>BigInt(Number.MAX_SAFE_INTEGER))return 0n;try{return store({kind:'builder',data:new Uint8Array(Number(n)),len:0});}catch{return 0n;}},fr_str_builder_append:(h,s)=>{
  if(shortString(s)){
    s=beforeNul(s);
    const n=encodePrefix(s);
    if(n>=0)return appendBytes(h,shortBuffer.subarray(0,n));
    return appendBytes(h,bytes(s));
  }
  return appendBytes(h,cbytes(s));},
fr_str_builder_append_view:(h,vh,a,n)=>{const v=view(vh),r=range(v,a,n);return r?appendBytes(h,v.data.subarray(r[0],r[0]+r[1])):0n;},
fr_str_builder_char:(h,c)=>{const b=builder(h);if(!b||c<=0n||c>255n)return 0n;reserve(b,b.len+1);b.data[b.len++]=Number(c);return h;},
fr_str_builder_finish:h=>{const b=builder(h);return b?decode(b.data.subarray(0,b.len)):null;},fr_str_builder_finish_take:h=>{const b=builder(h);if(!b)return null;const s=decode(b.data.subarray(0,b.len));b.data=new Uint8Array(0);b.len=0;return s;},
fr_abs_i:x=>x<0n?-x:x,fr_abs_f:Math.abs,fr_min_i:(a,b)=>a<b?a:b,fr_max_i:(a,b)=>a>b?a:b,fr_clamp_i:(x,a,b)=>x<a?a:x>b?b:x,fr_pow_i:(a,b)=>{if(b<0n)return 0n;let r=1n;while(b>0n){if(b&1n)r=wrap(r*a);a=wrap(a*a);b>>=1n;}return r;},fr_time_now_ms:()=>i(Date.now()),
fr_json_get_string:(s,k)=>{const v=JSON.parse(s)[k];return typeof v==='string'?v:'';},fr_json_get_int:(s,k)=>{const v=JSON.parse(s)[k];if(!Number.isSafeInteger(v))throw new RangeError('Use the lossless browser JSON module');return i(v);},fr_json_stringify_str:(k,v)=>JSON.stringify({[k]:v}),fr_json_stringify_int:(k,v)=>'{'+JSON.stringify(k)+':'+String(v)+'}'};})();
function fr_measure(fr_digest,fr_chars,fr_brackets,fr_at,fr_views,fr_stream) { const f=globalThis.ForgeNative?.["measure"]; if(typeof f!=='function') throw new Error('Missing Forge JavaScript FFI'); return f(fr_digest,fr_chars,fr_brackets,fr_at,fr_views,fr_stream); }
function fr_stream_input(fr_i) { const f=globalThis.ForgeNative?.["stream_input"]; if(typeof f!=='function') throw new Error('Missing Forge JavaScript FFI'); return f(fr_i); }
function fr_valid_digest(fr_value) {
  if (__forge.ne(__forge.fr_str_len(fr_value),(64n))) {
    return (0n);
  }
  let fr_i=(0n);
  while (__forge.lt(fr_i,(64n))) {
    let fr_c=__forge.loopIndex(__byteCache||(__byteCache={}),fr_value,fr_i);
    if ((Boolean((Boolean(__forge.lt(fr_c,(48n))) || Boolean(__forge.gt(fr_c,(57n))))) && Boolean((Boolean(__forge.lt(fr_c,(97n))) || Boolean(__forge.gt(fr_c,(102n))))))) {
      return (0n);
    }
    fr_i=__forge.add(fr_i,(1n));
  }
  var __byteCache = null;
  return (1n);
}

function fr_scan_chars(fr_value) {
  let fr_total=(0n);
  let fr_length=__forge.fr_str_len(fr_value);
  for (let fr_i=(0n);__forge.lt(fr_i,fr_length);fr_i=__forge.add(fr_i,(1n))) {
    fr_total=__forge.add(fr_total,__forge.loopIndex(__byteCache||(__byteCache={}),fr_value,fr_i));
  }
  var __byteCache = null;
  return fr_total;
}

function fr_scan_brackets(fr_value) {
  let fr_total=(0n);
  let fr_length=__forge.fr_str_len(fr_value);
  for (let fr_i=(0n);__forge.lt(fr_i,fr_length);fr_i=__forge.add(fr_i,(1n))) {
    fr_total=__forge.add(fr_total,__forge.loopIndex(__byteCache||(__byteCache={}),fr_value,fr_i));
  }
  var __byteCache = null;
  return fr_total;
}

function fr_read_at(fr_value,fr_offset) {
  return __forge.index(fr_value,fr_offset);
}

function fr_scan_view(fr_value) {
  let fr_handle=__forge.fr_str_view(fr_value);
  let fr_length=__forge.fr_str_view_len(fr_handle);
  let fr_total=(0n);
  for (let fr_i=(0n);__forge.lt(fr_i,fr_length);fr_i=__forge.add(fr_i,(1n))) {
    fr_total=__forge.add(fr_total,__forge.fr_str_view_at(fr_handle,fr_i));
  }
  __forge.fr_str_arena_reset();
  return fr_total;
}

function fr_stream_at(fr_start,fr_count,fr_offset) {
  let fr_total=(0n);
  for (let fr_i=(0n);__forge.lt(fr_i,fr_count);fr_i=__forge.add(fr_i,(1n))) {
    let fr_value=fr_stream_input(__forge.add(fr_start,fr_i));
    fr_total=__forge.add(fr_total,__forge.loopIndex(__byteCache||(__byteCache={}),fr_value,fr_offset));
  }
  var __byteCache = null;
  return fr_total;
}

function __forge_main() {
  fr_measure(fr_valid_digest,fr_scan_chars,fr_scan_brackets,fr_read_at,fr_scan_view,fr_stream_at);
  return (0n);
}
__forge_main();
