"""Time precompiled JS corpus programs in alternating order and verify every run."""
import json
import statistics
import subprocess
import sys
import time
from pathlib import Path

output = Path(sys.argv[1])
programs = [Path(arg) for arg in sys.argv[2:]]
rows = []
for pair in range(25):
    for program in (programs if pair % 2 == 0 else reversed(programs)):
        start = time.perf_counter_ns()
        actual = subprocess.check_output(['node', program])
        elapsed = (time.perf_counter_ns() - start) / 1e6
        if actual != b'alerts=60000\n':
            raise ValueError((program, actual))
        rows.append({'pair': pair, 'variant': program.stem, 'ms': elapsed})
output.write_text(json.dumps(rows, indent=2) + '\n')
for program in programs:
    print(program.stem, statistics.median(r['ms'] for r in rows if r['variant'] == program.stem))
