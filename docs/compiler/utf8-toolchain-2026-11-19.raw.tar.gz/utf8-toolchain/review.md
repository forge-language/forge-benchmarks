# Review of the Forge lexer and bootstrap constant lookup

Baseline is Forge 642aea4. The request was to check equivalence, malformed inputs, allocation costs and measurement controls in compiler/lexer.c and bootstrap/compiler.fg. This review covers these changes only.

**CRITICAL** — none.

**HIGH** — none outstanding. One earlier lookup used an arena allocation to append a colon to every query name. Allocation failure would turn a real constant match into a miss. The revised bootstrap/compiler.fg at line 1220 compares the original name and a separate colon with short-circuit evaluation. The matched bytes fit the source view before the following character is addressed. Offset conversion and builder finalization are checked in validate_source.

**MEDIUM** — none in the audited code. Recording unreferenced constants incurs work per declaration and should be included in any performance story for large constant-heavy inputs. Queries still scan the compact records linearly.

**LOW** — the self-hosted data representation uses a decimal offset decoded at use time. The producer encodes an observed source position, and the checked arena builder emits one complete record at a time. The restricted bootstrap language justifies the representation.

## Executed checks

- Compiled independent old/new lexer drivers using the historical C implementation and the current one. All 40 reserved words and 278 unique exact and adjacent spellings returned identical token kinds and spans.
- Compared baseline and candidate stage2 on 512 deterministic generated sources (seed 439) including valid and invalid declarations, reserved names, comments, duplicates, prefix collisions, constant aliases, local/parameter shadowing and cycles. Compared exit code, stdout, stderr and emitted C bytes or absence. All matched.
- Ran parser_regressions and selfhost_regressions through CTest, both passed.
- Inspected build/study/stage2.json. The initial compare includes the baseline compiler source, a mixed constant workload, and a tiny control. Each input produced identical C hashes in all three variants. The performance claim is limited to measured emission including process startup and writing C. It excludes the downstream native build.
- Reviewed the remove-ai-slops and programming skill criteria for implementation-mirroring tests, unnecessary extraction and brittle abstractions. No test-only implementation mirrors or needless abstractions in this diff. Local lookup still requires latest match, while global constant references retain original source order.
- The short decimal literal path in compiler/lexer.c uses a zero-initialized Token and only handles up to 18 decimal digits (maximum 999999999999999999, within int64). Longer and floating literals retain their original checked conversion.

Code quality status CLEAR. Recommendation APPROVE. No remaining implementation blocker for the audited changes. Benchmark publication and complete integration checks are separately owned by the parent.

## Supplemental review of the later candidates

Reviewed the emitted JS prefix implementation, first/last bootstrap-record lookup, check-only CLI, log alert example and installed C consumer.

- Compared generated baseline/candidate runtimes over 11,520 observations including 63/64/65-unit needles, ASCII lead-ins, non-BMP characters, unpaired surrogates, NUL, invalid offsets, null, boxed strings, numbers, arrays and objects. Both standard TextEncoder and a missing encodeInto fallback were exercised. Returned values and thrown error types agreed.
- Short UTF-8 suffixes require at most 3 bytes per UTF-16 unit. ASCII comparisons consume byte positions, and NUL termination takes effect before encoding. Generated alert examples from both compilers printed alerts=3.
- Verified late imported signatures, duplicate constants with competing errors, and nested lexical binding behavior against the baseline, including emitted C bytes for accepted inputs. Check-only results agreed with emission diagnostics and preserved the source used as the explicit output.
- javascript_regressions and selfhost_regressions passed again. Verified parallel independent clean configure/build of c_greeting with the installed package via Unix Makefiles, then rebuilt after deleting the generated header and editing the Forge source. Each invocation compiled the Forge library and the C executable printed the expected greeting. Ninja is absent on this host.
- build/study/stage2-final.json includes unqueried-constant and tiny input controls. At review time the JS timing set included ASCII success/failure, mixed UTF-8, Unicode hits and long ASCII hits. Additional long-Unicode and near-end misses would strengthen the measured scope of the fallback; differential correctness already covers these paths. No language-wide throughput inference follows.
- Both skill perspectives applied. The observable-output and protected-artifact assertions exercise actual behavior. No remaining CRITICAL, HIGH or MEDIUM defect. LOW residual evidence limitation is the JS timing controls listed above.

## BigInt byte-index refinement

Verified the final emitted fr_str_view_at against the baseline over 888 independent calls including valid UTF-8 byte offsets, invalid and builder handles, multiple view lengths, non-BigInt FFI values and boundaries near signed powers of two from 31 through 4096 bits. Return values and thrown exception classes matched. Current JavaScript regression suite passes.

Typed-array lengths are safe nonnegative integers. Every valid BigInt offset therefore converts exactly. A greater out-of-safe-range positive value rounds to at least 2^53 or infinity, both beyond the largest possible indexed byte. A negative integer stays negative. The non-BigInt branch preserves the original relational conversions and indexing behavior. Recommendation remains APPROVE.
