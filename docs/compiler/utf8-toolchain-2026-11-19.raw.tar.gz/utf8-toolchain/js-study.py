import hashlib, json, platform, statistics, subprocess, sys, tempfile, time
from pathlib import Path

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

before, after = map(lambda arg: Path(arg).resolve(), sys.argv[1:3])
output = Path(sys.argv[3])
cases = [
    ('ascii_hit', 'level=warn message', 'level=warn', 1),
    ('ascii_miss', 'level=info message', 'level=warn', 0),
    ('mixed_hit', 'id=서울', 'id=서울', 1),
    ('unicode_hit', '🍵서울', '🍵서울', 1),
    ('unicode_miss', '🍵서울', '🍵서X', 0),
    ('long_unicode', '한' * 160, '한' * 160, 1),
    ('short_view', 'id', 'id=서울', 0),
    ('long_hit', 'x' * 2048, 'x' * 2048, 1),
]
result = {'host':platform.platform(),'node':subprocess.check_output(['node','--version'],text=True).strip(),
          'compilers':{'baseline':digest(before),'candidate':digest(after)},'cases':{}}
with tempfile.TemporaryDirectory() as temp:
    root=Path(temp)
    for case, text, prefix, hit in cases:
        n=16000 if case=='long_hit' else 120000
        fg=root/'prefix.fg'
        fg.write_text(f'''import strings;
fn count(text: string, prefix: string, visits: int): int {{
    let view: int = str_view(text);
    let hits: int = 0;
    for (let i: int = 0; i < visits; i += 1) {{
        hits += str_view_matches(view, 0, prefix);
    }}
    return hits;
}}
native main {{ println(count("{text}", "{prefix}", {n})); return 0; }}
''')
        js=[root/'before.js',root/'after.js']
        for cc, path in zip((before,after),js):
            subprocess.run([cc,fg,'--emit-js','-o',path],check=True)
        runs=[]
        for iteration in range(17):
            for which in ([0,1] if iteration%2==0 else [1,0]):
                start=time.perf_counter_ns()
                proc=subprocess.run(['node',js[which]],capture_output=True,check=True)
                ms=(time.perf_counter_ns()-start)/1e6
                if proc.stdout!=f'{hit*n}\n'.encode():
                    raise ValueError((case,proc.stdout))
                runs.append({'pair':iteration,'variant':['baseline','candidate'][which],'ms':ms})
        result['cases'][case]={'n':n,'expected':hit*n,'source':digest(fg),
                               'emitted_js':[digest(p) for p in js],'runs':runs}
        print(case,*[round(statistics.median(r['ms'] for r in runs if r['variant']==v),1)
                     for v in ('baseline','candidate')],flush=True)
output.write_text(json.dumps(result,indent=2)+'\n')
