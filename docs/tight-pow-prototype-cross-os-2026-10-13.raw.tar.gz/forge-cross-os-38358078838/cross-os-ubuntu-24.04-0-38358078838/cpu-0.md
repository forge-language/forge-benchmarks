# Native cross-OS CPU comparison

Platform: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39` / `x86_64`. Measured 60 balanced triples per workload, seed 2026101302.
**Generated-C experiment `tight-pow`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0000 [0.9996, 1.0003] | 1.8551 [1.8544, 1.8556] | supported for this case |
| primes | 1.3627 [1.3603, 1.3649] | 1.3864 [1.3850, 1.3878] | supported for this case |
| scan | 1.0011 [0.9884, 1.0086] | 2.4148 [2.4025, 2.4383] | supported for this case |
| builder | 0.9996 [0.9976, 1.0015] | 1.7212 [1.7181, 1.7237] | supported for this case |
| immutable | 1.0030 [1.0000, 1.0058] | 21.8516 [21.7965, 21.9385] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-0.json](cpu-0.json).
