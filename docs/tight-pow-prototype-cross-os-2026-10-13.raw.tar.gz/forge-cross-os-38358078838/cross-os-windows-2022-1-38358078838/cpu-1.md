# Native cross-OS CPU comparison

Platform: `Windows-2022Server-10.0.20348-SP0` / `AMD64`. Measured 60 balanced triples per workload, seed 2026101303.
**Generated-C experiment `tight-pow`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 0.9999 [0.9993, 1.0005] | 1.8571 [1.8558, 1.8581] | supported for this case |
| primes | 1.1293 [1.1072, 1.1669] | 1.3798 [1.3613, 1.3943] | supported for this case |
| scan | 0.9993 [0.9985, 1.0015] | 2.4915 [2.4299, 2.5372] | supported for this case |
| builder | 1.0026 [0.9934, 1.0067] | 1.6497 [1.6407, 1.6661] | supported for this case |
| immutable | 0.9730 [0.9610, 0.9939] | 78.4333 [77.4215, 79.6627] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
