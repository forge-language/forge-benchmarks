# Native cross-OS CPU comparison

Platform: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39` / `x86_64`. Measured 60 balanced triples per workload, seed 2026101303.
**Generated-C experiment `tight-pow`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 0.9999 [0.9994, 1.0005] | 1.8541 [1.8534, 1.8547] | supported for this case |
| primes | 1.3648 [1.3601, 1.3687] | 1.3793 [1.3777, 1.3816] | supported for this case |
| scan | 0.9994 [0.9986, 1.0001] | 2.4280 [2.4262, 2.4329] | supported for this case |
| builder | 0.9856 [0.9749, 0.9944] | 1.5534 [1.5367, 1.5690] | supported for this case |
| immutable | 1.0004 [0.9979, 1.0021] | 26.2971 [26.2395, 26.3563] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
