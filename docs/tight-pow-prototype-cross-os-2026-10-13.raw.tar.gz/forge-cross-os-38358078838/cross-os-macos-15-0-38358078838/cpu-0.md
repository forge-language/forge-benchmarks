# Native cross-OS CPU comparison

Platform: `macOS-15.7.9-arm64-arm-64bit` / `arm64`. Measured 60 balanced triples per workload, seed 2026101302.
**Generated-C experiment `tight-pow`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 0.9975 [0.9358, 1.0230] | 1.6499 [1.5907, 1.6863] | supported for this case |
| primes | 1.3220 [1.2866, 1.3567] | 1.2334 [1.2154, 1.2503] | supported for this case |
| scan | 0.9900 [0.9542, 1.0194] | 8.7952 [8.5363, 9.0711] | supported for this case |
| builder | 1.0021 [0.9832, 1.0312] | 3.3018 [3.2256, 3.3494] | supported for this case |
| immutable | 0.9954 [0.9725, 1.0038] | 23.2267 [22.6948, 23.7237] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-0.json](cpu-0.json).
