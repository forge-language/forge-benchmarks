# Native cross-OS CPU comparison

Platform: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39` / `x86_64`. Measured 60 balanced triples per workload, seed 2026101302.
**Generated-C experiment `target-remainder`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0002 [0.9993, 1.0010] | 1.7177 [1.7160, 1.7191] | supported for this case |
| primes | 1.0007 [0.9978, 1.0017] | 1.4224 [1.4185, 1.4253] | supported for this case |
| scan | 1.0002 [0.9993, 1.0014] | 2.3951 [2.3839, 2.4031] | supported for this case |
| builder | 1.0007 [0.9991, 1.0018] | 1.4707 [1.4679, 1.4735] | supported for this case |
| immutable | 1.0024 [0.9950, 1.0172] | 24.2186 [24.0241, 24.5854] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
