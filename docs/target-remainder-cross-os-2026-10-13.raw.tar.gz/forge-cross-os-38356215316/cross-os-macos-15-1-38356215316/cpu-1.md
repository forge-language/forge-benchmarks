# Native cross-OS CPU comparison

Platform: `macOS-15.7.9-arm64-arm-64bit` / `arm64`. Measured 60 balanced triples per workload, seed 2026101302.
**Generated-C experiment `target-remainder`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 0.9981 [0.9944, 1.0050] | 1.6045 [1.5869, 1.6145] | supported for this case |
| primes | 1.0009 [0.9936, 1.0059] | 0.9549 [0.9513, 0.9655] | below target |
| scan | 1.0012 [0.9971, 1.0089] | 9.0316 [8.9442, 9.1847] | supported for this case |
| builder | 0.9999 [0.9942, 1.0050] | 3.3484 [3.3204, 3.4431] | supported for this case |
| immutable | 0.9995 [0.9948, 1.0020] | 22.3658 [22.2441, 22.4935] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
