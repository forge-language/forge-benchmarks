# Native cross-OS CPU comparison

Platform: `macOS-15.7.9-arm64-arm-64bit` / `arm64`. Measured 60 balanced triples per workload, seed 2026101301.
**Generated-C experiment `target-remainder`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0037 [0.9680, 1.0497] | 1.6433 [1.5975, 1.7093] | supported for this case |
| primes | 1.0023 [0.9852, 1.0304] | 0.9485 [0.9215, 0.9776] | below target |
| scan | 1.0049 [0.9761, 1.0236] | 9.2049 [8.8776, 9.4621] | supported for this case |
| builder | 1.0121 [0.9498, 1.1180] | 3.3379 [3.1555, 3.4516] | supported for this case |
| immutable | 1.0031 [0.9658, 1.0472] | 27.2222 [26.4383, 28.4721] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-0.json](cpu-0.json).
