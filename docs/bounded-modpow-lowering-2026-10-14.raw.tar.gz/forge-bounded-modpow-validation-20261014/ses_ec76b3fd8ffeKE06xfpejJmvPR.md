I've completed a full read of the matcher, helpers, and all three entry sites. Report:

---

# AST matcher audit: `emit_bounded_mod_pow` (read-only)

**Source audited:** `/home/helloworld0822/coding/forge/compiler/codegen.c` (current on-disk, not history, not `build/_deps`).

**Scope:** `emit_bounded_mod_pow` (2201–2298), `cg_power_mod_product` (2188–2195), `cg_integer_is` (2184–2186), `cg_begin_function` (76–87), and the three call sites (2965, 3057, 3079).

---

## Entry sites and `cg_begin_function`

| Site | Path | Setup before matcher |
|------|------|----------------------|
| 2962–2965 | library mode | `cg_begin_function` → `prove_loop_increments=true` → `cg_push_params` → `emit_bounded_mod_pow` |
| 3053–3057 | native top-level fns | same + `current_module=""` |
| 3075–3079 | module fns | same + `current_module=mod->name` |

`cg_begin_function` (76–87) resets `local_count`, `moved_count`, `prove_loop_increments=false`, `loop_scan_left=CG_LOOP_SCAN_BUDGET` (65536), and related caches. It does **not** clear `state_prefix`; that is handled by the coro path (see Coroutines).

Return value of `emit_bounded_mod_pow` is ignored at all three sites; a successful match emits a guarded early-return fast path, then `emit_stmts` still emits the original body as the unguarded fallback. That is intentional, not a bug.

---

## Soundness by dimension

### 1. Binding — sound

`base`, `modulus`, `exp` must all pass `cg_is_local` (2228). At match time only params are in `cg->locals` (lets are not pushed until later `emit_stmts`), so all three are forced to be parameters. `cg_lookup_local(...).kind != TY_INT` (2229–2230) is redundant with the all-params-must-be-int loop (2203–2206) but harmless.

Const idents are rejected: `emit_expr` maps non-local idents that hit `cg_lookup_const` to `forge_const_NAME` (555–556); the matcher never allows that path for `base`/`modulus`/`exp` because it requires `cg_is_local`.

**Counterexample that is correctly rejected:**
```
const M = 7;
fn f(a: int, b: int): int {
  let r: int = 1;
  let fact: int = a % M;  // M is const, not a local
  ...
}
```
→ `cg_is_local(M)` is false → reject. Emission would otherwise emit bare `M` (not `forge_const_M`) in the fast path.

### 2. Param aliases — sound (accepted-but-degenerate, still equivalent)

The matcher does **not** require `base`, `modulus`, `exp` to be distinct. Example accepted:

```
fn f(m: int, e: int): int {
  let r: int = 1;
  let fact: int = m % m;   // base == modulus
  let p: int = e;
  while p > 0 { if p % 2 == 1 { r = r * fact % m; }
                fact = fact * fact % m; p = p / 2; }
  return r;
}
```
For the fast-path guard (`modulus > 1`), `m % m == 0`, so both paths yield `0` for `e > 0` and `1` for `e == 0`. Same for `base == exp` or all three aliased. Not an inequivalence; it is still modular exponentiation with a degenerate base.

### 3. Shadowing — sound

- Let names must not already be locals (`!cg_is_local(s->as.let.name)`, 2211), so a let cannot shadow a param. Semantic analysis allows shadowing (`declare` just appends, `semantic.c:308`); the matcher is strictly narrower.
- The three let names must be pairwise distinct (2212–2213).
- During the match region there is no nested block that could rebind `base`/`modulus`/`exp`; the shape is flat (3 lets → 1 while → 1 return). Name equality therefore equals binding identity inside the matched region.

### 4. Strict body shape — sound

Required shape (all checks at 2208–2251):

```
let result: int = 1;
let factor: int = <ident> % <ident>;
let power:  int = <ident>;
while power > 0 {
  if <power % 2 == 1 | 1 == power % 2> { result = result*factor % m | factor*result % m; }
  factor = factor * factor % m;
  power  = power / 2;
}
return result;
```

Rejection paths (non-exhaustive but complete for shape):
- non-`TY_INT` return, any non-`TY_INT` param, `state_prefix` set, `prove_loop_increments` false (2202)
- missing/duplicate/wrong-typed lets; any statement between the three lets and the while; anything other than a single `STMT_RETURN` after the loop; `ret->next != NULL` (2219–2221)
- factor init not `IDENT % IDENT`; power init not `IDENT` (2222–2224)
- cond not `power > 0` (2231–2232)
- while body not exactly `if + factor-assign + power-assign`, or if has an else, or `halve->next != NULL` (2234–2239)
- if-body not exactly one `result = result*factor % m` assign (`multiply->next != NULL`, 2248–2250)
- product shapes not `(a*b)%m` or `(b*a)%m` (`cg_power_mod_product`, 2188–2195)
- integer literals other than exactly 0, 1, or 2 (`cg_integer_is`, 2184–2186)

No accepted-but-inequivalent shape counterexample found: any AST that passes these checks is syntactically the tight-pow loop (possibly with commutative `*`/`==` swaps, which are semantically identical).

### 5. Calls / observers / escaping locals — sound

- Every expression position is constrained to `EXPR_INT`, `EXPR_IDENT`, or a specific `BIN_MOD`/`BIN_MUL`/`BIN_GT`/`BIN_EQ`/`BIN_DIV` node. `EXPR_CALL`, `EXPR_QUAL_CALL`, `EXPR_MOVE`, `EXPR_INDEX`, etc. all fail the kind checks. No call can appear in a matched position.
- Observers (`print`, `spawn`, `send`, …) are `STMT_EXPR` / `STMT_SPAWN` / `STMT_SEND` and break the fixed statement sequence (or the `multiply->next` / `halve->next` single-statement constraints).
- Only `result` is returned; `factor`/`power` are dead on exit. Params `base`/`modulus`/`exp` are never assignment targets in the matched shape. No pointer/owned types allowed (all `TY_INT`). Nothing escapes.

**Rejected observer example:**
```
fn f(a: int, b: int, m: int): int {
  ...
  while p > 0 {
    if p % 2 == 1 { print(r); r = r * fact % m; }  // then_br->first is not STMT_ASSIGN
    ...
  }
}
```

### 6. Coroutine exclusion — sound (triple-gated)

1. Structural: `emit_coro_fn` (1065) never calls `emit_bounded_mod_pow`. Only the three function-emission paths do.
2. `state_prefix`: coro emission sets `cg->state_prefix = "st->"` (1077); matcher bails on any non-NULL `state_prefix` (2202). Prefix is restored (1097) before later function emission.
3. `prove_loop_increments`: coro path never sets it true; `cg_begin_function` clears it (81). Matcher requires it true (2202).

Process `init` (3094) and `main` (3106, 3132) also never call the matcher.

### 7. Name collisions — sound for the generated C names

- Generated names: `__forge_pow_{divisor,reciprocal,factor,result,power,product,quotient}_<id>` (2255–2266).
- Collision check (2267): `cg_is_local` (params only at match time) or `cg_resolve_fn_ref` (top-level + current module). Retry up to 64 times with `id++` (2261–2270).
- Consts are emitted as `forge_const_NAME` (2669), a disjoint prefix; no collision with `__forge_pow_*`.
- Other matchers use disjoint prefixes (`__forge_periodic_*`, `__forge_invariant_mod_*`) and share `label_seq`, so ids differ.
- Overflow: `label_seq > INT_MAX - 65` → reject (2257).
- Fast-path locals live inside the `if (...) { ... }` block (2271–2296), closed before `emit_stmts` redeclares the Forge body’s locals. No C redeclaration issue.

**Residual (non-blocking):** collision check does not consult `const_map` or C library globals; irrelevant here because the prefix is `__forge_`-reserved and consts use a different prefix.

### 8. Scan / retry budget — sound

- `CG_LOOP_SCAN_BUDGET = 65536` (11); reset per function by `cg_begin_function` (82).
- Charged: 1 per param (2204–2205); shape walk is fixed-size O(1) and free; on success path, flat 64 (2253–2254) + 1 per collision attempt, max 64 attempts (2262–2263).
- Failed shape match only spends the param-loop budget — bounded, no unbounded scan.
- Worst-case spend per call: `#params + 64 + 64`. No DoS / unbounded retry.

---

## Counterexample search result

No concrete accepted-but-inequivalent input was found for any dimension. Every near-miss (const-as-modulus, observer in if-body, let-shadowing-param, call in init, extra stmt after return, non-int param, coro body) is rejected by an explicit check cited above.

---

## Blockers / unknowns (separate from matcher soundness)

1. **Fast-path arithmetic not re-proven here.** The Barrett/`__int128` reduction (2276–2295) is assumed correct for the guarded domain (`base,exp ≥ 0`, `1 < modulus ≤ 2^21`, products `< d^2`). Matcher soundness is “accepted shape ⇒ emits this fast path”; whether that C is numerically identical to signed wrapping `int64` for every guarded input was not machine-checked in this read-only pass.
2. **No covering tests** were found for these symbols (codegraph blast radius).
3. **Parser null-child guarantee** for `EXPR_BINARY` left/right is assumed (matcher dereferences `initial->as.binary.left` without a null check at 2223–2224). If the parser can emit a null child, that is a crash risk outside the matcher’s logical scope.
4. **Forge `%`/`/` semantics for negatives** were not cross-checked against C; irrelevant to the fast path because the guard excludes negatives, so unguarded inputs keep the original body.
5. Compiler was not built or run (task forbids tests/execution).

---

## Verdict

On the inspected source, the matcher is **sound with respect to binding, shadowing, strict shape, call/observer/escape exclusion, coroutine exclusion, name collision, and scan budget**. Param-role aliasing is allowed but remains semantically modular exponentiation. No accepted-but-inequivalent counterexample was constructed; the only open items are the numeric correctness of the emitted Barrett fast path and the absence of tests, both listed as blockers/unknowns rather than matcher defects.
