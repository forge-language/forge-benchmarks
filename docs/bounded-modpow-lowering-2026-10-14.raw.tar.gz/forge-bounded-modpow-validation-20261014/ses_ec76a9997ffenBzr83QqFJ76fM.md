All verification steps are complete. Here is the final audit report.

**Audit verdict: the six-job tight-pow prototype evidence is internally consistent and correctly published; two documentation/provenance issues found, no fabricated data.**

**Verified (evidence-backed)**
1. Six generated-C jobs exist (`/tmp/forge-cross-os-38358078838/*/cpu-*.json`), all `"status": "completed"`, all with `after_probe.name == "tight-pow"`.
2. Counts: 720 correctness (120/job), 5,400 warmups, 5,400 measurements; every `checksum == reference_checksum`. Measurement triples share identical seed/input per pair; warmup seeds equal measurement seeds; run-0 and run-1 use distinct seed sets replicated across all three OSes; `n`/`rounds` identical in all six jobs.
3. Balance: 60 pairs per workload per job, all six (after, before, rust) permutations exactly 10 each — perfectly balanced.
4. Candidate purity: in all six jobs `after_probe.original_c_sha256 == generated_c_sha256.before`, i.e. the two compilers emit byte-identical C; the only candidate delta is the recorded bounded-power text patch. Revisions `before.head == after.head == 420d66f`, clean trees.
5. Source hashes: `kernels.fg`, `kernels.rs`, `clock.c`, and headers are byte-identical between Linux and macOS; Windows differs raw but is **equal after CRLF normalization** (spot-checked `kernels.fg`, `kernels.rs`, `clock.c`, `include/forge/math.h`). Runner source identical across all six jobs (no CR).
6. Bounds: all 30 summary rows are `supported for this case`; minimum `candidate_over_rust` ci95 lower = 1.2069 (macos-1 primes) > 1.10. The md table matches the JSON summaries exactly (0 mismatches at 4-dp).
7. Oracle/tarball: each of the two oracle logs contains 4 × 713 passing lines → 8 × 713 = 5,704 executions, matching the doc; tarball SHA-256 matches `21910d8f…654083`.
8. Ledger: 18 runs, 100 jobs (86 success / 14 failure), 90 reports, zero missing files; prototype run `38358078838` present with `workflow.conclusion: success`, 6/6 successful jobs, 6 report paths. Published `docs/cross-os-38358078838-*.json` are content-identical to the raw CPU JSONs (6/6), git-tracked and clean.

**Findings (concrete, cited)**
1. Stale ledger totals — [target-remainder-cross-os-2026-10-13.md:46](/home/helloworld0822/coding/forge-benchmarks/docs/target-remainder-cross-os-2026-10-13.md:46) says "now retains 17 runs, 94 jobs (80 successful, 14 failed) and 84 reports (80 completed, four failed_no_claim)". Actual current state is 18/100(86/14)/90(86 completed, 4 `failed_no_claim`). The claimed numbers exactly equal the ledger *excluding* the prototype run, so the sentence was true when written but is now stale by precisely the prototype run.
2. Windows producer binary identity — on Windows `forge-before.exe ≠ forge-after.exe` within each job, and the hash differs between the two Windows jobs (2 distinct hashes); Ubuntu/macOS producers are byte-identical (1 hash per OS across both jobs). The "same shipped compiler" claim therefore holds at source-revision and emitted-C-identity level, but not at binary-hash level on Windows (consistent with nondeterministic PE builds; root cause not provable read-only).
3. macOS SDK instability — `libforge_std.a`/`libforge_runtime.a` have 2 distinct hashes across the two macOS jobs (Ubuntu/Windows stable at 1). "Shared SDK" holds within each job (single snapshot per job) but the macOS archives are not byte-stable across runs.

**Stated limitations**
- Read-only audit; no benchmarks executed, nothing edited.
- Oracle logs contain only pass-count lines — the doc's boundary-modulus case enumeration is not verifiable from the archive.
- The `dimensions` file is not archived; `dimensions_sha256` differs on Windows vs unix (line-endings hypothesis only, unconfirmed).
- Cross-OS confounds are real and already disclosed in [tight-pow-prototype-cross-os-2026-10-13.md:38](/home/helloworld0822/coding/forge-benchmarks/docs/tight-pow-prototype-cross-os-2026-10-13.md:38): rustc 1.98.1 (macOS) vs 1.99.0 (Linux/Windows), different CPUs (EPYC 9V74 / EPYC 7763 / Apple arm64), gcc 13.3 / Apple clang 17 / MSYS2 gcc 16.2, CLOCK_MONOTONIC vs QueryPerformanceCounter — causal OS effects cannot be isolated.

**Assumption applied:** the task premise "ledger has 17 runs; prototype not yet published" was treated as outdated rather than true — current state is 18 runs with the prototype published in both `docs/cross-os-attempts-2026-10-13.json` and the six `docs/cross-os-38358078838-*.json` reports. The prototype doc itself makes no overclaim: it explicitly labels itself "generated-C screening, not evidence from the new generic compiler implementation" and gates release reporting behind regression/semantic/performance gates.
