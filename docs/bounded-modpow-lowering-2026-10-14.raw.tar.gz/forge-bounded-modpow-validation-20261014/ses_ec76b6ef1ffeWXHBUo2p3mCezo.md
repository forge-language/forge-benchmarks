All source evidence is in hand; the paper proof is complete. Final audit report follows.

---

# Audit: `emit_bounded_mod_pow` quotient exactness vs Python tight-pow probe

**Verdict: all six claims (a)–(f) CONFIRMED from source. No counterexamples. No UB found in the guarded path.** Read-only paper proof; nothing compiled or run.

**Artifacts compared**
- Compiler: [codegen.c:2200](/home/helloworld0822/coding/forge/compiler/codegen.c:2200) `emit_bounded_mod_pow`; guard 2270–2272; reciprocal 2275; peel/square/multiply 2278–2293; comment 2283–2285; return 2295; fall-through `#endif` 2296. Emitted before the original body at all three call sites ([2965](/home/helloworld0822/coding/forge/compiler/codegen.c:2965)/2968, 3057/3060, 3079+`emit_stmts`).
- Python probe: [cross_os_cpu_compare.py:81–118](/home/helloworld0822/coding/forge-benchmarks/benchmark/cross_os_cpu_compare.py:81), prefix 89–114, spliced after the signature so the original body follows as fallback (115–116).
- Original body shape: [kernels_prime_miller_rabin.fg:14–17](/home/helloworld0822/coding/forge-benchmarks/benchmark/cpu/kernels_prime_miller_rabin.fg:14) matches the codegen matcher (2218–2250: `result=1; factor=base%modulus; power=exponent; while power>0 { if power%2==1 {result=result*factor%modulus}; factor=factor*factor%modulus; power=power/2 } return result`).

**(a) Quotient exactness — PROVEN.** B=2^64, R=ceil(B/d) (verified: `UINT64_MAX/d+1` equals ceil(B/d) for all d≥1, including d|B), e=dR−B ∈ [0, d−1]. For n=dq+rem: floor(nR/B)=floor(n/d) ⟺ n·e < B·(d−rem); since d−rem ≥ 1 it suffices that n·e < B. With n ≤ d²−1, e ≤ d−1: n·e ≤ (d²−1)(d−1)=d³−d²−d+1 ≤ 2^63−2^42−2^21+1 < 2^64 for d ≤ 2^21. So `q=((prod·R)>>64)` (codegen.c:2286, py:101) is exactly floor(n/d) — never one-larger — hence `prod − q·d` (2287/py:102) never underflows and yields prod mod d. The 128-bit product fits (n < 2^42, R < 2^64 ⇒ < 2^106 < 2^128). Note the separate helper comment "exact quotient or one larger" at [codegen.c:2819](/home/helloworld0822/coding/forge/compiler/codegen.c:2819) belongs to `__forge_mod_invariant` (uncorrected-quotient discussion with explicit correction at 2822), not this path — no contradiction.

**(b) Structural equivalence — CONFIRMED identical.** Guard `base>=0 && exponent>=0 && modulus>1 && modulus<=INT64_C(2097152)` is textually the same (2270–2272 vs py:91). Fast-path bodies are byte-identical modulo the `probe_` prefix (peel 2279/py:97, square-first loop 2281–2293/py:99–108). Signed-width: all fast-path math is `uint64_t`; only conversions are guarded casts of nonnegative int64 and the return of r < d ≤ 2^21 (value-preserving, 2295/py:111); products < d² ≤ 2^42 so the raw `f*f` (2282) cannot wrap. Trap: fast path contains no division (reciprocal multiply only), d ≥ 2. Fallback: both fall through to the unchanged original body on guard failure or missing `__SIZEOF_INT128__` (2296/py:113), preserving the original entry trap `base % modulus` via `__forge_mod_i64` (codegen.c:2780, 2837). Exponent-zero: `if (p)` skips the loop, returns 1; original skips `while power>0`, returns 1 — 0^0=1 in all three. First-bit peel: peel of bit0 ≡ original's first-iteration multiply by initial result=1. The two algorithms compute the same powmod for every input in the guard domain.

**(c) n=0 — no special handling needed, claim accurate.** n=0 makes n·e=0 < B trivially ("n=0 is immediate", 2284); q=0, remainder 0−0=0, no underflow. base=0 passes `base>=0`, f=0% d=0, result is 0 for e≥1 and 1 for e=0 — matches original.

**(d) d ≤ 2^21 sufficient, not maximal — CONFIRMED.** Sufficient per (a). Not maximal: witness d=2^21+1=2097153 gives d³ = 2^63+3·2^42+3·2^21+1 = 9,223,385,231,000,600,577 < 2^64, so the identical bound (d²−1)(d−1) < d³ < B holds; the same proof admits every d with d³ < 2^64 (up to ≈2,642,245). The guard is conservative by design, not the mathematical limit. (Python's weaker restatement "n·d < 2^63" at py:82–83 is also correct: n < d² strict ⇒ n·d < d³ ≤ 2^63.)

**(e) Skipped square is a nontrapping modulo with nonzero d — CONFIRMED.** Original squares bitlen(e) times; fast path squares bitlen(e)−1 (zero for e=1). The single skipped square is the original's final dead `factor=(factor*factor)%modulus` (fg:16). In the guard domain factor < d ≤ 2^21 so the product < 2^42 (no i64 overflow for the fallback's checked mul) and the divisor is d ≥ 2 (nonzero, no trap). Removing it is unobservable. Outside the domain the fast path is not taken, so the original square still executes.

**(f) Accepted-but-inequivalent inputs / UB — none found.** Both artifacts accept exactly the same domain and compute identical results there; outside it both run the identical original body. Fast-path UB audit: `UINT64_MAX/d` with d ≥ 2; 128-bit product bounded; `q·d ≤ prod` by (a) so no unsigned wrap; `(int64_t)r` with r < 2^21. Concrete edge checks: d=2 ⇒ R=2^63, e=0 (exact for all n); d=2^21 ⇒ 2^21 | 2^64, e=0 (exact); n=1 ⇒ q=0; n up to (d−1)² (the true reachable max, tighter than the claimed d²−1) satisfies the bound; e=INT64_MAX and base=INT64_MAX are fine (u64 loop, reduction mod d).

**Blockers / limitations (source-only)**
1. No compilation/execution was performed (per constraints), so "no overflow/trap" is argued from C semantics of the emitted constructs, not machine-verified.
2. Fallback trap behavior was verified from the emitted helper text (`__forge_mod_i64`, FORGE_MOD macro at codegen.c:2780/2837) and the current .fg source; the dated docs JSON showing generated fallback bodies is corroborating but not current-tree output.
3. "Maximal d" was not computed exactly (only proven non-maximal via the exact d=2097153 witness); an exact supremum would need big-integer arithmetic, which was not executed.
4. No performance claim is made or verified here — the Python tight-pow probe is a generated-C screening prefix (py:82); nothing about current generic compiler performance follows from it.
