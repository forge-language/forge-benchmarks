Audit complete. Report follows.

## Audit: `emit_bounded_mod_pow` and related codegen (read-only, paper analysis)

**Scope**: current uncommitted `compiler/codegen.c` (WIP vs HEAD `420d66f`; +121 lines introduce `emit_bounded_mod_pow` at [codegen.c:2201](/home/helloworld0822/coding/forge/compiler/codegen.c:2201) plus a `label_seq` overflow guard at :2257). No code was compiled, executed, or benchmarked; no generated code was run.

### Emitted structure vs hand-written tight-pow prototype

The recognized Forge shape (grounded in the fixture at `tests/compiler_test.py:440-442`) is the classic checked body: `let result=1; let factor=base%modulus; let power=exponent; while(power>0){ if(power%2==1) result=(result*factor)%modulus; factor=(factor*factor)%modulus; power=power/2; } return result;`. The emitted specialization ([codegen.c:2271-2298](/home/helloworld0822/coding/forge/compiler/codegen.c:2271)) prepends a guarded, Barrett-reduced binary exponentiation that returns early, leaving the original body as fall-through. Paper diff findings:

- **Init order is sound.** `divisor` → `reciprocal` → `factor` → `result/power` is emitted in strict dependency order (:2276-2279); no read-before-init, no re-evaluation of params (plain non-volatile `int64_t` by-value parameters).
- **Bit order is equivalent to classic tight-pow.** The emitted code peels bit 0 (`if(p&1) r=f; p>>=1;` :2280-2282) then loops square-first/multiply-second (:2284-2295). Step-by-step trace against the prototype shows identical bit processing; `exp==0` returns `1` because `return` (:2297) sits inside the runtime guard but **outside** `if(p)`, matching the original body's skipped loop.
- **Reduction math checks out on paper.** For `d<=2^21`, `n<d^2`: `e=d*R-B<d`, `n*e<d^3=2^63<2^64`, so `floor(n*R/2^64)` is exactly `floor(n/d)` — the comment at :2285-2287 is correct; no quotient correction or wrap needed. `UINT64_MAX/d+1` cannot overflow because the guard forces `d>=2`.
- **Guard preserves fallback semantics.** `base>=0 && exp>=0 && 1<d<=2097152` (:2272-2274) excludes everything that could make raw unsigned `%`/shift diverge (negatives, `d<=1` including the zero trap); excluded inputs fall through to the original checked body, whose initial `factor = FORGE_MOD(base, modulus)` still traps via `__forge_check_div_i64` ([codegen.c:2778-2782](/home/helloworld0822/coding/forge/compiler/codegen.c:2778)).
- **Matcher fail-closed**: rejects shadowed lets, non-int params, any `else` branch, extra statements, calls/moves/yields; generated `__forge_pow_*` names are collision-checked against locals and resolvable functions (:2261-2270).

### Invariant descriptors after the prefix

Call order at all three sites is pow-prefix → descriptors → periodic-sum → body ([codegen.c:2967-2969](/home/helloworld0822/coding/forge/compiler/codegen.c:2967), :3059-3061, :3081-3083). When the prefix's guard fires, `return` skips descriptor init and the body — safe because the matcher proves the body pure (no calls, no param writes), and `__forge_mod_prepare` is a pure struct initializer ([codegen.c:2809-2813](/home/helloworld0822/coding/forge/compiler/codegen.c:2809)). When the prefix is absent or the guard fails, descriptors are declared/initialized (:1319-1320) **before** first use in the body (rewrite at :597-606) — order holds. Descriptors are per-function block scope, so reuse of `__forge_invariant_mod_0` across functions is safe. Latent footgun: `emit_invariant_mod_descriptors` itself never checks `state_prefix`/`prove_loop_increments`; it is only safe because current call sites gate it — not a live bug.

### int128-disabled fallback

The `#if defined(__SIZEOF_INT128__) … #endif` (:2271, :2298) strips the entire fast block preprocessor-side; there is no `#else`. What remains — descriptors plus the original checked body — is bit-identical to non-specialized emission. The gate is the canonical GCC/Clang feature macro, so MSVC cl.exe (which never defines it and lacks `__int128`) cleanly drops the block, as do 32-bit targets.

### Library vs module vs ordinary emission

All three sites run the identical pipeline (`cg_begin_function` → `prove_loop_increments=true` → `push_params` → pow → descriptors → periodic → body). Differences: library mode gives external linkage, mangled names, header prototypes, and explicit `#include <stdint.h>` (:2924, :2942); ordinary sets `current_module=""` (:3056); module sets `current_module` (:3078), which widens the name-collision lookup (`cg_resolve_fn_ref`, :190-196) to top-level + current-module functions — other modules' functions are always C-mangled, so no collision. `label_seq` is monotonic per translation unit, so generated names are file-unique. The specialization is **not** applied to externs, coroutines (`emit_coro_fn`), process-init wrappers, native `main`, or the JS backend.

### Parameter evaluation order / side effects

Caller side: arguments are lowered inline `f(a,b,c)` (:715-718), so C's unspecified argument evaluation order applies — pre-existing for all calls, unchanged by this specialization. Callee side: the guard reads params once each (with short-circuit `&&`, no side-effecting expressions); descriptors call `__forge_mod_prepare(param)` at most once per qualifying int parameter in declaration order, after the prefix; the skipped original body is provably pure, so the early return drops no observable effects.

### C ABI and Windows/macOS widths

- Forge `int` is `int64_t` everywhere ([codegen.c:466](/home/helloworld0822/coding/forge/compiler/codegen.c:466)); by-value `int64_t` params/returns are ABI-stable on Win64 (LLP64) and macOS (LP64 x86_64 / AAPCS64 arm64). Library headers include `<stdint.h>`, so exported prototypes are well-defined on both.
- `UINT64_MAX`/`UINT64_C`/`INT64_C` are C99 `<stdint.h>` — provided by MSVC too. No `long`-width, endian, or alignment assumptions in the fast path.
- `unsigned __int128` appears only under `__SIZEOF_INT128__` — GCC/Clang-defined on x86_64 and aarch64 (macOS Apple Silicon, MinGW); absent on MSVC → fallback. Note a **policy divergence**: the descriptor helpers additionally exclude `__aarch64__`/`_M_ARM64` (:2811, :2817, per HEAD commit "Keep checked hardware remainder on ARM64 targets") while the pow fast path enables int128 on ARM64. Both gates are self-consistent (type available wherever the macro is defined), so this is a consistency observation, not a correctness defect.

### Non-portable constructs (file:line)

1. [codegen.c:2839](/home/helloworld0822/coding/forge/compiler/codegen.c:2839) — `FORGE_MOD` uses a GNU statement expression `({ … })` (with nested `_Generic`/`_Static_assert`); rejected by MSVC cl.exe. This is how the **fallback** body lowers `%` against a non-constant modulus, so the fallback requires a GCC/Clang-family compiler even with int128 disabled.
2. [codegen.c:2835](/home/helloworld0822/coding/forge/compiler/codegen.c:2835) — `FORGE_ADD/SUB/MUL/DIV` dispatch via C11 `_Generic`, unsupported in MSVC cl.exe C mode; used by the fallback body's wrapping products/quotients.
3. [codegen.c:2756](/home/helloworld0822/coding/forge/compiler/codegen.c:2756) — `FORGE_PRINT_AUTO` `_Generic` (not on the mod-pow path; listed for completeness).
4. [codegen.c:2288](/home/helloworld0822/coding/forge/compiler/codegen.c:2288), :2292 — `unsigned __int128` — GNU-extension type, but correctly gated; not a defect.
5. Observation: ordinary/module emission ([codegen.c:2985-2986](/home/helloworld0822/coding/forge/compiler/codegen.c:2985)) includes no `<stdint.h>` directly, relying on the external `forge_runtime.h` for the `uint64_t`/`int64_t`/`UINT64_MAX` used by the fast path; library mode is self-contained (:2942).

**No native speed claim is made for this implementation.** Nothing was compiled, executed, or benchmarked; only structural equivalence and portability were assessed on paper.

**Limitations**: `forge_runtime.h` lives in an external install path (per `driver.c:333`); its stdint contents were not inspected (build/_deps off-limits per task). MSVC/macOS toolchains were not exercised. The worktree is mid-WIP (modified `tests/*` uncommitted); line numbers reflect the current on-disk `codegen.c` (3180 lines).
