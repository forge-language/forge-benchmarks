# Native cross-OS CPU comparison

Platform: `macOS-15.7.9-arm64-arm-64bit` / `arm64`. Measured 60 balanced triples per workload, seed 20261014.

| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0009 [0.9971, 1.0055] | 0.8730 [0.8707, 0.8803] | below target |
| primes | 0.7361 [0.7334, 0.7406] | 0.7015 [0.6973, 0.7042] | below target |
| scan | 0.9998 [0.9984, 1.0027] | 1.0016 [0.9983, 1.0101] | below target |
| builder | 0.9961 [0.9769, 1.0088] | 0.5732 [0.5666, 0.5932] | below target |
| immutable | 1.0030 [0.9993, 1.0089] | 17.1644 [16.6875, 18.2254] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
