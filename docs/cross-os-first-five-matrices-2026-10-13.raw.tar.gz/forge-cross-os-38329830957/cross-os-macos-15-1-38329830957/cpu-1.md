# Native cross-OS CPU comparison

Platform: `macOS-15.7.9-arm64-arm-64bit` / `arm64`. Measured 60 balanced triples per workload, seed 20261014.
**Generated-C experiment `bounded-inline`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 0.9953 [0.9859, 1.0092] | 0.8741 [0.8596, 0.8866] | below target |
| primes | 0.7356 [0.7291, 0.7424] | 0.7053 [0.7015, 0.7081] | below target |
| scan | 1.0024 [1.0000, 1.0041] | 1.0016 [0.9987, 1.0056] | below target |
| builder | 0.9886 [0.9685, 1.0044] | 0.5703 [0.5642, 0.5823] | below target |
| immutable | 1.0004 [0.9946, 1.0054] | 16.6599 [16.5264, 16.7727] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
