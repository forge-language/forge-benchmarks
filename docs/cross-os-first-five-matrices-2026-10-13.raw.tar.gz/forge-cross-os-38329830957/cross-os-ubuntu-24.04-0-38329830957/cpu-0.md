# Native cross-OS CPU comparison

Platform: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39` / `x86_64`. Measured 60 balanced triples per workload, seed 20261013.
**Generated-C experiment `bounded-inline`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0001 [0.9998, 1.0004] | 1.8556 [1.8553, 1.8560] | supported for this case |
| primes | 1.1077 [1.1055, 1.1082] | 1.4094 [1.4073, 1.4106] | supported for this case |
| scan | 1.0464 [1.0446, 1.0485] | 0.9741 [0.9702, 0.9778] | below target |
| builder | 0.9972 [0.9961, 0.9981] | 1.0876 [1.0869, 1.0891] | below target |
| immutable | 0.9964 [0.9947, 0.9984] | 18.7537 [18.7019, 18.7926] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-0.json](cpu-0.json).
