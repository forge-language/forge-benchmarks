# Native cross-OS CPU comparison

Platform: `Windows-2022Server-10.0.20348-SP0` / `AMD64`. Measured 60 balanced triples per workload, seed 20261014.
**Generated-C experiment `hybrid-range`: the candidate C helper is modified after emission. These results do not measure the shipped compiler unchanged.**


| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 1.0001 [0.9993, 1.0007] | 1.8572 [1.8564, 1.8580] | supported for this case |
| primes | 1.0189 [1.0169, 1.0206] | 1.2704 [1.2675, 1.2723] | supported for this case |
| scan | 4.4158 [4.4116, 4.4178] | 2.3542 [2.3525, 2.3571] | supported for this case |
| builder | 1.5607 [1.5517, 1.5667] | 1.4976 [1.4911, 1.5082] | supported for this case |
| immutable | 1.5543 [1.5493, 1.5559] | 77.8607 [77.2356, 78.3209] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
