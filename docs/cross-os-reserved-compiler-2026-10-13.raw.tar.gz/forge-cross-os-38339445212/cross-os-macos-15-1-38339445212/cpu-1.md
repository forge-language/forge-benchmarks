# Native cross-OS CPU comparison

Platform: `macOS-15.7.9-arm64-arm-64bit` / `arm64`. Measured 60 balanced triples per workload, seed 20261014.

| Workload | Candidate / baseline (95% interval) | Candidate / Rust (95% interval) | Rust 1.10 |
| --- | ---: | ---: | --- |
| lcg | 0.9982 [0.9904, 1.0109] | 0.8779 [0.8643, 0.8859] | below target |
| primes | 0.7360 [0.7323, 0.7429] | 0.7056 [0.7001, 0.7150] | below target |
| scan | 0.9964 [0.9933, 1.0025] | 1.0005 [0.9946, 1.0053] | below target |
| builder | 2.2830 [2.2795, 2.2901] | 1.3050 [1.3021, 1.3076] | supported for this case |
| immutable | 1.0031 [0.9988, 1.0108] | 16.5934 [16.4966, 16.7364] | supported for this case |

All measured checksums and same-input warmups match an independent Python reference. All six three-way permutations occur equally often. Each row has a paired-ratio bootstrap 95% interval; this is not simultaneous confidence over workloads or proof for all programs.

Both Forge versions share identical SDK archives/headers, source algorithms and clock; one Rust control is used throughout. C uses -O3/native CPU tuning/LTO; Rust uses opt-level=3, target-cpu=native, thin LTO and disabled overflow checks. Process startup is excluded from kernel times. All platforms use unpinned child processes; virtualized/shared runners and frequency changes remain sources of noise. Compare before/after ratios within each OS; absolute times across different OS/hardware/architectures are not OS-only causal comparisons.

Builder transfers the buffer in both implementations. Immutable append uses different allocation/lifetime policies. CPU results do not prove HTTP capacity, memory-safety equivalence or universal language throughput. Build failures are recorded as failed_no_claim and must not be silently removed from the cross-OS report.

Full samples, commands and hashes: [cpu-1.json](cpu-1.json).
